import React, { createContext, ReactElement, ReactNode, useState } from "react";
import { en_US } from "./en_US";
import { LocalizationBundle } from "./LocalizationBundle";

interface LocalizationControllerProps {
  children: ReactNode;
}

interface LocalizationState {
  readonly bundle: LocalizationBundle;
}

const initialState: LocalizationState = {
  bundle: en_US,
};

export const LocalizationContext = createContext(initialState);

export function LocalizationController(
  props: LocalizationControllerProps
): ReactElement {
  const [state] = useState(initialState);

  return (
    <LocalizationContext.Provider value={state}>
      {props.children}
    </LocalizationContext.Provider>
  );
}
