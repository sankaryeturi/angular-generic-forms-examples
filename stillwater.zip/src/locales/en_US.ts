export const en_US = {
  login: {
    manage: "Manage Your Policy",
    trouble: "Trouble Logging In?",
    newuser: "New User?",
    usernamerule: "Minimum 6 characters and Max 32 characters",
    passcodeError: "Please enter your password",
    easyaccesscontext: "Easy Access - no log in required",
    forgotMyPassword: "I forgot my password",
    forgotMyUserId: "I forgot my User ID",
    forgotUserIDSuccessMessage: "User ID has been sent to given email id.",
    forgotPasswordSuccessMessage:
      "An email has been sent with a link to reset your password. The link will expire in 30 minutes.",
  },

  signup: {
    securityContext:
      "For your security, please help us verify your identity. All information provided here should correspond to the first person listed on the policy.",
    zipcodeLabel: "Mailling Zip Code",
    zipcodeError: "Please enter mailling zipcode",
    zipcodeLength: "zipcode should be maximum 5 characters",
    subHeading: "user id and password set up",
    useridExistencyError: "User ID already registered.",
    emailExistencyError: "Given email already registered.",
  },

  dashboard: {
    policyFeaturesInfo: [
      {
        title: "DO I NEED UMBRELLA INSURANCE?",
        subTitle:
          "A commonly asked question when considering purchasing Umbrella insurance is “Do I really need it?”",
        backgroundImageClass: "shield-check-icon",
        buttonIconClass: "shield-check-whiteBg-icon",
        buttonContent:
          "Learn more about the risks that Umbrella insurance covers",
        buttonClass: "",
      },
      {
        title: "WHAT’S THE DIFFERENCE?",
        subTitle:
          "50% of homeowners don’t understand what “actual cash value” or “replacement cost” means.",
        backgroundImageClass: "home-icon",
        buttonIconClass: "home-white-smoke-pipe-icon",
        buttonContent: "Know how to make the best choice for your situation",
        buttonClass: "",
      },
      {
        title: "TOP 5 MYTHS ABOUT AUTO INSURANCE",
        subTitle:
          "We’re calling out some of the biggest myths about auto insurance to help you feel less intimidated and more informed.",
        backgroundImageClass: "car-icon",
        buttonIconClass: "car-alt-white-icon padding-1020",
        buttonContent: "Know more and drive confidently",
        buttonClass: "ssp-pl2",
      },
      {
        title: "CHECK OUT THE KNOWLEDGE BASE",
        subTitle:
          "Learn more about insurance with our knowledge articles, FAQs and Glossary.",
        backgroundImageClass: "book-open",
        buttonIconClass: "open-book-icon",
        buttonContent: "Browse the knowledge base and learn more",
        buttonClass: "ssp-pl2",
      },
    ],
  },

  "dashboard.paragraph1":
    "Lacus gravida porta elementum. Donec a erat lectus. Pellentesque id semper odio. Aliquam dapibus luctus fermentum.",

  "confirmSignup.pContent1":
    "Your online service is now activated. You have successfully created your user ID and password. A confirmation email has been sent to the address provided.",
  "confirmSignup.pContent2":
    "Make sure you can always access this email address. We'll use it in case you need to reset your password or retrieve your user ID.",

  "accountSettings.personalContext":
    "You can change your Mailing address, Email address and phone number",
  "accountSettings.securityContext": "You can change your password and User ID",
  "accountSettings.communicationContext":
    "You can see the Notification Preferences and Paperless Settings",

  "changeMailingAddress.subHeading": "CHANGE MAILING ADDRESS",
  "changeMailingAddress.success":
    "You have successfully submitted mailing address change for the following policies:",

  "changeMailingAddressInfo.P1":
    "If you're just changing your mailing address, please continue. This will NOT change where your home is located or your cars are kept. If you're actually moving and need to change your address, please contact ",
  "changeMailingAddressInfo.P1A":
    "your agent or our Customer Service department.",
  "changeMailingAddressInfo.autoInfo":
    "If you have an Auto policy and are moving to a new address, you'll need a new policy.",
  "changeMailingAddressInfo.homeinfo":
    "If you're moving Homes...this requires a new policy. ",
  "changeMailingAddressInfo.condoInfo":
    "If you're moving Condos...in many cases we can just change the unit #, but if you're moving to a new building or location you'll need a new policy. ",
  "changeMailingAddressInfo.apartmentInfo":
    "If you're moving Apartments...in many cases we can just change the unit # or address, but sometimes you may need a new policy.",
  "changeMailingAddressInfo.tenantInfo":
    "If you have a Tenant (Dwelling) policy and have sold the property or bought a new property, please contact your agent or us. ",
  "changeMailingAddressInfo.umbrellaInfo":
    "If you have an Umbrella policy in most cases we can update the addresses of the policies and items on your policy. ",
  "changeMailingAddressInfo.earthquakeInfo":
    "If you have an Earthquake policy in most cases this will require a new policy. ",

  "changemailadd.address": "Address",
  "changemailadd.city": "City",
  "changemailadd.state": "State",
  "changemailadd.zipcode": "ZIP Code",
  "changemailadd.addresserror": "Please enter Address",
  "changemailadd.cityerror": "Please enter city",
  "changemailadd.stateerror": "Please Select State",
  "changemailadd.zipcodeerror": "Please enter ZIP code",
  "changemailadd.submitbutton": "Submit",
  "changemailadd.successResponse": "Email address changed successfully",

  changeEmailAddress: {
    subHeading: "PERSONAL - CHANGE EMAIL ADDRESS",
    label1: "Current Email address",
    newEmail: "New Email",
    confirmNewEmail: "Confirm New Email",
    newEmailError: "Please enter new email",
    confirmEmailError: "Please enter confirm new email",
    confirmEmailInvaildError: "Invalid Confirm Email Address",
    emailMatchError: "New email and confirm email is not matched",
  },

  changePhoneNumber: {
    input1: "Primary Phone",
    input2: "Secondary Phone",
    input1Error: "Please enter phone number",
    subHeading: "personal - change phone number",
  },

  changePassword: {
    currentPassword: "Current Password",
    newPassword: "New Password",
    confirmPassword: "Confirm New Password",
    newPasswordError: "Please enter new password",
    confirmPasswordError: "Please enter confirm password",
    subHeading: "personal - change password",
    successMessage: "Password changed successfully",
  },
  policyInfo: {
    "insuranceDrivers.text1": "Herb Sewell",
    "insuranceDrivers.text2": "Primary named insured",
    "insuranceDrivers.text3": "Quanita Sewell",
    "insuranceDrivers.text4": "Secondary named insured",
  },

  "policyCoverage.premiumTotal": "Premium Total",

  changeUserid: {
    subHeading: "personal - change userid",
    label1: "Current User ID :",
    oldPasswordLabel: "Enter Your Password",
    newUseridLabel: "New User ID",
    newUseridError: "Please enter new user ID",
    confirmNewUseridError: "Please enter confirm user ID",
    userIdMatchError: "New User ID and confirm User id should match",
    successMessage: "User Id changed successfully",
    userIdMinChar: "User id minimum 6 charactors",
  },

  changeSecurityQuestions: {
    subHeading: "change security questions"
  },

  "paperlessPreference.content1": "Go paperless for your Stillwater policies",
  "paperlessPreference.content2":
    "Don't worry you'll always have access to important documents anytime you log in to your Stillwater account.",
  "paperlessPreference.successMessage":
    "Congratulations! You're paperless now.",

  payments: {
    makepayContext1: "Includes any fully earned fees",
    context1:
      "This amount will be withdrawn from the above account no sooner than 3 days from the day you submit this request.",
    context2:
      "I acknowledge that I am authorizing an electric debit to my account for $2,340.00 which will be debited on or after Mon May 18 10:33:05 EDT 2020.",
    context3: "to open and acknowledge the Terms & Conditions",
    termsConditionsLabel: "I agree to use DocuSign to electronically sign for and acknowledge setting up or changing a monthly electronic debit (EFT) to pay for this policy",
    creditDebitCard: "Credit/Debit Card",
    eftLabel: "EFT (Electronic Withdrawal)",
    eftLabel1: "EFT (Electronic Check) Payment",
    errorInfo:
      "Physical checks from the Mortgage or Title company, and online bill-pay checks, must be sent to Stillwater for processing. Do not attempt to process electronically",
    paymentType1: "Pay the full amount now",
    paymentType2: "Monthly Debit/Credit Card",
    paymentType2Desc: "Automatic monthly bill to a credit or debit card",
    paymentType3: "Monthly EFT withdrawn from bank account",
    paymentType3Desc: "Direct monthly withdrawal from a specified bank account",
    paymentType4: "50/50 Billing",
    paymentType4Desc: "Integer sollicitudin turpis a elit porta molestie.",
    filterContent: "Filter transactions by date range",
    yourPaymentPlan: "your payment plan",
    yourCurrentPaymentPlan: "Your current payment plan",
    yourCurrentPaymentPlanContent: "Recurring monthly EFT withdrawn from bank account",
    paymentContactInfo: "Change your current pay plan, set up an automatic payment schedule, or ask us anything about your account by calling 888-999-0000."
  },

  claims: {
    claimNumber: "claim number",
    dateOfLoss: "date of loss",
    locationOfLoss: "location of loss",
    dateReported: "date reported",
    lossDescription: "loss description",
    claimExaminer: "claim examiner",
    claimExaminerPhone: "claim examiner phone",
    claimExaminerEmail: "claim examiner email",
    claimUpdates: "claim updates",
    thingsToDo: "things to do",
    claimClosed: "Claim Closed",
    viewClaimDetails: "View Claim Details",
  },

  troubleLogging: {
    userIdNavigateText: "Forgot your User ID ? Click here",
    passcodeContent1:
      "I know my User ID and will answer Security Questions to reset my password",
    passcodeContent2: "I know my Client ID Number to reset my password",
    passcodeContent3:
      "Your Client ID is located in the upper right hand corner of any mailed Declarations Page or Policy Bill.",
    forfotPassClick: "Forgot your password ? Click here",
  },

  autoId: {
    context1:
      "Send to multiple recipients using comma to separate email addresses",
    IDheading: "ID Card Summary",
    roadAssistanceSuccess: "You have Roadside Assistance for this policy.",
    roadAssistanceError: "You do not have Roadside Assistance for this policy.",
    roadAssistanceToPolicy: "add roadside assistance to your policy",
    roadAssistanceNeedHelp: "need help now?",
    roadAssistanceCover: "24/7 ASSISTANCE COVERS",
    roadAssistanceDriverConfidently:
      "DRIVE CONFIDENTLY WITH ROADSIDE ASSISTANCE",
    addPolicyContact: "(866)890-1234",
    assistanceCoverList: {
      towing: "Towing",
      batteryService: "Battery Service",
      deliveryService: "Delivery Service",
      flatTireChange: "Flat Tire Change",
      lockoutService: "Lockout Service",
    },
    successMessageContent: "Your ID Card has been successfully sent to following recipient(s)"
  },
  eDocs: {
    enterPolicyNo: "Please enter your policy number",
  },

  "notificationpref.subHeading": "PERSONAL - CHANGE MAILING ADDRESS",
  "notificationpref.content1":
    "Get a reminder when we are waiting on something that will help expedite your claim.",
  "notificationpref.content2":
    "Get a reminder when your bill is due and when payment has been received.",
  "notificationpref.content3":
    "Get a confirmation when a change to your policy is made.",
  "notificationpref.content4":
    "Get an alert on tips for severe weather events and how to report a weather related claim.",
  "notificationpref.content5":
    "Duis non mauris at mi laoreet ornare ut quis nisi.",
  "notificationpref.formSuccessMessage": "Notification Preferences are changed successfully",

  "footer.rightsContent":
    "©2020 Stillwater Insurance Group. All Rights Reserved.",
  "footer.privacyLink": "Privacy Policy",
  "footer.securityPolicy": "Security Policy",

  button: {
    returnLogin: "Return to Log In",
    submit: "Submit",
    prev: "Prev",
    next: "Next",
    changePayPlan: "Change Pay Plan to Monthly Bank Withdrawal (EFT)",
    makepay: "Make a Payment",
    updateBankingInfo: "Update Banking Information"
  },
  "button.edocs": "e-Docs",
  "button.fileClaim": "File a claim",
  "button.changepass": "Change Password",
  "button.changeuserid": "Change User ID",
  "button.changemailingadd": "Change Mailing Address*",
  "button.changemailadd": "Change Email Address",
  "button.changephoneno": "Change Phone Number",
  "button.notificationpref": "Notification Preferences",
  "button.paperlessset": "Paperless Settings",
  "button.changeSecurityQuestions": "Change Security Questions",
  "button.submit": "Submit",
  "button.save": "Save",
  "button.cancel": "Cancel",
  "button.contact": "Contact",
  "button.continue": "Continue",
  "button.accountsettings": "Account Settings",
  "button.additionalPhoneNo": "Add additional phone number",
  "button.knowDifference": "Know the difference",
  "button.makeSureCoverage": "Make sure you have the right amount of coverage",
  "button.addDriver": "Add Driver",
  "button.addVehicle": "Add Vehicle",
  "button.submitPayment": "Submit Payment",

  heading: {
    forgotPassword: "forgot password",
    forgotUserid: "forgot user id",
    edocs: "eDOCS",
    docsNotes: "DOCS & NOTES",
    changePayToEFT: "CHANGE PAY PLAN TO EFT",
    payPlanChange: "PAY PLAN CHANGE TO RECURRING MONTHLY ELECTRONIC DEBIT (EFT) CONFIRMATION"
  },

  "heading.bannerheading1": "know how to",
  "heading.bannerheading2": "insurance",
  "heading.downloadapps": "Download the stillwater mobile app today",
  "heading.announcement":
    "Important COVID-19 information for our policy holders",
  "heading.accountsettings": "Account Settings",
  "heading.accsetpersonal": "personal",
  "heading.security": "security",
  "heading.communication": "communication",
  "heading.currentmailadd": "Current Mailing Address:",
  "heading.newmailadd": "New Mailing Address:",
  "heading.dashboardMain": "knows how to insurance",
  "heading.changeEmailAddress": "change email address",
  "heading.changephonenumber": "change phone number",
  "heading.changePasscode": "change password",
  "heading.changeuserid": "change user id",
  "heading.accountSignup": "account sign up",
  "heading.confirmation": "confirmation",
  "heading.securityQuestions": "Security Questions",
  "heading.policyInformation": "POLICY INFORMATION",
  "heading.policySummary": "POLICY SUMMARY",
  "heading.discounts": "DISCOUNTS",
  "heading.insuredDrivers": "INSURED DRIVERS",
  "heading.vehicles": "VEHICLES",
  "heading.policyCoverages": "policy coverages",
  "heading.payments": "payments",
  "heading.billing": "billing",
  "heading.premiumTotal-perVehicle": "Premium Total - Per Vehicle",
  "heading.dashboardHeading1":
    "WHAT’S THE DIFFERENCE BETWEEN ACTUAL CASH VALUE AND REPLACMENT COST?",
  "heading.dashboardHeading2": "AUTO INSURANCE",
  "heading.dashboardHeading3": "DO YOU HAVE ENOUGH?",
  "heading.paymentSummary": "payment summary",
  "heading.howYouWantToPay": "HOW DO YOU WANT TO PAY",
  "heading.transactionHistory": "TRANSACTION HISTORY",
  "heading.creditCardInfo": "Credit Card Information",
  "heading.billingAddressCard": "Billing Address on Card",
  "heading.paperlesspreferences": "paperless preferences",
  "heading.paperlesspreferencesInfo": "PAPERLESS PREFERENCES INFO & FAQs",
  fileExt: {
    pdf: ".pdf"
  },
  label: {
    whatsThis: "What is this",
    clientId: "Client ID",
    email: "Email",
    autoId: "auto id",
    download: "download",
    print: "print",
    send: "Send",
    effective: "effective",
    expires: "expires",
    vehicleDesc: "vehicle description",
    agency: "agency",
    done: "Done",
    filter: "filter",
    fromDate: "from date",
    toDate: "to date",
    call: "Call",
    dob: "Date of Birth",
    policyNumber: "Policy Number",
    userid: "User ID",
    passcode: "Password",
    confirmPassword: "Confirm Password",
    yr: "YR",
    make: "MAKE",
    vin: "VIN",
    icCardPolicy: "ID Card Policy",
    routingNumber: "Routing Number",
    accountNumber: "Account Number",
    confirmAccountNumber: "Confirm Account Number",
    clickHere: "Click here"
  },
  "label.policyNumber": "Policy Number",
  "label.email": "Email",
  "label.userid": "User ID",
  "label.passcode": "Password",
  "label.login": "Log In",
  "label.register": "Register",
  "label.viewDetails": "View Details",
  "label.makePayment": "Make a Payment",
  "label.payment": "Payment",
  "label.autiIdCard": "Auto ID Card",
  "label.policyTerm": "Policy Term",
  "label.policyPremium": "Policy Premium",
  "label.nextPaymentDue": "Next Payment Due",
  "label.amountDue": "Amount Due",
  "label.amount": "Amount",
  "label.totalSavings": "Total Savings",
  "label.editSelectedCoverages": "edit selected coverages",
  "label.logOut": "Log Out",
  "label.areYouMoving": "Are You Moving?",
  "label.auto": "Auto",
  "label.home": "Home",
  "label.condo": "Condo",
  "label.apartment": "Apartment",
  "label.tenant": "Tenant (Dwelling)",
  "label.umbrella": "Umbrella",
  "label.earthquake": "Earthquake",
  "label.roadsideAssistance": "ROADSIDE ASSISTANCE",
  "label.docNotes": "DOCS & NOTES",
  "label.policyInfo": "POLICY INFO",
  "label.claims": "CLAIMS",
  "label.submitClaims": "submit claim",
  "label.submitAClaims": "submit a claim",
  "label.total": "Total",
  "label.editRemoveDriver": "Edit/Remove Driver",
  "label.lastPaymentReceived": "Last Payment Received",
  "label.paymentDueDate": "Payment Due Date",
  "label.lastPaymentAmount": "Last Payment Amount",
  "label.minimumAmountDue": "Minimum Amount Due",
  "label.totalAmountDue": "Total Amount Due",
  "label.processDate": "process date",
  "label.transaction": "transaction",
  "label.balence": "balence",
  "label.paymentPlan": "payment plan",
  "label.expirationDate": "Expiration Date",
  "label.cvv": "CVV",
  "label.accountType": "Account Type",
  "label.printAcknowledgment": "Print Acknowledgment",
  "label.click": "Click",
  "label.here": "HERE",
  "label.reportAclaim": "report a claim",
  "label.activeClaims": "active claims",
  "label.claimHistory": "claim history",
  "label.itemToDo": "Item To Do",
  "label.toDoPlaceholder": "To Do Placeholder",
  "label.targetMessageHeading": "Alert message text here",
  "label.selectOption": "-- Select Option --",
  "label.text": "text",
  "label.yes": "yes",
  "label.no": "no",
  "label.marketing": "marketing",
  "label.securityQuestion": "Security Question",
  "label.answer": "Answer",
  "label.getAquote": "Get a quote",
  "label.retrieveSavedQuote": "Retrieve a Saved Quote",

  text: {
    sendEmail: "Send Email To",
  },
  "text.bannerAutoInsurance": "What goes into the price of auto insurance",
  "text.bannerHomeInsurance": "Top 5 myths about Home Insurance",
  "text.bannerRentInsurance": "Renters Insurance 101",
  "text.bannerUmbrellaInsurance": "Do I need Umbrella Insurance?",
  "text.downloadappcontext":
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ligula sapien, feugiat quis nunc vitae, vehicula aliquam est. Etiam id urna quis justo interdum varius id vitae leo. Donec hendrerit at purus vitae congue.",
  "text.dummycontent":
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ut tellus ut libero blandit tristique eu sit amet velit. Vivamus viverra eleifend magna dictum rutrum. Nunc facilisis, sapien in tempus molestie, dui tortor blandit mi, nec commodo dui ipsum ac sapien. Ut massa augue, pellentesque eget nibh non, imperdiet eleifend nisl. Ut lacinia nec mauris at congue. Maecenas accumsan diam non suscipit fringilla. Aenean non augue in dolor lobortis scelerisque eget in odio. Phasellus dolor leo, suscipit vel  ex sit amet, pellentesque egestas est. Fusce felis ex, porttitor vitae nisl sed, aliquam semper urna.",
  "text.dummycontentsmall":
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dignissim sodales mauris elementum feugiat. Sed porta consectetur tortor laoreet hendrerit.",
  "text.accsetcontent1":
    "Suspendisse non fermentum neque. Sed vel quam quam. Nam ut velit eu magna interdum ultricies in eget mauris. Curabitur semper finibus metus, eget vehicula tortor sodales ut. Donec pharetra finibus mi, quis feugiat elit commodo sed. Mauris varius, arcu vel tincidunt cursus, mi justo mollis quam, et lacinia elit mi et eros.",
  "text.addressnote":
    "Note: For foreign mailing address changes, please Cancel request and contact customer service at 1-800-849-6140.",
  "text.changemailingaddpolicy":
    "The change in mailing address will be for selected policies only.",
  "text.policy": "Policy",
  "text.emptyRecords": "There is no records",
  "text.deductible": "Deductible",
  "text.paperlessTermsConditions": "Paperless Terms & Conditions",

  validation: {
    policyNoRequired: "Please enter policy number",
    dobValidation: "Invalid date format..!",
    emailRequired: "Please enter Email ID",
    emailPattern: "Invalid Email Address",
    useridRequired: "Please enter User ID",
    useridMinimum: "User ID should be minimum 6 characters",
    useridMaximum: "User ID should be maximum 32 characters",
    passStrengthMin: "Must contain at least eight characters",
    passStrengthUppercase: "Must contain at least one upper case letter",
    passStrengthNumber: "Must contain at least one number",
    passStrengthSpcChar: "Must contain at least one special character",
    confirmPasswordMatch: "Password and confirm password must match.",
    routingNoRequired: "Please enter Routing Number",
    accountNoRequired: "Please enter Account Number",
    confirmAccountNoRequired: "Please enter confirm Account Number",
    accountNoShouldMatch: "Account number should match"
  },
  "validation.phoneNumber": "Not a valid phone number",
  "validation.currentPassworeRequired": "Please enter your current password",
  "validation.passMin": "Password should be minimum 6 characters",
  "validation.passcodeCombo": "Password shoud have alpha numaric",

  "validation.newConfirmPasswordMatch":
    "New password and confirm password must match.",
  "validation.dobValidation": "Invalid date format..!",
  "validation.policyNoRequired": "Please enter policy number",
  "validation.answerRequired": "Answer is required",
  "validation.clientIdRequired": "Please enter client ID",

  "image.logocontext": "Stillwater Insurance",
  "links.androidapp":
    "https://play.google.com/store/apps/details?id=com.stillwater.insurance&hl=en_US",
  "links.iosapp":
    "https://apps.apple.com/us/app/stillwater-insurance/id1434850228",
};
