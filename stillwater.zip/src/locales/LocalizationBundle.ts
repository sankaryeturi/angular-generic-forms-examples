import { en_US } from "./en_US";

export type LocalizationBundle = typeof en_US;
export type LocalizationKey = keyof LocalizationBundle;
