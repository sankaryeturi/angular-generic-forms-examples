/* eslint-disable */
import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, mount, ReactWrapper, configure } from "enzyme";
import EFTComponent from "../pages/payments/Eft";
import { Provider } from "react-redux";
import TestRenderer from "react-test-renderer";
import { useSelector, useDispatch } from "react-redux";

const mockDispatch = jest.fn();
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

configure({ adapter: new Adapter() });

describe("<EFTComponent /> with no props", () => {
  test("EFTComponent snapshot", () => {
    const snap = TestRenderer.create(<EFTComponent />).toJSON();
    expect(snap).toMatchSnapshot();
  });

  it("renders <EFTComponent/> components", () =>
    expect(shallow(<EFTComponent />)).toMatchSnapshot());

  // Form check
  it("renders <ValidatorForm/> components", () => {
    const wrapper = mount(<EFTComponent />);
    expect(wrapper.exists("ValidatorForm")).toMatchSnapshot();
  });
  // Routing Field validations
  it("renders Routing field", () => {
    const wrapper = mount(<EFTComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("name")).toEqual("routing");
  });
  // Sccount Field validations
  it("renders Account field", () => {
    const wrapper = mount(<EFTComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("name")).toEqual("account");
  });
  // cancel button
  it("renders Cancel button field", () => {
    const wrapper = mount(<EFTComponent />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(0).text()).toEqual("Cancel");
  });
  // submit button
  it("renders Submit button field", () => {
    const wrapper = mount(<EFTComponent />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(1).text()).toEqual("Submit Payment");
  });


});
