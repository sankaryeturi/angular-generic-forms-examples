/* eslint-disable */
import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, mount, ReactWrapper, configure } from "enzyme";
import { LoginComponent } from "../shared-components/login/login";
import { Provider } from "react-redux";
import TestRenderer from "react-test-renderer";
import { useSelector, useDispatch } from "react-redux";

const mockDispatch = jest.fn();
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

configure({ adapter: new Adapter() });

describe("<LoginComponent /> with no props", () => {
  test("LoginComponent snapshot", () => {
    const snap = TestRenderer.create(<LoginComponent />).toJSON();
    expect(snap).toMatchSnapshot();
  });

  it("renders <LoginComponent/> components", () =>
    expect(shallow(<LoginComponent />)).toMatchSnapshot());

  it("renders <TextValidator/> components", () => {
    expect(shallow(<a href="/login">Trouble Logging In?</a>)).toMatchSnapshot();
  });

  // it("calls onLogin when button clicked", () => {
  //   const onSubmitMock = jest.fn();
  //   const component = shallow(<LoginComponent />);
  //   expect(onSubmitMock).toMatchSnapshot();
  // });

  it("should disable submit button on submit click", () => {
    const wrapper = mount(<LoginComponent />);
    expect(wrapper).toBeTruthy();
  });

  it("renders <LoginComponent/> components", () => {
    const wrapper = mount(<LoginComponent />);
    expect(wrapper.exists()).toBeTruthy();
  });
  // form submit
  it("form submit action", () => {
    const wrapper = mount(<LoginComponent />);
    const innerWrap = wrapper.find("ValidatorForm");
    expect(innerWrap.simulate('click'));
  })
  it("renders <TextValidator/> components", () => {
    const wrapper = mount(<LoginComponent />);
    expect(wrapper.exists("TextValidator")).toEqual(true);
  });

  it("renders <TextValidator/> components", () => {
    const wrapper = mount(<LoginComponent />);
    expect(wrapper.find("TextValidator").length).toEqual(2);
  });

  it("renders <LoginComponent/> components", () => {
    const wrapper = mount(<LoginComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("name")).toEqual("userId");
    //innerWrap.at(0).simulate('change', { target: { name: 'userId', value: wrapper.state()} });
  });

  it("renders <LoginComponent/> components", () => {
    const wrapper = mount(<LoginComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("validators"));
    // innerWrap.at(0).simulate('change', { target: { name: 'userId', value: wrapper.state() } });
  });

  it("renders <LoginComponent/> components", () => {
    const wrapper = mount(<LoginComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("name")).toEqual("password");
    //innerWrap.at(1).simulate('change', { target: { name: 'password', value: wrapper.state() } });
  });

  it("renders <TextValidator/> components", () => {
    const wrapper = mount(<LoginComponent />);
    const btnWrap = wrapper.find("button");
    expect(btnWrap.exists()).toBe(true);
    // expect(btnWrap.dive().find('span').text()).toEqual('Login');
  });

  it("renders <TextValidator/> components", () => {
    const wrapper = mount(<LoginComponent />);
    expect(wrapper.find(".ssp-error").exists()).toBe(true);
  });

  it("renders <TextValidator/> components", () => {
    const wrapper = mount(<LoginComponent />);
    expect(wrapper.find("a").at(0).exists()).toBe(true);
  });

  it("renders <TextValidator/> components", () => {
    const troubleLogin = mount(<a href="/login">Trouble Logging In?</a>);
    expect(troubleLogin.text()).toEqual("Trouble Logging In?");
  });

  it("renders <TextValidator/> components", () => {
    const wrapper = mount(<LoginComponent />);
    expect(wrapper.find("a").at(1).exists()).toBe(true);
  });

  it("renders <TextValidator/> components", () => {
    const newUser = mount(<a href="/login">New User?</a>);
    expect(newUser.text()).toEqual("New User?");
  });

  // it("calls onLogin when button clicked", () => {
  //   const onSubmitMock = jest.fn();
  //   const component = shallow(<LoginComponent/>);
  //   component.find("TextValidator").simulate('change', { target: { value: component.state()  } })
  //   component.find("TextValidator").simulate('change', { target: { value: 'myPassword' } })
  //   component.find("form").simulate("submit");
  //   expect(onSubmitMock).toBeCalled();
  // });
});
