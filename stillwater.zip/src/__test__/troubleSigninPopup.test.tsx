/* eslint-disable */
import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, mount, ReactWrapper, configure } from "enzyme";
import TroubleSigninComponent from "../shared-components/trouble-signin-popup/troubleSigninPopup";
import { Provider } from "react-redux";
import TestRenderer from "react-test-renderer";
import { useSelector, useDispatch } from "react-redux";

const mockDispatch = jest.fn();
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

configure({ adapter: new Adapter() });

describe("<TroubleSigninComponent /> with no props", () => {
  test("TroubleSigninComponent snapshot", () => {
    const snap = TestRenderer.create(<TroubleSigninComponent />).toJSON();
    expect(snap).toMatchSnapshot();
  });

  it("renders <TroubleSigninComponent/> components", () =>
    expect(shallow(<TroubleSigninComponent />)).toMatchSnapshot());

//   it("renders MONTH name field", () => {
//     const wrapper = mount(<TroubleSigninComponent />);
//     const innerWrap = wrapper.find("a").at(0);
//     expect(innerWrap.text()).toEqual("I forgot my password");
//   });

});