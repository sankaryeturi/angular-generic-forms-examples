/* eslint-disable */
import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, mount, ReactWrapper, configure } from "enzyme";
import SignUpPage from "../pages/signup/signUpPage";
import { Provider } from "react-redux";
import TestRenderer from "react-test-renderer";
import { useSelector, useDispatch } from "react-redux";

const mockDispatch = jest.fn();
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

configure({ adapter: new Adapter() });

describe("<SignUpPage /> with no props", () => {
  test("SignUpPage snapshot", () => {
    const snap = TestRenderer.create(<SignUpPage />).toJSON();
    expect(snap).toMatchSnapshot();
  });

  it("renders <SignUpPage/> components", () =>
    expect(shallow(<SignUpPage />)).toMatchSnapshot());

  // form submit
  it("form submit action", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("ValidatorForm");
    expect(innerWrap.simulate('click'));
  });

  // month field
  it("renders MONTH name field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("name")).toEqual("dobMonth");
  });
  it("renders MONTH type field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("type")).toEqual("number");
  });
  it("renders MONTH validation field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("validators"));
  });
  it("onchange in MONTH change field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).simulate('change'));
  });
  it("keyup in MONTH change field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).simulate('keyup'));
  });

  // day field
  it("renders DAY field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("name")).toEqual("dobDay");
  });
  it("renders DAY type field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("type")).toEqual("number");
  });
  it("renders DAY validation field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("validators"));
  });
  it("onchange in DAY change field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).simulate('change'));
  });
  it("keyup in DAY change field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).simulate('keyup'));
  });

  // year field
  it("renders YEAR field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("name")).toEqual("dobYear");
  });
  it("renders YEAR type field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("type")).toEqual("number");
  });
  it("renders YEAR validation field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("validators"));
  });
  it("onchange in YEAR change field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).simulate('change'));
  });
  it("keyup in YEAR change field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).simulate('keyup'));
  });

  //policy number field
  it("renders POLICY NUMBER field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(3).prop("name")).toEqual("policyNumber");
  });
  it("renders POLICY NUMBER type field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(3).prop("type")).toEqual("text");
  });
  it("renders POLICY NUMBER validation field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(3).prop("validators"));
  });
  it("renders POLICY NUMBER change field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(3).prop("change"));
  });

  //zipcode field
  it("renders ZIPCODE field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(4).prop("name")).toEqual("zipCode");
  });
  it("renders ZIPCODE type field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(4).prop("type")).toEqual("text");
  });
  it("renders ZIPCODE validation field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(4).prop("validators"));
  });
  it("renders ZIPCODE change field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(4).prop("change"));
  });

  // cancel button
  it("renders Cancel button field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(0).text()).toEqual("Cancel");
  });
  // submit button
  it("renders Submit button field", () => {
    const wrapper = mount(<SignUpPage />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(1).text()).toEqual("Continue");
  });

});