/* eslint-disable */
import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, mount, ReactWrapper, configure } from "enzyme";
import { Provider } from "react-redux";
import TestRenderer from "react-test-renderer";
import { useSelector, useDispatch } from "react-redux";
import { CommonService } from '../_services/commonServices';

const mockDispatch = jest.fn();
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

describe("CommonService", () => {
  it("should...", () => {
    const commonservices = new CommonService(); 
    const getUrgentMessages = CommonService.getUrgentMessages = jest.fn();
  });
});