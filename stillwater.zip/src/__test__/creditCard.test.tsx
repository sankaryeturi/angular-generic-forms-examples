/* eslint-disable */
import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, mount, ReactWrapper, configure } from "enzyme";
import CreditComponent from "../pages/payments/credit";
import { Provider } from "react-redux";
import TestRenderer from "react-test-renderer";
import { useSelector, useDispatch } from "react-redux";

const mockDispatch = jest.fn();
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

configure({ adapter: new Adapter() });

describe("<CreditComponent /> with no props", () => {
  test("CreditComponent snapshot", () => {
    const snap = TestRenderer.create(<CreditComponent />).toJSON();
    expect(snap).toMatchSnapshot();
  });

  it("renders <CreditComponent/> components", () =>
    expect(shallow(<CreditComponent />)).toMatchSnapshot());

  // Form check
  it("renders <ValidatorForm/> components", () => {
    const wrapper = mount(<CreditComponent />);
    expect(wrapper.exists("ValidatorForm")).toMatchSnapshot();
  });
  // Card Number Field validations
  it("renders Card Number field", () => {
    const wrapper = mount(<CreditComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("name")).toEqual("cardNumber");
  });
  // Card Holder Name Field validations
  it("renders Card Holder Name field", () => {
    const wrapper = mount(<CreditComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("name")).toEqual("cardHolderName");
  });
  // Month Field validations
  it("renders Month field", () => {
    const wrapper = mount(<CreditComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("name")).toEqual("month");
  });
  // Year Field validations
  it("renders Year field", () => {
    const wrapper = mount(<CreditComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(3).prop("name")).toEqual("year");
  });
  // CVV Field validations
  it("renders CVV field", () => {
    const wrapper = mount(<CreditComponent />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(4).prop("name")).toEqual("cvv");
  });
  // Billing Address Field validations
  // it("renders Billing Address field", () => {
  //   const wrapper = mount(<CreditComponent />);
  //   const innerWrap = wrapper.find("TextValidator").find("Radio");
  //   expect(innerWrap.at(0).prop("name")).toEqual("address");
  // });
  // cancel button
  it("renders Cancel button field", () => {
    const wrapper = mount(<CreditComponent />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(0).text()).toEqual("Cancel");
  });
  // submit button
  it("renders Submit button field", () => {
    const wrapper = mount(<CreditComponent />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(1).text()).toEqual("Submit Payment");
  });


});
