/* eslint-disable */
import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, mount, ReactWrapper, configure } from "enzyme";
import ChangePassword from "../pages/account-settings/changePassword";
import { Provider } from "react-redux";
import TestRenderer from "react-test-renderer";
import { useSelector, useDispatch } from "react-redux";

const mockDispatch = jest.fn();
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

configure({ adapter: new Adapter() });

describe("<ChangePassword /> with no props", () => {
  test("ChangePassword snapshot", () => {
    const snap = TestRenderer.create(<ChangePassword />).toJSON();
    expect(snap).toMatchSnapshot();
  });

  it("renders <ChangeEmail/> components", () =>
    expect(shallow(<ChangePassword />)).toMatchSnapshot());

  // Form check
  it("renders <ValidatorForm/> components", () => {
    const wrapper = mount(<ChangePassword />);
    expect(wrapper.exists("ValidatorForm")).toMatchSnapshot();
  });
  // form submit
  it("form submit action", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("ValidatorForm");
    expect(innerWrap.simulate('click'));
  })
  // Current password Field validations
  it("renders Current Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("name")).toEqual("currentPassword");
  });
  it("renders Current Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("type")).toEqual("password");
  });
  it("renders Current Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("validators"));
  });
  it("onchange in Current Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).simulate('change'));
  })
  // New Password Field validations
  it("renders New Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("name")).toEqual("newPassword");
  });
  it("renders New Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("type")).toEqual("password");
  });
  it("renders New Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("validators"));
  });
  it("onchange in New Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).simulate('change'));
  })
  // Confirm New Password Field validations
  it("renders Confirm New Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("name")).toEqual("confirmNewPassword");
  });  
  it("renders Confirm New Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("type")).toEqual("password");
  });
  it("renders Confirm New Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("validators"));
  });
  it("onchange in Confirm New Password field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).simulate('change'));
  })
  // cancel button
  it("renders Cancel button field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(0).text()).toEqual("Cancel");
  });
  // submit button
  it("renders Submit button field", () => {
    const wrapper = mount(<ChangePassword />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(1).text()).toEqual("Submit");
  });
});
