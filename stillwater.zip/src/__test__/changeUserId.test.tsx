/* eslint-disable */
import React from "react";
import Adapter from "enzyme-adapter-react-16";
import { shallow, mount, ReactWrapper, configure } from "enzyme";
import ChangeUserId from "../pages/account-settings/changeUserId";
import { Provider } from "react-redux";
import TestRenderer from "react-test-renderer";
import { useSelector, useDispatch } from "react-redux";

const mockDispatch = jest.fn();
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: () => mockDispatch,
}));

configure({ adapter: new Adapter() });

describe("<ChangeUserId /> with no props", () => {
  test("ChangeUserId snapshot", () => {
    const snap = TestRenderer.create(<ChangeUserId />).toJSON();
    expect(snap).toMatchSnapshot();
  });

  it("renders <ChangeUserId/> components", () =>
    expect(shallow(<ChangeUserId />)).toMatchSnapshot());

  // Form check
  it("renders <ValidatorForm/> components", () => {
    const wrapper = mount(<ChangeUserId />);
    expect(wrapper.exists("ValidatorForm")).toMatchSnapshot();
  });
  // form submit
  it("form submit action", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("ValidatorForm");
    expect(innerWrap.simulate('click'));
  })
  // Current Password Field validations
  it("renders Current Password field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("name")).toEqual("currentPassword");
  });
  it("renders Current Password field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("type")).toEqual("password");
  });
  it("renders Current Password field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(0).prop("validators"));
  });
  // New Userid Field validations
  it("renders New Userid field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("name")).toEqual("newUserid");
  });
  it("renders New Userid field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("type")).toEqual("text");
  });
  it("renders New Userid field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(1).prop("validators"));
  });
  // Confirm New Userid Field validations
  it("renders Confirm New Userid field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("name")).toEqual("confirmNewUserid");
  });
  it("renders Confirm New Userid field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("type")).toEqual("text");
  });
  it("renders Confirm New Userid field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("TextValidator");
    expect(innerWrap.at(2).prop("validators"));
  });
  // cancel button
  it("renders Cancel button field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(0).text()).toEqual("Cancel");
  });
  // submit button
  it("renders Submit button field", () => {
    const wrapper = mount(<ChangeUserId />);
    const innerWrap = wrapper.find("ValidatorForm");
    const btnWrap = innerWrap.find("button");
    expect(btnWrap.at(1).text()).toEqual("Submit");
  });


});
