const APP_BASE_URL = "https://localhost:8553/";
const QA_BASE_URL = "https://qua.stillwaterinsurance.com/";
// const QA_BASE_URL = "https://localhost:8553/";
// const APP_BASE_URL = "/";
// const QA_BASE_URL = "/";

/********** MOCK URLS ********/
const APP_URLS = {
  LOGIN: QA_BASE_URL + "Policy-api/v1/session/signin",
  LOGOUT: QA_BASE_URL + "Policy-api/v1/session/signout",
  CURRENT_MAIL_ADDRESS: "",
  GET_ALL_POLICIES: QA_BASE_URL + "Policy-api/v2/policy/list",
  GET_POLICY_DETAILS: QA_BASE_URL + "Policy-api/v2/policy/summary",
  CHANGE_EMAIL: QA_BASE_URL + "Policy-api/v2/account/email/change",
  CHANGE_PASSWORD: QA_BASE_URL + "Policy-api/v2/account/password/change/",
  CHANGE_USERID: QA_BASE_URL + "Policy-api/v2/account/username/update",
  SIGNUP_POLICY_INFO_CHECK:
    QA_BASE_URL + "Policy-api/v2/registry/account/check",
  SIGNUP_EMAIL_USERID_CHECK:
    QA_BASE_URL + "Policy-api/v2/registry/username/check",
  GET_QUESTOINS: QA_BASE_URL + "Policy-api/v2/registry/security/questions/list",
  BLANKETED_ALERTS: APP_BASE_URL + "Policy-api/v2/alerts/blanketed",
  TARGETED_ALERTS: APP_BASE_URL + "Policy-api/v2/alerts/targeted",
  GET_STATES: QA_BASE_URL + "Policy-api/v2/meta/state/list",
  GET_PROPERTYLOSSTYPE:
    APP_BASE_URL + "api/v1/claim/fnol/property/getLossTypeList",
  GET_PROPERTYLOSSCAUSELIST:
    APP_BASE_URL + "api/v1/claim/fnol/property/getLossCauseList",
  FORGOT_USERID: QA_BASE_URL + "Policy-api/v2/forgot/username",
  NOTE_ALERTS: APP_BASE_URL + "Policy-api/v2/notes",
  PAYMENT_HISTORY: QA_BASE_URL + "Policy-api/v2/policy/transaction/history",
  FORGOT_PASSWORD_CLIENTURL:
    QA_BASE_URL + "Policy-api/v2/forgot/password/reset/clientId",
  USER_SECURITY_QUESTIONS: QA_BASE_URL + "Policy-api/v2/forgot/password/reset/username",
  UPDATE_SECURITY_QUESTIONS: QA_BASE_URL + "Policy-api/v2/account/security/questions/update",
  FORGOT_PASSWORD_VERIFY_ANS:
    QA_BASE_URL + "Policy-api/v2/forgot/password/reset/verifyAnswers",
  GET_USER_EMAILID: QA_BASE_URL + "Policy-api/v2/account/email/",
  GET_USER_PHONENO: QA_BASE_URL + "Policy-api/v2/account/phoneNumbers/",
  CHANGE_PHONE_NO: QA_BASE_URL + "Policy-api/v2/account/phoneNumbers/update",
  GET_EDOCS_LIST: QA_BASE_URL + "Policy-api/v2/edoc/current",
  PAPERLESS_PREFERENCE:
    QA_BASE_URL + "Policy-api/v2/account/paperlessPreference/change",
  GET_MAILING_POLICIES: QA_BASE_URL + "Policy-api/v2/account/mailingAddresses",
  CHANGE_MAILING_ADDRESS:
    QA_BASE_URL + "Policy-api/v2/account/mailingAddress/update",
  GET_CLAIM_hISTORY: QA_BASE_URL + "Policy-api/v2/policy/fnol/claim/list",
  TERMS_CONDITIONS: QA_BASE_URL + "Policy-api/v2/registry/termcondition/get",
  FINAL_REGISTRATION: QA_BASE_URL + "Policy-api/v2/registry/user/add",
  GET_AUTOIDS_LIST: QA_BASE_URL + "Policy-api/v2/policy/idcard/data",
  GET_POLICY_DOCS: QA_BASE_URL + "Policy-api/v2/policy/documents",
  GET_HELPTEXT: QA_BASE_URL + "Policy-api/v2/policy/coverage/helptext",
  AUTOID_SEND_MAIL: QA_BASE_URL + "Policy-api/v2/policy/idcard/email",
  GET_USER_NORIFICATION_INFO: QA_BASE_URL + "Policy-api/v2/account/notificationPreference",
  UPDATE_NOTIFICATION_PREF: QA_BASE_URL + "Policy-api/v2/account/notificationPreference/change",
  EFT_SUBMIT: QA_BASE_URL + "Policy-api/v2/policy/payment/change"
};

export class URL {
  public static readonly LOGIN = APP_URLS.LOGIN;
  // public static readonly GET_PROFILE = APP_URLS.GET_PROFILE;
  public static readonly LOGOUT = APP_URLS.LOGOUT;
  public static readonly CURRENT_MAIL_ADDRESS = APP_URLS.CURRENT_MAIL_ADDRESS;
  public static readonly CHANGE_EMAIL = APP_URLS.CHANGE_EMAIL;
  public static readonly CHANGE_PASSWORD = APP_URLS.CHANGE_PASSWORD;
  public static readonly CHANGE_USERID = APP_URLS.CHANGE_USERID;
  public static readonly SIGNUP_POLICY_INFO_CHECK =
    APP_URLS.SIGNUP_POLICY_INFO_CHECK;
  public static readonly SIGNUP_EMAIL_USERID_CHECK =
    APP_URLS.SIGNUP_EMAIL_USERID_CHECK;
  public static readonly GET_QUESTOINS = APP_URLS.GET_QUESTOINS;
  public static readonly BLANKETED_ALERTS = APP_URLS.BLANKETED_ALERTS;
  public static readonly GET_ALL_POLICIES = APP_URLS.GET_ALL_POLICIES;
  public static readonly GET_POLICY_DETAILS = APP_URLS.GET_POLICY_DETAILS;
  public static readonly GET_STATES = APP_URLS.GET_STATES;
  public static readonly GET_PROPERTYLOSSTYPE = APP_URLS.GET_PROPERTYLOSSTYPE;
  public static readonly GET_PROPERTYLOSSCAUSELIST =
    APP_URLS.GET_PROPERTYLOSSCAUSELIST;
  public static readonly TARGETED_ALERTS = APP_URLS.TARGETED_ALERTS;
  public static readonly FORGOT_USERID = APP_URLS.FORGOT_USERID;
  public static readonly NOTE_ALERTS = APP_URLS.NOTE_ALERTS;
  public static readonly PAYMENT_HISTORY = APP_URLS.PAYMENT_HISTORY;
  public static readonly FORGOT_PASSWORD_CLIENTURL =
    APP_URLS.FORGOT_PASSWORD_CLIENTURL;
  public static readonly USER_SECURITY_QUESTIONS =
    APP_URLS.USER_SECURITY_QUESTIONS;
  public static readonly UPDATE_SECURITY_QUESTIONS = APP_URLS.UPDATE_SECURITY_QUESTIONS;
  public static readonly FORGOT_PASSWORD_VERIFY_ANS =
    APP_URLS.FORGOT_PASSWORD_VERIFY_ANS;
  public static readonly GET_USER_EMAILID = APP_URLS.GET_USER_EMAILID;
  public static readonly GET_USER_PHONENO = APP_URLS.GET_USER_PHONENO;
  public static readonly CHANGE_PHONE_NO = APP_URLS.CHANGE_PHONE_NO;
  public static readonly GET_EDOCS_LIST = APP_URLS.GET_EDOCS_LIST;
  public static readonly PAPERLESS_PREFERENCE = APP_URLS.PAPERLESS_PREFERENCE;
  public static readonly GET_MAILING_POLICIES = APP_URLS.GET_MAILING_POLICIES;
  public static readonly CHANGE_MAILING_ADDRESS =
    APP_URLS.CHANGE_MAILING_ADDRESS;
  public static readonly GET_CLAIM_hISTORY = APP_URLS.GET_CLAIM_hISTORY;
  public static readonly TERMS_CONDITIONS = APP_URLS.TERMS_CONDITIONS;
  public static readonly FINAL_REGISTRATION = APP_URLS.FINAL_REGISTRATION;
  public static readonly GET_AUTOIDS_LIST = APP_URLS.GET_AUTOIDS_LIST;
  public static readonly GET_POLICY_DOCS = APP_URLS.GET_POLICY_DOCS;
  public static readonly GET_HELPTEXT = APP_URLS.GET_HELPTEXT;
  public static readonly AUTOID_SEND_MAIL = APP_URLS.AUTOID_SEND_MAIL;
  public static readonly GET_USER_NORIFICATION_INFO = APP_URLS.GET_USER_NORIFICATION_INFO;
  public static readonly UPDATE_NOTIFICATION_PREF = APP_URLS.UPDATE_NOTIFICATION_PREF;
  public static readonly EFT_SUBMIT = APP_URLS.EFT_SUBMIT;

  public static dynamicUrl = APP_BASE_URL + "api/v1/";
  /** get cities list */
  public static getCities(stateCode: string) {
    return QA_BASE_URL + "Policy-api/v2/meta/city/list/" + stateCode;
  }
  /** submit a claim url */
  public static submitClaim(policyNumber: string) {
    return this.dynamicUrl + "claim/fnol/" + policyNumber + "/submitClaim";
  }
  /** change Phone Number URL */
  public static updatePolicyAlertsUrl(userId: string) {
    return this.dynamicUrl + "updatePolicyAlerts/" + userId;
  }
}
