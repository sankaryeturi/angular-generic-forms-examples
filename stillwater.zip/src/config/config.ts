import logo from "../assets/images/stillwater-home-logo.png";
import checkImage from "../assets/images/check.png";

export const resolutions = {
  xs: 0,
  sm: 600,
  md: 768,
  lg: 1280,
  xl: 1920,
};

export const constantValues = {
  validationLength_8: 8,
};
// global images
export const IMAGES = {
  logo: logo,
  check: checkImage
};
