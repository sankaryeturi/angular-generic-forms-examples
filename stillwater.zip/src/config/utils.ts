/* eslint-disable */
import { ValidateFunction } from "ajv";
import traverse from "react-traverse";

export function normalize(input: any) {
  try {
    traverse(input).forEach(function (this: any, val: any) {
      if (typeof val === "string") {
        let adj: string | null = val.trim();
        if (adj === "") adj = null;
        this.update(adj);
        return;
      }
    });
    return input;
  } catch (error) {
    console.log("Error: normaliza() - utils.ts", error);
  }
}

export function validate<T>(fn: ValidateFunction, input: object): T {
  if (!fn(input)) {
    console.error(fn.errors);
    //throw new Error('object failed to validate')
  }
  return (input as unknown) as T;
}
