import React from "react";
import ReactDOM from "react-dom";
import {
  createMuiTheme,
  MuiThemeProvider,
  CssBaseline,
} from "@material-ui/core";
import App from "./App";
import { Provider } from "react-redux";
import configureStore from "./_store/store";
import { resolutions } from "./config/config";

const app: any = document.querySelector("#root");
const method = app & app?.hasChildNodes() ? "hydrate" : "render";
// define dynamic resolutions
const breaktheme = createMuiTheme({
  breakpoints: {
    // Define custom breakpoint values.
    // These will apply to Material-UI components that use responsive
    // breakpoints, such as `Grid` and `Hidden`. You can also use the
    // theme breakpoint functions `up`, `down`, and `between` to create
    // media queries for these breakpoints
    values: {
      xs: resolutions.xs,
      sm: resolutions.sm,
      md: resolutions.md,
      lg: resolutions.lg,
      xl: resolutions.xl,
    },
  },
});

const store = configureStore();

ReactDOM[method](
  <Provider store={store}>
    <MuiThemeProvider theme={breaktheme}>
      {/* CssBaseline kickstart an elegant, consistent, and simple baseline to build upon. */}
      <CssBaseline />
      <App />
    </MuiThemeProvider>
  </Provider>,
  app
);
