import { standard } from "./standard";

export type ThemeBundle = typeof standard;
export type ThemeKey = keyof ThemeBundle;
export interface ThemeProps {
  theme: ThemeBundle;
}
