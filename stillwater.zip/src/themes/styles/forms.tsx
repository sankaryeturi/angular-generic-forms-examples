import styled from "styled-components";

export const SspformGroup = styled.div`
  margin: 8px 0 20px 0;
  &.month, &.day {
    max-width:60px;
    display:inline-block;
    margin-right: 15px;
  }
  &.year {
    max-width: 80px;
    display:inline-block;
  }
  input,
  select,
  .select-field {
    background-color: ${(props) => props.theme.white};
    width: 100%;
    padding: 12px 20px;
    display: inline-block;
    border: 0px;
    border-bottom: 2px solid ${(props) => props.theme.darkBlue};
    border-radius: 3px 3px 0px 0px;
    box-sizing: border-box;
    height: 55px;
  }
  textarea {
    background-color: ${(props) => props.theme.white};
    width: 100%;
  }
  label {
    letter-spacing: 0px;
    color: ${(props) => props.theme.black};
    font-weight: bold;
    &.label-bold {
      font: normal normal bold 16px/24px Source Sans Pro;
    }
    text-transform: capitalize;
  }

  &.gray {
    input {
      background-color: ${(props) => props.theme.appBG};
    }
  }
  .select-field.gray {
    background-color: ${(props) => props.theme.appBG};
  }
  &.input50 {
    input,
    select,
    .select-field {
      height: 50px;
      padding-left: 10px;
      font: 16px/20px Source Sans Pro;
    }
    .MuiSelect-root {
      padding-top: 0;
    }
  }
  .height-30 {
    height: 30px;
  }
  .password-strength {
    position: initial;
  }
  &.rightTopRadius0 {
    input {
      border-top-right-radius: 0;
    }
  }
  .MuiInput-underline:before {
    border-bottom: 0px solid rgba(0, 0, 0, 0.42);
  }
  p.Mui-error {
    font-size: 0.75rem !important;
  }

  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    input {
      //background: #F0F0F0;
      border-radius: 0;
    }
    select {
      font-size: 16px;
      font-weight: 600;
    }
  }
`;

export const PasswordRules = styled.div`
  margin: 16px 0 0 0;
  padding: 5px 10px;
  display: inline-block;

  li {
    span.success {
      margin-right: 5px;
      margin-left: 4px;
    }
    span.success:before {
      content: "";
      border: solid black;
      border-width: 0 2px 2px 0;
      border-color: ${(props) => props.theme.hashDark};
      display: inline-block;
      padding: 3px;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
      width: 8px;
      height: 15px;
      border-color: ${(props) => props.theme.green};
    }
    span.danger {
      margin-right: 16px;
    }
    span.danger:before,
    span.danger:after {
      position: absolute;
      left: 15px;
      content: " ";
      height: 13px;
      width: 2px;
      background-color: red;
    }
    span.danger:before {
      transform: rotate(45deg);
      margin-top: 4px;
    }
    span.danger:after {
      transform: rotate(-45deg);
      margin-top: 4px;
    }
  }
  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    position: relative;
    margin: 16px 0 0 0;
  }
`;

export const ErrorMessage = styled.span`
  font-weight: bold;
  &.orange {
    color: ${(props) => props.theme.orange};
  }
`;
