export const buttonMixin = (
  bgcolor,
  color,
  padding,
  border,
  borderradius,
  width,
  fontWeight,
  minHeight
) => {
  return `
        background: ${bgcolor};
        color: ${color};
        padding: ${padding};
        border: ${border};
        border-radius: ${borderradius};
        width: ${width};
        font-weight: ${fontWeight};
        min-height: ${minHeight}
    `;
};
