import styled from "styled-components";
import { css } from "styled-components";

const buttonMixin = (
  bgcolor,
  color,
  padding,
  border,
  borderradius,
  fontWeight,
  minHeight
) => {
  return `
        background: ${bgcolor};
        color: ${color};
        padding: ${padding};
        border: ${border};
        border-radius: ${borderradius};        
        font-weight: ${fontWeight};
        min-height: ${minHeight}
    `;
};
const disabledMixin = css`
  color: ${(props) => props.theme.white};
  background-color: ${(props) => props.theme.hash};
`;
export const Bluebutton = styled.button`
  ${buttonMixin("#0099CC", "#ffffff", "0.5rem", "0", "3px", "bold", "48px")};
  &:hover {
    cursor: pointer;
  }
  &.w-100 {
    width: 100%;
  }
  &.w-20 {
    width: 20%;
  }
  &.w-25 {
    width: 25%;
  }
  &.min-w150 {
    min-width: 150px;
  }
  &.w-auto {
    width: auto;
  }
  &.h-40 {
    min-height: 40px;
  }
  &.h-20 {
    min-height: 20px;
  }
  &.uppercase {
    text-transform: uppercase;
  }
  @media screen and (max-width: 767px) {
    /* margin-right: 3%;
     width: 100%; */
    margin-bottom: 10px;
  }
`;
export const Darkbluebutton = styled.button`
  ${buttonMixin("#003399", "#ffffff", "14px", "0", "3px", "bold", "48px")};
  &:hover {
    cursor: pointer;
  }
  &.w-20 {
    width: 20%;
  }
  &.w-25 {
    width: 25%;
  }
  &.min-w150 {
    min-width: 150px;
  }
  &.disabled {
    ${disabledMixin};
  }
`;
export const OrangeButton = styled.button`
  ${buttonMixin(
    "#FF6600 0% 0% no-repeat padding-box",
    "#ffffff",
    "14px",
    "0",
    "3px",
    "bold",
    "48px"
  )};
  &.shadow {
    box-shadow: 3px 3px 6px #0000008f;
  }
  &.w-25 {
    width: 25%;
  }
  &.p25-30 {
    padding: 15px 30px;
  }
`;
export const Whitebutton = styled.button`
  background-color: ${(props) => props.theme.white};
  border: 1px solid ${(props) => props.theme.hash};
  border-radius: 3px;
  padding: 5px 25px;
  margin-right: 10px;
  color: ${(props) => props.theme.darkBlue};
  font-weight: bold;
  height: 48px;
  &.dark-blue-border {
    border-color: ${(props) => props.theme.darkBlue};
  }
  &.orange-border {
    border-color: ${(props) => props.theme.orange};
  }
  &.orange-color {
    color: ${(props) => props.theme.orange};
  }
  &.uppercase {
    text-transform: uppercase;
  }
  &:hover {
    cursor: pointer;
  }
  &.h-40 {
    height: 40px;
  }
  &.h-35 {
    height: 35px;
  }
  &.min-w350 {
    min-width: 350px;
  }
  @media screen and (max-width: 992px) {
    padding: 5px 5px;
  }
`;
export const CancelLineBtn = styled.button`
  border: 0;
  background: none;
  text-decoration: underline;
  color: ${(props) => props.theme.darkBlue};
  font: Bold 14px/20px Source Sans Pro;
  &:hover {
    cursor: pointer;
  }
`;
export const Anchor = styled.a`
  display: flex;
  justify-content: center;
  align-items: center;
  text-decoration: none;

  &.w-100 {
    width: 100%;
  }
  &.text-left {
    justify-content: start;
  }
  &.dark-blue {
    color: ${(props) => props.theme.darkBlue};
  }
  &.bold {
    font-weight: bold;
  }
  &.underline {
    text-decoration: underline;
  }
`;
export const Sspbluebutton = styled.button`
  background-color: ${(props) => props.theme.darkBlue};
  color: ${(props) => props.theme.white};
  padding: 15px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  border-radius: 3px;
  &.w-auto {
    width: auto;
  }
`;
export const BlueBorderBtn = styled.button`
  ${buttonMixin(
    "#ffffff",
    "#003399",
    "0.5rem",
    "1px solid #003399",
    "3px",
    "400",
    "10px"
  )};
  font: Regular 16px/24px Source Sans Pro;
  &.bold {
    font: Bold 16px/20px Source Sans Pro;
  }
  .angle-icon-adjust {
    vertical-align: bottom;
    background-size: 18px;
  }
`;
export const GrayButton = styled.button`
  ${buttonMixin(
    "#EFEFEF",
    "#003399",
    "0.5rem",
    "1px solid #EFEFEF",
    "3px",
    "400",
    "10px"
  )};
  &.bottom-radious-0 {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
  }
`;
export const CustomButton = styled.button``;
