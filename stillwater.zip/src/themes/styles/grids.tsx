import styled from "styled-components";
import { Dflexcenter } from "./common";
import cargray from "../../assets/images/icons/car-gray.svg";
import homeDisabled from "../../assets/images/icons/home-disabled.svg";
import homeDarkBlue from "../../assets/images/icons/home-alt.svg";
import carDarkBlue from "../../assets/images/icons/car-dark-blue.svg";
import userwhite from "../../assets/images/icons/user-white.svg";
import lockwhite from "../../assets/images/icons/lock-white.svg";
import buildingBlue from "../../assets/images/icons/building-blue.svg";
import buildingBlack from "../../assets/images/icons/building-black-medium.svg";
import signalstreamwhite from "../../assets/images/icons/signal-stream-white.svg";
import houseDamageGray from "../../assets/images/icons/house-damage-gray.svg";
import carPacificBlue from "../../assets/images/icons/car-pacific-blue.svg";
import homeAltPacificBlue from "../../assets/images/icons/home-alt-pacific-blue.svg";
import buildingPacificBlueMedium from "../../assets/images/icons/building-pacific-blue-medium.svg";

export const Blueheadinggrid = styled.div`
  border-radius: 3px;
  margin-bottom: 20px;
  margin-right: 20px;
  &.min-height-auto {
    > .content {
      min-height: auto;
    }
  }
  .content {
    padding: 15px 25px;
    min-height: 360px;
    heignt: 100%;
    background: ${(props) => props.theme.hashLight};
    &.white {
      background-color: ${(props) => props.theme.white};
    }
    &.h-250 {
      min-height: 250px;
    }
    p {
      font-size: 1rem;
    }

    .buttons-block {
      width: 80%;
      margin: 30px auto;
    }

    .display-flex {
      display: flex;
      padding-bottom: 15px;
    }
    .display-flex-p {
      display: flex;
      padding-bottom: 12px;
      justify-content: space-between;
      font: Bold 16px/20px Source Sans Pro;
      &.orange {
        color: ${(props) => props.theme.orange};
      }
    }
    .PrivateSwitchBase-root-1 {
      padding: 0 9px;
    }
    .ssp-orange {
      background: ${(props) => props.theme.orange};
      color: ${(props) => props.theme.white};
      border-radius: 3px;
    }
    .tablecontainer {
      width: 98%;
    }
    .transaction {
      text-decoration: underline;
      font: Bold 16px/20px Source Sans Pro;
      letter-spacing: 0px;
      color: ${(props) => props.theme.darkBlue};
    }
    .paymentButton {
      display: flex;
      align-items: center;
      margin: 32px;
    }
    .heading-color {
      font: Bold 16px/20px Source Sans Pro;
      letter-spacing: 0px;
      color: ${(props) => props.theme.darkBlue};
      font-size: 16px;
    }
    .paragraph-color {
      font: Bold 14px/18px Source Sans Pro;
      letter-spacing: 0px;
      color: ${(props) => props.theme.black};
      font-size: 14px;
    }

    @media screen and (max-width: 767px) {
      .buttons-block {
        width: 100%;
        margin: 30px auto 0 auto;
      }
    }
  }
  .heading {
    background-color: ${(props) => props.theme.darkBlue};
    padding: 15px 25px;
    color: ${(props) => props.theme.white};
    text-transform: uppercase;
    border-radius: 3px 3px 0px 0px;
    h3 {
      margin: 0;
    }
    .user-icon {
      background-image: url(${userwhite});
      background-repeat: no-repeat;
      background-position: 10% 50%;
      padding: 10px 15px 10px 20px;
    }
    .lock-icon {
      background-image: url(${lockwhite});
      background-repeat: no-repeat;
      background-position: 10% 50%;
      padding: 10px 15px 10px 20px;
    }
    .signal-icon {
      background-image: url(${signalstreamwhite});
      background-repeat: no-repeat;
      background-position: 10% 50%;
      padding: 10px 30px 10px 20px;
    }
  }

  @media screen and (max-width: 767px) {
    margin-right: 0;
    .content {
      min-height: inherit;
    }
  }
`;

export const Blueheading = styled.div`
  background: ${(props) => props.theme.hashLight};
  border-radius: 3px;
  .content {
    padding: 15px 25px;
    min-height: 360px;
    heignt: 100% p {
      font-size: 1rem;
    }
  }
  .heading {
    background-color: ${(props) => props.theme.darkBlue};
    padding: 15px 25px;
    color: ${(props) => props.theme.white};
    text-transform: uppercase;
    border-radius: 3px 3px 0px 0px;
    h3 {
      margin: 0;
    }
  }

  @media screen and (max-width: 767px) {
    margin-right: 0;
    .content {
      min-height: inherit;
    }
  }
`;
export const Insurancegridtype = styled.div`
  border-radius: 3px;
  text-align: center;
  color: ${(props) => props.theme.hashDark};
  background-color: ${(props) => props.theme.white};
  margin-bottom: 20px;

  &.full-border {
    .content {
      border-bottom: 2px solid;
    }
  }
  .content {
    padding: 10px 10px;
    min-height: auto;
    font-weight: 600;
    border: 2px;
    border-color: ${(props) => props.theme.hashDark};
    border-style: solid;
    border-bottom: 0;
    font: Bold 14px/16px Source Sans Pro;
    &.border-bottem {
      border-bottom: 2px solid ${(props) => props.theme.hashDark};
    }
    .icon {
      height: 30px;
      background-position: center;
      background-repeat: no-repeat;
      margin-bottom: 10px;
      width: 100%;
    }

    .car-icon {
      background-image: url(${cargray});
    }
    .home-icon {
      background-image: url(${homeDisabled});
    }
    .building {
      background-image: url(${buildingBlack});
    }
    .renters {
      background-image: url(${buildingBlack});
    }
    .umbrella {
      background-image: url(${buildingBlack});
    }
    .landlord {
      background-image: url(${buildingBlack});
    }
    .earthquake {
      background-images: url(${houseDamageGray});
    }
    &.banner-grid {
      .car-icon {
        background-image: url(${carPacificBlue});
      }
      .home-icon {
        background-image: url(${homeAltPacificBlue});
      }
      .building {
        background-image: url(${buildingPacificBlueMedium});
      }
      .renters {
        background-image: url(${buildingPacificBlueMedium});
      }
      .umbrella {
        background-image: url(${buildingPacificBlueMedium});
      }
      .landlord {
        background-image: url(${buildingBlack});
      }
      .earthquake {
        background-images: url(${houseDamageGray});
      }
    }
  }
  &.active {
    .content {
      border-color: ${(props) => props.theme.darkBlue};
      color: ${(props) => props.theme.darkBlue};
      .border-bottem {
        border-bottom: 2px solid ${(props) => props.theme.darkBlue};
      }
      .car-icon {
        background-image: url(${carDarkBlue});
      }
      .home-icon {
        background-image: url(${homeDarkBlue});
      }
      .building {
        background-image: url(${buildingBlue});
      }
      .renters {
        background-image: url(${buildingBlack});
      }
      .umbrella {
        background-image: url(${buildingBlack});
      }
      .landlord {
        background-image: url(${buildingBlack});
      }
      .earthquake {
        background-images: url(${houseDamageGray});
      }
    }
  }
  .footer {
    background-color: ${(props) => props.theme.darkBlue};
    padding: 5px 12px;
    min-height: 50px;
    a {
      color: ${(props) => props.theme.white};
    }
  }

  &.banner-grid {
    .content {
      border-color: ${(props) => props.theme.pacificBlue};
      color: ${(props) => props.theme.pacificBlue};
    }
    .footer {
      background-color: ${(props) => props.theme.pacificBlue};
    }
    &.active {
      .content {
        border-color: ${(props) => props.theme.darkBlue};
        color: ${(props) => props.theme.darkBlue};
      }
      .footer {
        background-color: ${(props) => props.theme.darkBlue};
      }
    }
  }

  &.disabled {
    .content {
      border-color: ${(props) => props.theme.hashDark};
    }
    color: ${(props) => props.theme.hashDark};
  }
  &.shortlinks {
    min-height: 75px;
    text-transform: uppercase;
    .content {
      min-height: inherit;
      border-color: ${(props) => props.theme.darkBlue};
      &.dflexcenter {
        ${Dflexcenter};
      }
    }
    .footer {
      padding: 3px 12px;
      max-height: 40px;
      min-height: 40px;
      display: flex;
      justify-content: center;
      align-items: center;

      a {
        text-decoration: none;
      }
    }
  }
  @media screen and (max-width: 767px) {
    .footer {
      padding: 10px 10px;
    }
  }
  @media screen and (max-width: 1299px) {
    .content {
      padding: 10px 10px;
    }
  }
`;

export const SuccessBlock = styled.div`
  background-color: ${(props) => props.theme.white};
  border: 1px solid ${(props) => props.theme.green};
`