import styled from "styled-components";
import { standard } from "../standard";

const semiBold = "Bold 17px/24px Work Sans semi bold";
const headingMixin = (color, font, textTransform?, textAlign?) => {
  return `
    color: ${color};
    font: ${font};
    margin: 0;
    text-transform: ${textTransform};
    text-align: ${textAlign};
  `;
};
export const Darkblueheadingh3 = styled.h3`
  ${headingMixin(
    `${standard.darkBlue}`,
    "24px/30px Work Sans Extra Bold",
    "uppercase"
  )}
`;
export const Darkblueheadingh4 = styled.h4`
  ${headingMixin(
    `${standard.darkBlue}`,
    "20px/30px Work Sans Extra Bold",
    "capitalize",
    "center"
  )}
`;
export const Darkblueheadingh5 = styled.h5`
  ${headingMixin(
    `${standard.darkBlue}`,
    "Bold 18px/32px Work Sans semi bold",
    "uppercase"
  )}
  &.extra-bold {
    font: Bold 18px/32px Work Sans Extra bold
  }
  &.capitalize {
    text-transform: capitalize;
  }
`;
export const PacificBlueh3 = styled.h3`
  font: 20px/30px Work Sans Extra Bold;
  color: ${(props) => props.theme.pacificBlue};
  margin: 0;
  text-transform: uppercase;
  &.text-transform-inherit {
    text-transform: inherit;
  }
`;
export const Blueh6title = styled.h6`
  color: ${(props) => props.theme.darkBlue};
  font-size: 16px;
  margin: 0;
`;
export const DarkBlueh5title = styled.h6`
  font: Bold 16px/20px Source Sans Pro;
  color: ${(props) => props.theme.darkBlue};
  margin: 0;
`;

export const GreenHeading = styled.h4`
  color: ${(props) => props.theme.green};
  font: Bold 20px/24px Work Sans Extra Bold;
  margin: 0;
`;
