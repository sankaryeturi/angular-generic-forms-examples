import styled from "styled-components";

export const OrangeText = styled.span`
  color: ${(props) => props.theme.orange};
`;
