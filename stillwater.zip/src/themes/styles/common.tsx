import styled from "styled-components";
import { css } from "styled-components";
import setting from "../../assets/images/icons/setting.svg";
import carBlack from "../../assets/images/icons/car-black.svg";
import homeBlack from "../../assets/images/icons/home-black.svg";
import hotelBlack from "../../assets/images/icons/hotel-black.svg";
import buildingBlack from "../../assets/images/icons/building-black.svg";
import shieldCheckBlack from "../../assets/images/icons/shield-check-black.svg";
import houseDamageBlack from "../../assets/images/icons/house-damage-black.svg";

const borderMixin = (bordersize, borderstyle, bordercolor, borderradius) => {
  return `
    border: ${bordersize} ${borderstyle} ${bordercolor};
    border-radius: ${borderradius};
  `;
};

export const Dflexcenter = css`
  display: flex;
  align-items: center;
  justify-content: center;
`;
export const DashboardAlerts = styled.div`
  float: left;
  .ssp-list {
    box-shadow: 3px 3px 4px #00000029;
    border: 1px solid ${(props) => props.theme.darkBlue};
    display: inline-block;
    padding: 20px 40px 20px 30px;
    position: relative;
    margin-right: 1rem;
    margin-bottom: 1rem;
    a {
      color: ${(props) => props.theme.darkBlue};
      font-weight: bold;
    }
    ._closebtn {
      position: absolute;
      right: 5px;
      top: 5px;
    }
    .policy-type-name {
      min-width: 48px;
      width: 100%;
      max-width: 45px;
      display: inline-flex;
      overflow: hidden;
    }
    .claim-number {
      white-space: nowrap;
      width: 52px;
      overflow: hidden;
      text-overflow: ellipsis;
      display: inline-block;
      vertical-align: bottom;
    }
  }
  @media screen and (min-width: ${(props) =>
      props.theme.tabMin}) and (max-width: 850px) {
    .ssp-list {
      padding: 20px 30px 20px 20px;
      .policy-type-name {
        min-width: 40px;
        max-width: 40px;
      }
    }
  }
  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    margin-right: 0;
    width: 90%;
    margin: 0 auto;
    float: inherit;
    max-width: 350px;
    > div {
      width: 100%;
    }
    :first-child {
      margin-top: 10px;
    }
  }
`;
export const Appbodycontainer = styled.div`
  background-color: ${(props) => props.theme.appBG};
  padding-top: 10px;
  padding-bottom: 10px;
  > div {
    max-width: 85.4%;
    margin: 0 auto;
    padding: 10px 25px;
    background-color: ${(props) => props.theme.white};
    @media only screen and (max-width: ${(props) => props.theme.mobileMax}) {
      max-width: 88.4%;
    }
    @media only screen and (min-width: ${(props) =>
        props.theme.tabMin}) and (max-width: ${(props) => props.theme.tabMax}) {
      max-width: 90%;
    }
  }

  .dark-label {
    color: ${(props) => props.theme.black};
    font-weight: bold;
  }
  .page-title {
    color: ${(props) => props.theme.darkBlue};
    .back-button {
      display: inline-block;
      vertical-align: bottom;
    }
    .setting-icon {
      background-repeat: no-repeat;
      background-position: 10% 50%;
      padding: 10px 15px 10px 20px;
      background-size: 30px 30px;
    }
    .setting-img {
      width: 30px;
      height: 30px;
      margin-right: 1rem;
    }
    h3 {
      display: inline-block;
      margin-top: 0;
      font-size: 1.5rem;
      margin: 0;
      vertical-align: top;
      text-transform: uppercase;
      font-family: "Work Sans Extra Bold";
    }
    .pacific-blue-heading {
      text-transform: uppercase;
      margin-top: 0;
      margin-bottom: 0;
      /* margin-left: 5.2%; */
      color: ${(props) => props.theme.pacificBlue};
      font: Bold 20px/24px Work Sans Extra Bold;
    }
  }
  .white-block {
    height: 300px;
    background-color: white;
  }
  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    padding-top: 0;
    background-color: ${(props) => props.theme.white};
    > div {
      max-width: 100%;
      &.mobile-fullLayout {
        padding: 0 0;
      }
    }
    .page-title {
      .back-button {
        font-size: 1rem;
        vertical-align: sub;
        svg {
          font-size: 1.5rem !important;
        }
      }
      h3 {
        vertical-align: top;
      }
      .setting-img {
        width: 20px;
        height: 20px;
        margin-right: 0.7rem;
      }
    }
  }
`;
export const Settingicon = styled.span`
  background-image: url(${setting});
`;

const backgroundicon = (icon) => {
  return `
    background-image: url(${icon});
    background-repeat: no-repeat;   
    `;
};

export const ListwithIcons = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
  li {
    background-position: 0 50%;
    background-size: 20px;
    padding: 10px 10px 10px 35px;
    &.ssp-carblackicon {
      ${backgroundicon(`${carBlack}`)}
    }
    &.ssp-homeblackicon {
      ${backgroundicon(`${homeBlack}`)}
    }
    &.ssp-hotelblackicon {
      ${backgroundicon(`${hotelBlack}`)}
    }
    &.ssp-buildingblackicon {
      ${backgroundicon(`${buildingBlack}`)}
    }
    &.ssp-umbrellablackicon {
      ${backgroundicon(`${shieldCheckBlack}`)}
    }
    &.ssp-homedamageblackicon {
      ${backgroundicon(`${houseDamageBlack}`)}
    }
  }
`;
export const DarkblueLink = styled.a`
  color: ${(props) => props.theme.darkBlue};
  &.bold {
    font-weight: bold;
  }
  &.label-right {
    position: absolute;
    right: 0;
    top: -5px;
    z-index: 9;
  }
  &.underline {
    text-decoration: underline;
  }
`;

export const InformationSummary = styled.div`
  font: Regular 16px/32px Source Sans Pro;
  .darkblue-color {
    font: Bold 16px/20px Source Sans Pro;
    color: ${(props) => props.theme.darkBlue};
  }
`;

/** Border blocks */
export const Blueborder = styled.div`
  ${borderMixin("1px", "solid", "#003399", "3px")};
  background-color: ${(props) => props.theme.white};
  color: ${(props) => props.theme.black};
  &.active {
    color: ${(props) => props.theme.darkBlue};
  }
`;
export const PacificBlueborder = styled.div`
  ${borderMixin("1px", "solid", "#0099CC", "3px")};
  background-color: ${(props) => props.theme.white};

  .font16Bold {
    font: normal normal bold 16px/24px Source Sans Pro;
  }
`;
