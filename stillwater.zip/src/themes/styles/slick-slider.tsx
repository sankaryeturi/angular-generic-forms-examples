import styled from "styled-components";

export const CarouselSlider = styled.div`
  &.banner-slider {
    .slick-track {
      margin: 0 auto 0 auto;
    }
    .slick-arrow {
      border-radius: 50%;
    }
    .slick-next {
      right: -60px;
    }
    .slick-prev {
      left: -60px;
    }
    .slick-next,
    .slick-prev {
      top: 40%;
      width: 45px;
      height: 45px;
    }

    .slick-next:focus,
    .slick-next:hover,
    .slick-prev:focus,
    .slick-prev:hover {
      /* background: #e0e0e0; */
    }

    .slick-next.slick-disabled:before,
    .slick-prev.slick-disabled:before {
      opacity: 0.5;
    }

    .slick-prev:before,
    .slick-next:before {
      border: solid white;
      border-width: 0 4px 4px 0;
      width: 17px;
      height: 17px;
      opacity: 1;
    }

    @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
      display: none;
    }

    @media screen and (min-width: ${(props) =>
        props.theme.tabMin}) and (max-width: ${(props) => props.theme.tabMax}) {
      display: inherit;
      /* width: 80% !important; */
      .slick-prev {
        left: -9% !important;
      }
      .slick-next {
        right: -9% !important;
      }
    }
    @media screen and (min-width: ${(props) =>
        props.theme.desktopMin}) and (max-width: ${(props) =>
        props.theme.desktopMidPoint}) {
      /* width: 65% !important; */
      .slick-prev {
        left: -9% !important;
      }
      .slick-next {
        right: -9% !important;
      }
    }
  }

  &.policy-slider {
    .slick-next {
      right: -10px;
    }
    .slick-prev {
      left: -20px;
    }
    .slick-list {
      padding-left: 10px;
    }
  }

  .slick-list,
  .slick-slider,
  .slick-track {
    position: relative;
    display: block;
  }
  .slick-loading .slick-slide,
  .slick-loading .slick-track {
    visibility: hidden;
  }
  .slick-slider {
    box-sizing: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-touch-callout: none;
    -khtml-user-select: none;
    -ms-touch-action: pan-y;
    touch-action: pan-y;
    -webkit-tap-highlight-color: transparent;
  }
  .slick-list {
    overflow: hidden;
    margin: 0;
    padding: 0;
    /*padding-left: 10px;*/
  }
  .slick-list:focus {
    outline: 0;
  }
  .slick-list.dragging {
    cursor: pointer;
    cursor: hand;
  }
  .slick-slider .slick-list,
  .slick-slider .slick-track {
    -webkit-transform: translate3d(0, 0, 0);
    -moz-transform: translate3d(0, 0, 0);
    -ms-transform: translate3d(0, 0, 0);
    -o-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
  .slick-track {
    top: 0;
    left: 0;
    margin: 0 auto 0 0;
  }
  .slick-track:after,
  .slick-track:before {
    display: table;
    content: "";
  }
  .slick-track:after {
    clear: both;
  }
  .slick-slide {
    display: none;
    float: left;
    height: 100%;
    min-height: 1px;
  }
  [dir="rtl"] .slick-slide {
    float: right;
  }
  .slick-slide img {
    display: block;
  }
  .slick-slide.slick-loading img {
    display: none;
  }
  .slick-slide.dragging img {
    pointer-events: none;
  }
  .slick-initialized .slick-slide {
    display: block;
  }
  .slick-vertical .slick-slide {
    display: block;
    height: auto;
    border: 1px solid transparent;
  }
  .slick-arrow.slick-hidden {
    display: none;
  }
  /*# sourceMappingURL=slick.min.css.map */

  .slick-dots,
  .slick-next,
  .slick-prev {
    position: absolute;
    display: block;
    padding: 0;
  }
  .slick-dots li button:before,
  .slick-next:before,
  .slick-prev:before {
    font-family: slick;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #000;
  }

  .slick-next,
  .slick-prev {
    font-size: 0;
    line-height: 0;
    top: 45%;
    width: 20px;
    height: 20px;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%);
    cursor: pointer;
    color: transparent;
    border: none;
    outline: 0;
    background: 0 0;
  }
  .slick-next:focus,
  .slick-next:hover,
  .slick-prev:focus,
  .slick-prev:hover {
    color: transparent;
    outline: 0;
  }
  .slick-next:focus:before,
  .slick-next:hover:before,
  .slick-prev:focus:before,
  .slick-prev:hover:before {
    opacity: 1;
  }
  .slick-next.slick-disabled:before,
  .slick-prev.slick-disabled:before {
    opacity: 0.15;
  }
  .slick-next:before,
  .slick-prev:before {
    font-size: 20px;
    line-height: 1;
    opacity: 0.75;
    color: #000;
  }
  .slick-prev {
    left: -25px;
    padding-left: 16px;
  }
  [dir="rtl"] .slick-prev {
    right: -47px;
    left: auto;
  }
  .slick-prev:before {
    content: "";
    border: solid black;
    border-width: 0 3px 3px 0;
    display: inline-block;
    padding: 3px;
    transform: rotate(135deg);
    -webkit-transform: rotate(135deg);
    width: 13px;
    height: 13px;
  }
  .slick-next:before,
  [dir="rtl"] .slick-prev:before {
    content: "";
    content: "";
    border: solid black;
    border-width: 0 3px 3px 0;
    display: inline-block;
    padding: 3px;
    transform: rotate(-45deg);
    -webkit-transform: rotate(-45deg);
    width: 13px;
    height: 13px;
  }
  .slick-next {
    right: -25px;
    padding-right: 16px;
  }
  [dir="rtl"] .slick-next {
    right: auto;
    left: -47px;
  }
  [dir="rtl"] .slick-next:before {
    content: "→";
  }
  .slick-dotted.slick-slider {
    margin-bottom: 30px;
  }
  .slick-dots {
    bottom: -25px;
    width: 100%;
    margin: 0;
    list-style: none;
    text-align: center;
  }
  .slick-dots li {
    position: relative;
    display: inline-block;
    width: 20px;
    height: 20px;
    margin: 0 5px;
    padding: 0;
    cursor: pointer;
  }
  .slick-dots li button {
    font-size: 0;
    line-height: 0;
    display: block;
    width: 20px;
    height: 20px;
    padding: 5px;
    cursor: pointer;
    color: transparent;
    border: 0;
    outline: 0;
    background: 0 0;
  }
  .slick-dots li button:focus,
  .slick-dots li button:hover {
    outline: 0;
  }
  .slick-dots li button:focus:before,
  .slick-dots li button:hover:before {
    opacity: 1;
  }
  .slick-dots li button:before {
    font-size: 6px;
    line-height: 20px;
    position: absolute;
    top: 0;
    left: 0;
    width: 20px;
    height: 20px;
    content: "â€¢";
    text-align: center;
    opacity: 0.15;
    color: #000;
  }
  .slick-dots li.slick-active button:before {
    opacity: 0.75;
    color: #000;
  }
`;
