import styled from "styled-components";
import signOut from "../../assets/images/icons/sign-out.svg";
import userHeadset from "../../assets/images/icons/user-headset.svg";
import setting from "../../assets/images/icons/setting.svg";
import clipboardCheck from "../../assets/images/icons/clipboard-check.svg";
import clipboardCheckBig from "../../assets/images/icons/clipboard-check-big.svg";
import walletBlue from "../../assets/images/icons/wallet-blue.svg";
import walletBlueBig from "../../assets/images/icons/wallet-blue-big.svg";
import homeBlack from "../../assets/images/icons/home-black.svg";
import clipboardListCheckWhite from "../../assets/images/icons/clipboard-list-check-white.svg";
import piggyBankWhite from "../../assets/images/icons/piggy-bank-white.svg";
import usersWhite from "../../assets/images/icons/users-white.svg";
import carWhite from "../../assets/images/icons/car-alt-white.svg";
import wallet from "../../assets/images/icons/wallet.svg";
import shieldWhite from "../../assets/images/icons/shield-alt-white.svg";
import addressCardBlue from "../../assets/images/icons/address-card-blue.svg";
import userPlusBlue from "../../assets/images/icons/user-plus-blue.svg";
import fileAlt from "../../assets/images/icons/file-alt.svg";
import fileAltBlue from "../../assets/images/icons/file-alt-blue.svg";
import angleDownWhite from "../../assets/images/icons/angle-down-white.svg";
import angleUpWhite from "../../assets/images/icons/angle-up-white.svg";
import angleLeftWhite from "../../assets/images/icons/angle-left-white.svg";
import barsBlue from "../../assets/images/icons/bars-blue.svg";
import barsWhite from "../../assets/images/icons/bars-white.svg";
import plusBlue from "../../assets/images/icons/plus-blue.svg";
import carBlack from "../../assets/images/icons/car-black.svg";
import sortWhite from "../../assets/images/icons/sort-white.svg";
import infoBlue from "../../assets/images/icons/info.svg";
import traficBlue from "../../assets/images/icons/traffic-cone-blue.svg";
import traficRed from "../../assets/images/icons/traffic-cone-red.svg";
import traficGray from "../../assets/images/icons/traffic-cone-gray.svg";
import traficGreen from "../../assets/images/icons/traffic-cone-green.svg";
import angleDownBlue from "../../assets/images/icons/angle-down-blue.svg";
import angleUpBlue from "../../assets/images/icons/angle-up-blue.svg";
import closeCircleBlue from "../../assets/images/icons/times-circle.svg";
import closeCircleDisable from "../../assets/images/icons/close-circle-disable.svg";
import checkGreen from "../../assets/images/icons/check-green.svg";
import buildingBlack from "../../assets/images/icons/building-black.svg";
import homeDarkBlue from "../../assets/images/icons/home-alt.svg";
import carDarkBlue from "../../assets/images/icons/car-dark-blue.svg";
import buildingBlueSmall from "../../assets/images/icons/building-blue-small.svg";
import shieldCheckWhiteBG from "../../assets/images/icons/shield-check-white-bg.svg";
import homeWhiteSmokePipe from "../../assets/images/icons/home-white-smoke-pipe.svg";
import openBookWhite from "../../assets/images/icons/book-open-white.svg";
import clipboardListCheckBlue from "../../assets/images/icons/clipboard-list-check-blue.svg";
import folderOpenBlue from "../../assets/images/icons/folder-open-blue.svg";
import signinWhite from "../../assets/images/icons/sign-in-white.svg";
import downloadWhite from "../../assets/images/icons/download-white.svg";
import printWhite from "../../assets/images/icons/print-white.svg";
import printBlue from "../../assets/images/icons/print-blue.svg";
import paperPlaneWhite from "../../assets/images/icons/paper-plane-white.svg";
import paperclip from "../../assets/images/icons/paperclip.svg";
import hotelWhiteSmall from "../../assets/images/icons/hotel-white-small.svg";
import buildingWhite from "../../assets/images/icons/building.svg";
import buildingWhiteSmall from "../../assets/images/icons/building-white-small.svg";
import lifeRingBlue from "../../assets/images/icons/life-ring-blue.svg";
import toolboxBlue from "../../assets/images/icons/toolbox-blue.svg";
import steeringWheelBlue from "../../assets/images/icons/steering-wheel-blue.svg";
import filePdfBlue from "../../assets/images/icons/file-pdf-blue.svg";
import anniversaryImage from "../../assets/images/anniversary.png";

const backgroundicon = (icon, position, padding) => {
  return `
    background-image: url(${icon});
    background-repeat: no-repeat;
    background-position: ${position};
    padding: ${padding};
    `;
};
const padding10151020 = "10px 15px 10px 20px";
const padding10101020 = "10px 10px 10px 20px";
const padding1020 = "10px 20px 10px 20px";
const padding1215 = "12px 15px 12px 15px";
const padding1015 = "10px 15px";
const padding10 = "10px";
const bgPosition1050 = "10% 50%";

export const ThemeIcon = styled.span`
  &.ssp-userheadseticon {
    ${backgroundicon(userHeadset, bgPosition1050, padding10151020)}
  }
  &.ssp-settingicon {
    ${backgroundicon(setting, bgPosition1050, padding10151020)}
  }
  &.ssp-logouticon {
    ${backgroundicon(`${signOut}`, bgPosition1050, padding10151020)}
  }
  &.ssp-clipboardcheck {
    ${backgroundicon(
      `${clipboardCheck}`,
      bgPosition1050,
      "10px 15px 10px 15px"
    )}
  }
  &.ssp-clipboardcheck-big-icon {
    ${backgroundicon(
      `${clipboardCheckBig}`,
      bgPosition1050,
      "10px 15px 10px 15px"
    )}
  }
  &.ssp-homeblackicon,
  &.home-icon {
    ${backgroundicon(`${homeBlack}`, bgPosition1050, padding10101020)}
    background-size: 20px;
  }
  &.ssp-carblackicon,
  &.car-icon {
    ${backgroundicon(`${carBlack}`, bgPosition1050, padding10101020)}
    background-size: 20px;
  }
  &.ssp-walletblue-icon {
    ${backgroundicon(`${walletBlue}`, bgPosition1050, padding10151020)}
  }
  &.ssp-walletblue-big-icon {
    ${backgroundicon(`${walletBlueBig}`, bgPosition1050, padding10151020)}
  }
  &.wallet-white-icon {
    ${backgroundicon(`${wallet}`, bgPosition1050, padding10151020)}
  }
  &.clipboard-list-check-white {
    ${backgroundicon(
      `${clipboardListCheckWhite}`,
      bgPosition1050,
      padding10151020
    )}
  }
  &.piggy-bank-white-icon {
    ${backgroundicon(`${piggyBankWhite}`, bgPosition1050, padding10151020)}
  }
  &.users-white-icon {
    ${backgroundicon(`${usersWhite}`, bgPosition1050, padding10151020)}
  }
  &.car-alt-white-icon {
    ${backgroundicon(`${carWhite}`, bgPosition1050, padding10151020)}
    &.padding-1020 {
      padding: 10px 20px;
    }
  }
  &.shield-alt-white-icon {
    ${backgroundicon(`${shieldWhite}`, bgPosition1050, padding10151020)}
  }
  &.shield-check-whiteBg-icon {
    ${backgroundicon(`${shieldCheckWhiteBG}`, bgPosition1050, padding10151020)}
  }
  &.address-card-blue-icon {
    ${backgroundicon(`${addressCardBlue}`, bgPosition1050, padding1020)}
  }
  &.user-plus-blue-icon {
    ${backgroundicon(`${userPlusBlue}`, bgPosition1050, padding10151020)}
  }
  &.file-alt-icon {
    ${backgroundicon(`${fileAlt}`, bgPosition1050, padding10101020)}
  }
  &.info-blue-icon {
    ${backgroundicon(`${infoBlue}`, bgPosition1050, "10px 10px 10px 5px")}
  }
  &.file-alt-blue-icon {
    ${backgroundicon(`${fileAltBlue}`, bgPosition1050, padding10101020)}
  }
  &.angle-down-white-icon {
    ${backgroundicon(`${angleDownWhite}`, bgPosition1050, padding10101020)}
  }
  &.angle-up-white-icon {
    ${backgroundicon(`${angleUpWhite}`, bgPosition1050, padding10101020)}
  }
  &.angle-left-white-icon {
    ${backgroundicon(`${angleLeftWhite}`, bgPosition1050, padding10101020)}
  }
  &.bars-blue-icon {
    ${backgroundicon(`${barsBlue}`, bgPosition1050, padding10101020)}
    min-height: 30px;
  }
  &.bars-white-icon {
    ${backgroundicon(`${barsWhite}`, bgPosition1050, padding10101020)}
    min-height: 30px;
  }
  &.plus-blue-icon {
    ${backgroundicon(`${plusBlue}`, "50% 50%", padding10101020)}
    &.bg-size50 {
      background-size: 50%;
    }
  }
  &.ssp-sort-white {
    ${backgroundicon(`${sortWhite}`, bgPosition1050, padding10101020)}
    background-size: 12px;
  }
  &.trafic-blue-icon {
    ${backgroundicon(`${traficBlue}`, bgPosition1050, padding10101020)}
  }
  &.trafic-red-icon {
    ${backgroundicon(`${traficRed}`, bgPosition1050, padding10101020)}
  }
  &.trafic-gray-icon {
    ${backgroundicon(`${traficGray}`, bgPosition1050, padding10101020)}
  }
  &.trafic-green-icon {
    ${backgroundicon(`${traficGreen}`, bgPosition1050, padding10101020)}
  }
  &.angle-down-blue-icon {
    ${backgroundicon(`${angleDownBlue}`, bgPosition1050, padding10101020)}
  }
  &.angle-up-blue-icon {
    ${backgroundicon(`${angleUpBlue}`, bgPosition1050, padding10101020)}
  }
  &.close-circle-blue-icon {
    ${backgroundicon(`${closeCircleBlue}`, bgPosition1050, padding10101020)}
  }
  &.close-circle-disable-icon {
    ${backgroundicon(`${closeCircleDisable}`, bgPosition1050, padding10101020)}
  }
  &.check-green-icon {
    ${backgroundicon(`${checkGreen}`, bgPosition1050, padding10101020)}
  }
  &.building-black-icon,
  &.renters {
    ${backgroundicon(`${buildingBlack}`, bgPosition1050, padding10101020)}
  }
  &.umbrella {
    ${backgroundicon(`${buildingBlack}`, bgPosition1050, padding10101020)}
  }
  &.home-dark-blue,
  &.home-icon&.active {
    ${backgroundicon(`${homeDarkBlue}`, bgPosition1050, padding10101020)}
  }
  &.car-dark-blue,
  &.car-icon&.active {
    ${backgroundicon(`${carDarkBlue}`, bgPosition1050, padding10101020)}
  }
  &.building-blue,
  &.renters&.active {
    ${backgroundicon(`${buildingBlueSmall}`, bgPosition1050, padding10101020)}
  }
  &.home-white-smoke-pipe-icon {
    ${backgroundicon(`${homeWhiteSmokePipe}`, bgPosition1050, padding1020)}
  }
  &.open-book-icon {
    ${backgroundicon(`${openBookWhite}`, bgPosition1050, padding1020)}
  }
  &.clipboard-list-check-blue-icon {
    ${backgroundicon(
      `${clipboardListCheckBlue}`,
      bgPosition1050,
      padding10101020
    )}
  }
  &.folder-open-blue-icon {
    ${backgroundicon(`${folderOpenBlue}`, bgPosition1050, padding1020)}
  }
  &.signin-icon {
    ${backgroundicon(`${signinWhite}`, bgPosition1050, padding1020)}
  }
  &.download-white-icon {
    ${backgroundicon(`${downloadWhite}`, bgPosition1050, padding1020)}
  }
  &.print-white-icon {
    ${backgroundicon(`${printWhite}`, bgPosition1050, padding1020)}
  }
  &.print-blue-icon {
    ${backgroundicon(`${printBlue}`, bgPosition1050, padding1020)}
  }
  &.paper-plane-white-icon {
    ${backgroundicon(`${paperPlaneWhite}`, bgPosition1050, padding1020)}
  }
  &.paperclip-icon {
    ${backgroundicon(`${paperclip}`, bgPosition1050, padding10)}
  }
  &.hotel-white-icon {
    ${backgroundicon(`${hotelWhiteSmall}`, bgPosition1050, padding10)}
  }
  &.building-white-icon {
    ${backgroundicon(`${buildingWhiteSmall}`, bgPosition1050, padding10)}
  }
  &.life-ring-blue-icon {
    ${backgroundicon(`${lifeRingBlue}`, bgPosition1050, padding1015)}
  }
  &.toolbox-blue-icon {
    ${backgroundicon(`${toolboxBlue}`, bgPosition1050, padding1015)}
  }
  &.steering-wheel-blue-icon {
    ${backgroundicon(`${steeringWheelBlue}`, bgPosition1050, padding1015)}
  }
  &.file-pdf-blue-icon {
    ${backgroundicon(`${filePdfBlue}`, bgPosition1050, padding1215)}
  }
  &.padding1215 {
    padding: ${padding1215};
  }
  &.padding1015 {
    padding: ${padding1015};
  }
  &.medium-size {
    height: 40px;
  }
  &.bg-small {
    background-size: 20px;
  }
  &.bg-very-small {
    background-size: 15px;
  }
`;

export const BlueRibbon = styled.div`
  background-image: url(${anniversaryImage});
  background-repeat: no-repeat;
  background-position: 93% 50%;
  width: 60px;
  height: 100px;
  display: inline-block;
  color: ${(props) => props.theme.white};
  font-weight: bold;
  .number {
    padding-top: 15px;
    font-size: 18px;
    line-height: 16px;
  }
`;
