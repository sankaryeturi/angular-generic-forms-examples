import styled from "styled-components";

export const Dialogpopup = styled.div`
  padding: 20px;
  border: 2px solid #ff6600;
  width: 100%;
  .title {
  }
`;

export const PopupBlock = styled.div`
  width: 50%;
  display: flex;
  padding: 16px 32px 24px;
  position: absolute;
  box-shadow: 0px 3px 5px -1px rgba(0,0,0,0.2), 0px 5px 8px 0px rgba(0,0,0,0.14), 0px 1px 14px 0px rgba(0,0,0,0.12);
  align-items: center;
  justify-content: center;
  background-color: #fff;
  top: 40%;
  left: 50%;
  transform: translate(-50%, -50%);
  .close-icon {
    top: 25px;
    right: 20px;
    position: absolute;
  }
  &.guidanceCheckPopup {
    width: 40%;
  }
`