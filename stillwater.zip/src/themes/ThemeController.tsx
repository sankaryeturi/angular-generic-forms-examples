import React, { createContext, ReactElement, ReactNode, useState } from "react";
import { standard } from "./standard";
import { ThemeBundle } from "./ThemeBundle";

interface ThemeControllerProps {
  children: ReactNode;
}

interface ThemeState {
  readonly theme: ThemeBundle;
}

const initialState: ThemeState = {
  theme: standard,
};

export const ThemeContext = createContext(initialState);

export function ThemeController(props: ThemeControllerProps): ReactElement {
  const [state] = useState(initialState);

  return (
    <ThemeContext.Provider value={state}>
      {props.children}
    </ThemeContext.Provider>
  );
}
