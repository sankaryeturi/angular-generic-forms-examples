import React from "react";
import { Route, Redirect } from "react-router-dom";

export function useAppContext() {
  return localStorage.getItem("isAuthenticated");
}

export function AuthenticatedRoute({ children, ...rest }) {
  const isAuthenticated = useAppContext();
  return (
    <Route {...rest}>
      {isAuthenticated ? children : <Redirect to={`/login`} />}
    </Route>
  );
}

export function UnauthenticatedRoute({ children, ...rest }) {
  const isAuthenticated = useAppContext();
  return (
    <Route {...rest}>{!isAuthenticated ? children : <Redirect to="/" />}</Route>
  );
}
