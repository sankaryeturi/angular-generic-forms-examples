export const GETSIGNUPPOLICYINFO = "GETSIGNUPPOLICYINFO";
export const UPDATESIGNUPPOLICYINFO = "UPDATESIGNUPPOLICYINFO";

export const getSignupPolicies = () => {
  return { type: GETSIGNUPPOLICYINFO };
};

export const updateSignupPolicy = (payload: any) => {
  return { type: UPDATESIGNUPPOLICYINFO, payload };
};
