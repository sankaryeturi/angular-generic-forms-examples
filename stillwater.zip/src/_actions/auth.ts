export const GETAUTHENTICATION = "GETAUTHENTICATION";
export const UPDATEAUTHENTICATION = "UPDATEAUTHENTICATION";
export const CLEARAUTHENTICATION = "CLEARAUTHENTICATION";

export const getAuthentication = () => {
  return { type: GETAUTHENTICATION };
};

export const updateAuthentication = (payload) => {
  return { type: UPDATEAUTHENTICATION, payload };
};

export const clearAuthentication = () => {
  return { type: CLEARAUTHENTICATION };
};
