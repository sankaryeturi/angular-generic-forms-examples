const GETPOLICYALERTS = "GETPOLICYALERTS";
const UPDATEPOLICYALERTS = "UPDATEPOLICYALERTS";
const CLEARPOLICYALERTS = "CLEARPOLICYALERTS";

/**
 * get the policy alerts
 * @param payload
 */
export const getPolicyAlerts = (payload: any) => {
  return { type: GETPOLICYALERTS, payload };
};

/**
 * update the policy Alerts
 * @param payload
 */
export const updatePolicyAlerts = (payload: any) => {
  return { type: UPDATEPOLICYALERTS, payload };
};
/**
 * clear the Policy Alerts
 */
export const clearPolicyAlerts = () => {
  return { type: CLEARPOLICYALERTS };
};
