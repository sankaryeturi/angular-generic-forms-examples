export const GETPOLICIES = "GETPOLICIES";
export const UPDATEPOLICIES = "UPDATEPOLICIES";
export const CLEARPOLICIES = "CLEARPOLICIES";

/**
 * get policies list
 */
export const getPolicies = () => {
  return { type: GETPOLICIES };
};
/**
 * update the policies
 * @param payload
 */
export const updatePolicies = (payload: any) => {
  return { type: UPDATEPOLICIES, payload };
};
/**
 *
 * @param payload
 */
export const clearPolicies = () => {
  return { type: CLEARPOLICIES };
};
