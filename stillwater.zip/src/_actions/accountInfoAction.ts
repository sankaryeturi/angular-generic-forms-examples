export const GETCURRENTMAILINGADDRESS = "GETCURRENTMAILINGADDRESS";
export const UPDATECURRENTMAILINGADDRESS = "UPDATECURRENTMAILINGADDRESS";
export const GETUSERPROFILE = "GETUSERPROFILE";
export const UPDATEUSERPROFILE = "UPDATEUSERPROFILE";
export const LOGOUT = "LOGOUT";

/** */
export const getCurrentMailingAddress = () => {
  return { type: GETCURRENTMAILINGADDRESS };
};
/** */
export const updateCurrentMailinAddress = (payload: any) => {
  return { type: UPDATECURRENTMAILINGADDRESS, payload };
};
/** get user profile */
export const getUserProfile = () => {
  return { type: GETUSERPROFILE };
};
/** update user profile */
export const updateUserProfile = (payload: any) => {
  return { type: UPDATEUSERPROFILE, payload };
};
/** logout */
export const logoutAction = () => {
  return { type: LOGOUT };
};
