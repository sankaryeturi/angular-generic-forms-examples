const GETIMPORTANTALERTS = "GETIMPORTANTALERTS";
const UPDATEIMPORTANTALERTS = "UPDATEIMPORTANTALERTS";
const GETTARGETEDALERTS = "GETTARGETEDALERTS";
const UPDATETARGETEDALERTS = "UPDATETARGETEDALERTS";
const CLEARTARGETEDALERTS = "CLEARTARGETEDALERTS";

/**
 * get important alerts
 */
export const getImportantAlerts = () => {
  return { type: GETIMPORTANTALERTS };
};
/**
 * update important alerts
 */
export const updateImportantAlerts = (payload: any) => {
  return { type: UPDATEIMPORTANTALERTS, payload };
};
/**
 * get targeted alerts
 */
export const getTargetedAlerts = () => {
  return { type: GETTARGETEDALERTS };
};
/**
 * update targeted alerts
 */
export const updatedTargetedAlerts = (payload: any) => {
  return { type: UPDATETARGETEDALERTS, payload };
};
/**
 * clear targeted alerts
 */
export const clearTargetedAlerts = () => {
  return { type: CLEARTARGETEDALERTS };
};
