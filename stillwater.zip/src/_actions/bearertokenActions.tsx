export const GETBEARERTOKEN = "GETBEARERTOKEN";
export const UPDATEBEARERTOKEN = "UPDATEBEARERTOKEN";
export const CLEARBREADCRUMB = "CLEARBREADCRUMB";
/**
 * get the bearertoken
 * @param payload
 */
export const getbearertoken = (payload: any) => {
  return { type: GETBEARERTOKEN, payload };
};
/**
 * update the bearertoken
 * @param payload
 */
export const updatebearertoken = (payload: any) => {
  return { type: UPDATEBEARERTOKEN, payload };
};
/**
 * clear the bearertoken
 */
export const clearbearertoken = () => {
  return { type: CLEARBREADCRUMB };
};
