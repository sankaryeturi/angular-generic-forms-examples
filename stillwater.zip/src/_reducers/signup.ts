const initialState = {
  signupInfo: [],
};

const signupReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case "GETSIGNUPPOLICYINFO":
      return { signupInfo: action.payload };
    case "UPDATESIGNUPPOLICYINFO":
      return { ...state, signupInfo: action.payload };
    default:
      return state;
  }
};

export default signupReducer;
