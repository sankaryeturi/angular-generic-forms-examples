const dashboardState = {
  policyAlerts: [],
};

const dashboardReducer = (state = dashboardState, action: any) => {
  switch (action.type) {
    case "GETPOLICYALERTS":
      return { ...state };
    case "UPDATEPOLICYALERTS":
      return { ...state, policyAlerts: action.payload };
    case "CLEARPOLICYALERTS":
      return { ...state, policyAlerts: [] };
    default:
      return state;
  }
};

export default dashboardReducer;
