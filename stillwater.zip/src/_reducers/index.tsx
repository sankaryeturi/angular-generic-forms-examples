import { combineReducers } from "redux";

import bearertokenReducer from "./bearertokenReducer";
import policiesReducer from "./policiesReducer";
import accountInfoReducer from "./accountInfoReducer";
import signupReducer from "./signup";
import importantAlertsReducer from "./importantAlertsReducer";
import dashboardReducer from "./dashboardPageReducer";
import authReducer from "./authReducer";

const appReducers = combineReducers({
  bearertokenReducer,
  policiesReducer,
  accountInfoReducer,
  signupReducer,
  importantAlertsReducer,
  dashboardReducer,
  authReducer,
});

export default appReducers;
