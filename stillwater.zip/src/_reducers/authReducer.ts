const isAuthenticated: any = false;

const authReducer = (state = isAuthenticated, action: any) => {
  switch (action.type) {
    case "GETAUTHENTICATION":
      return { ...state };
    case "UPDATEAUTHENTICATION":
      return { ...state, isAuthenticated: action.payload };
    case "CLEARAUTHENTICATION":
      return { ...state };
    default:
      return state;
  }
};

export default authReducer;
