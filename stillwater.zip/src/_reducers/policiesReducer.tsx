const initialState = {
  policis: [],
};

const policiesReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case "GETPOLICIES":
      return { policis: action.payload };
    case "UPDATEPOLICIES":
      return { ...state, policis: action.payload };
    case "CLEARPOLICIES":
      return { ...state, policis: [] };
    default:
      return state;
  }
};

export default policiesReducer;
