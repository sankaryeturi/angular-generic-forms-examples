const initialState = {
  currentMailingAddress: [],
  profile: [],
};

const accountInfoReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case "GETCURRENTMAILINGADDRESS":
      return { ...state };
    case "UPDATECURRENTMAILINGADDRESS":
      return { ...state, currentMailingAddress: action.payload };
    case "GETUSERPROFILE":
      return { ...state };
    case "UPDATEUSERPROFILE":
      return { ...state, profile: action.payload };
    default:
      return state;
  }
};

export default accountInfoReducer;
