const initialState = {
  alerts: [],
  targetedAlerts: [],
};

const importantAlertsReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case "GETIMPORTANTALERTS":
      return { alerts: action.payload };
    case "UPDATEIMPORTANTALERTS":
      return { ...state, alerts: action.payload };
    case "GETTARGETEDALERTS":
      return { targetedAlerts: action.payload };
    case "UPDATETARGETEDALERTS":
      return { ...state, targetedAlerts: action.payload };
    case "CLEARTARGETEDALERTS":
      return { ...state, targetedAlerts: [] };
    default:
      return state;
  }
};
export default importantAlertsReducer;
