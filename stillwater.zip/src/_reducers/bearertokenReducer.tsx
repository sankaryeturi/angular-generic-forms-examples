const bearerState = {
  token: "",
};
const bearertokenReducer = (state = bearerState, action: any) => {
  switch (action.type) {
    case "GETBEARERTOKEN":
      return { ...state };
    case "UPDATEBEARERTOKEN":
      return { ...state, token: action.payload };
    case "CLEARBREADCRUMB":
      return { ...state };
    default:
      return state;
  }
};

export default bearertokenReducer;
