import React, { ReactElement, useContext, useState, useEffect } from "react";
import { SspformGroup } from "../../themes/styles";
import { InputLabel, Select, MenuItem } from "@material-ui/core";
import { Visibility, VisibilityOff } from "@material-ui/icons";
import {
  FormControl,
  Input,
  InputAdornment,
  IconButton,
  makeStyles,
} from "@material-ui/core";
import { standard } from "../../themes/standard";

/** page styles */
const useStyles = makeStyles({
  /** password icon */
  eyeIcon: {
    backgroundColor: standard.white,
    display: "inline-table",
    marginLeft: "0",
    borderBottom: `2px solid ${standard.darkBlue}`,
  },
});

export default function SecurityQuestionsComponent(props: any): ReactElement {
  const classes = useStyles();

  // updating the question change
  const handleQuestionChange = (e, index) => {
    const value = e.target.value;
    props.handleQuestionChange(value, index);
  };

  // updating answer
  const handleAnswer = (e, index) => {
    const value = e.target.value;
    props.handleAnswer(value, index);
  };

  // password toggle
  const handleClickShowPassword = (index, e) => {
    props.ShowPassword(index);
  };
  const questoinsCount = [0, 1, 2];
  return (
    <div>
      {questoinsCount &&
        questoinsCount?.map((list: any, i) => {
          return (
            <div className="ssp-mt60" key={i}>
              <SspformGroup
                theme={props.theme}
                className={`${props.inputClass} input50`}
              >
                <InputLabel shrink>
                  {props.bundle["label.securityQuestion"]} {i + 1}
                </InputLabel>
                <Select
                  className={`${props.inputClass} select-field`}
                  value={list.value}
                  onChange={(e) => handleQuestionChange(e, i)}
                >
                  {props.questionsList.map((question, j) => {
                    return (
                      <MenuItem value={question} key={j} selected={question?.text === props?.userAttempts[i]?.question}>
                        {question.text}
                      </MenuItem>
                    );
                  })}
                </Select>
              </SspformGroup>

              <SspformGroup
                theme={props.theme}
                className={`${props.inputClass} input50 rightTopRadius0`}
              >
                <FormControl fullWidth>
                  <label>
                    {props.bundle["label.answer"]} {i + 1}
                  </label>
                  <Input
                    className="ssp-mt0"
                    type={!list.showPasswordField ? "text" : "password"}
                    value={props?.userAttempts[i]?.answer}
                    onChange={(e) => handleAnswer(e, i)}
                    required
                    endAdornment={
                      props?.iconState === "show" && (
                        <InputAdornment
                          position="end"
                          className={classes.eyeIcon}
                        >
                          <IconButton
                            onClick={(e) => handleClickShowPassword(i, e)}
                            onMouseDown={(e) => e.preventDefault}
                          >
                            {list?.showPasswordField ? (
                              <Visibility />
                            ) : (
                              <VisibilityOff />
                            )}
                          </IconButton>
                        </InputAdornment>
                      )
                    }
                  />
                </FormControl>
              </SspformGroup>
            </div>
          );
        })}
    </div>
  );
}
