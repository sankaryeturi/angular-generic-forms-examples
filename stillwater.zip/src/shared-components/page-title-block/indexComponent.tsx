import React, { ReactElement } from "react";
import { ArrowBackIos } from "@material-ui/icons";
import { Hidden } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import { ThemeIcon } from "../../themes/styles";

export default function PageTitleComponent(props): ReactElement {
  const history = useHistory();

  function navigation() {
    history.go(-1);
  }

  return (
    <div className="page-title ssp-mt3">
      <div className="ssp-inline-block">
        <Hidden smDown>
          <a onClick={navigation} className="ssp-inline-block">
            <ArrowBackIos fontSize="large" className="ssp-mr2" />
          </a>
        </Hidden>
        <ThemeIcon
          className={`ssp-inline-block medium-size ssp-mr2 ${props.iconName}`}
        ></ThemeIcon>
      </div>
      <div className="ssp-inline-block ssp-w85 ssp-valign-top">
        <h3 className="ssp-pt1">{props.pageTitle}</h3>
        {props.subTitle && (
          <h4 className="pacific-blue-heading">{props.subTitle}</h4>
        )}
      </div>
    </div>
  );
}
