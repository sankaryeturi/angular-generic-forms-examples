import React, { useContext } from "react";
import { LocalizationContext } from "../../locales";
import { ThemeContext } from "../../themes";
import { Pagefooter } from "./styles";

function Footer() {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);

  return (
    <Pagefooter theme={theme}>
      <div className="dflexcenter">
        <img
          alt=""
          title=""
          src={require("../../assets/images/authorize-net.png")}
        />
        <img
          alt=""
          title=""
          src={require("../../assets/images/NortonSeal.png")}
        />
      </div>
      <p>{bundle["footer.rightsContent"]}</p>
      {/* <i className="material-icons">lock</i> */}
      <div>
        <a href="/">{bundle["footer.privacyLink"]}</a> |{" "}
        <a href="/">{bundle["footer.securityPolicy"]}</a>
      </div>
    </Pagefooter>
  );
}

export default Footer;
