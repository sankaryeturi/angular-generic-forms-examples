import styled from "styled-components";
import { Dflexcenter } from "../../themes/styles/common";

export const Pagefooter = styled.div`
  text-align: center;
  padding: 30px 0;
  font-family: "Source Sans Pro", sans-serif;
  font-size: 13px;
  .dflexcenter {
    ${Dflexcenter};
  }
  a {
    color: ${(props) => props.theme.darkBlue};
    text-decoration: none;
  }

  @media screen and (max-width: 767px) {
    border-top: 2px solid #d6d6d6;
  }
`;
