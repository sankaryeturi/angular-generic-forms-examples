import styled from "styled-components";
import banner from "../../assets/images/component.png";

export const Homebanner = styled.div`
  color: ${(props) => props.theme.white};
  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    background: ${(props) => props.theme.white};
  }
  @media screen and (min-width: ${(props) => props.theme.tabMin}) {
    background: ${(props) => props.theme.pacificBlue} 0% 0% no-repeat
      padding-box;
  }
`;

export const Bannercontainer = styled.div`
  max-width: ${(props) => props.theme.containerWidth};
  margin: 0 auto;
  background-image: url(${banner});
  background-repeat: no-repeat;
  background-position: right;
  height: 100%;

  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    max-width: 100%;
    background-image: none;
  }
`;

export const Easyaccess = styled.div`
  background: ${(props) => props.theme.whitergb};
  text-align: center;
  padding: 0 0 4% 0;
  > div {
    color: ${(props) => props.theme.black};
    padding: 7px 0;
    font-weight: 600;
  }
`;

export const Bluebutton = styled.button`
  background: ${(props) => props.theme.pacificBlue};
  border-radius: 3px;
  opacity: 1;
  border: 0;
  color: ${(props) => props.theme.white};
  padding: 0.5rem;
  width: 155px;
  font-weight: bold;
  min-height: 48px;
  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    margin-right: 3%;
    display: block;
    width: 100%;
    margin-bottom: 10px;
  }
`;

export const Bannerquicklinks = styled.div`
  background: #ffffff66 0% 0% no-repeat padding-box;
  border: 2px solid ${(props) => props.theme.white};
  border-radius: 3px;
  opacity: 1;
  min-height: 50px;
  margin-right: 16px;
  margin-bottom: 16px;
  text-align: center;
  padding: 6%;
  span {
    font: Bold 16px/20px Source Sans Pro;
    letter-spacing: 1px;
  }
  @media screen and (min-width: ${(props) => props.theme.tabMin}) {
    max-height: 127px;
    height: 100%;
    min-height: 100px;
  }
`;
