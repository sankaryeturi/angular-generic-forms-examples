import React, { ReactElement, useContext } from "react";
import Grid from "@material-ui/core/Grid";
import Hidden from "@material-ui/core/Hidden";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import { LoginComponent } from "../login/login";
import { LoginController } from "../login/logincontroller";
import {
  Homebanner,
  Bannercontainer,
  Easyaccess,
  Bluebutton,
  Bannerquicklinks,
} from "./bannerStyles";
import { ThemeIcon } from "../../themes/styles";
import LogoComponent from "../logo/logo";
import { Link } from "react-router-dom";

export default function BannerComponent(): ReactElement {
  const { bundle } = useContext(LocalizationContext);
  const { theme } = useContext(ThemeContext);
  const imageInfo = {
    logoName: "stillwater-logo-horiz@2x-new.png",
    logoPath: "images/",
    altContent: bundle["image.logocontext"],
    titleContent: bundle["image.logocontext"],
  };

  const aboutPoliciesList = [
    {
      imageName: "car.svg",
      text: bundle["text.bannerAutoInsurance"],
    },
    {
      imageName: "home.svg",
      text: bundle["text.bannerHomeInsurance"],
    },
    {
      imageName: "building.svg",
      text: bundle["text.bannerRentInsurance"],
    },
    {
      imageName: "shield-check.svg",
      text: bundle["text.bannerUmbrellaInsurance"],
    },
  ];

  return (
    <Homebanner theme={theme}>
      <Bannercontainer theme={theme}>
        <Grid container>
          <Grid item xs={12} md={5} lg={4}>
            <Hidden smDown>
              <LogoComponent {...imageInfo} />
            </Hidden>

            <div className="ssp-loginblock">
              <div className="ssp-loginformblock">
                <h2>{bundle?.login?.manage}</h2>
                {/* Login form */}
                <LoginController>
                  <LoginComponent />
                </LoginController>
              </div>
              <Easyaccess theme={theme}>
                <div>{bundle?.login?.easyaccesscontext}</div>
                <div>
                  <Link to="/edocs">
                    <Bluebutton type="button" theme={theme} className="ssp-mr2">
                      <ThemeIcon className="file-alt-icon"></ThemeIcon>
                      {bundle["button.edocs"]}
                    </Bluebutton>
                  </Link>

                  <Bluebutton type="button" theme={theme}>
                    <ThemeIcon className="wallet-white-icon"></ThemeIcon>
                    {bundle?.button?.makepay}
                  </Bluebutton>
                </div>
              </Easyaccess>
            </div>
          </Grid>
          <Grid
            item
            xs={12}
            md={7}
            lg={8}
            className="ssp-bannerimage ssp-bg-blue-sm"
          >
            <Grid container>
              <Grid item xs={12}>
                <div className="ssp-bannerrightblock">
                  <h1>
                    <span className="ssp-h1span1">
                      {bundle["heading.bannerheading1"]}
                    </span>
                    <span className="ssp-h1span2">
                      {bundle["heading.bannerheading2"]}
                    </span>
                  </h1>
                  <div className="ssp-p4">
                    <Grid container>
                      <Grid item xs={12} md={9} lg={6}>
                        <Grid container>
                          {aboutPoliciesList.map((aboutData, i) => (
                            <Grid
                              item
                              xs={12}
                              md={6}
                              className="ssp-mb3"
                              key={i}
                            >
                              <Bannerquicklinks theme={theme}>
                                <div>
                                  <img
                                    alt=""
                                    title=""
                                    src={require("../../assets/images/icons/" +
                                      aboutData.imageName)}
                                  />
                                </div>
                                <span>{aboutData.text}</span>
                              </Bannerquicklinks>
                            </Grid>
                          ))}
                        </Grid>
                      </Grid>
                    </Grid>
                  </div>
                </div>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Bannercontainer>
    </Homebanner>
  );
}
