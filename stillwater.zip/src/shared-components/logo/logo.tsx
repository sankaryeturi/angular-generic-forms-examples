import React, { ReactElement } from "react";
import styled from "styled-components";
import logo from "../../assets/images/stillwater-logo-horiz@2x-new.png";
const Logo = styled.div`
  text-align: center;
  img {
    margin: 15px 0 0 0;
    min-width: 206px;
    width: 38%;
  }
`;

export default function LogoComponent(props: any): ReactElement {
  return (
    <Logo className="ssp-mb2">
      <a href="/" title={props.titleContent}>
        <img alt={props.altContent} title={props.titleContent} src={logo} />
      </a>
    </Logo>
  );
}
