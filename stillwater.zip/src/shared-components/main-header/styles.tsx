import styled from "styled-components";
import logoRes from "../../assets/images/stillwater-logo-horiz@2x.png";
import { IMAGES } from "../../config/config";

export const Mainheader = styled.div`
  height: 140px;
  background-color: ${(props) => props.theme.white};
  padding: 30px 0 0 0;
  > div {
    max-width: 85.4%;
    margin: 0 auto;
    .logo {
      .logo-image-block {
        background-image: url(${IMAGES.logo});
        max-width: 260px;
        min-height: 60px;
        width: 100%;
        height: 100%;
        background-position: center center;
        background-size: cover;
        background-repeat: no-repeat;
      }
    }
    @media only screen and (min-width: ${(props) =>
        props.theme.tabMin}) and (max-width: ${(props) => props.theme.tabMax}) {
      max-width: 90%;
    }
  }
  img {
    max-width: 252px;
    width: 100%;
  }
  .quick-links {
    margin-top: 19px;
    button {
      padding: 13px 10px;
    }
  }
  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    height: auto;
    padding-bottom: 0;
    &.blue-heading {
      background-color: ${(props) => props.theme.darkBlue};
    }
    > div {
      .logo {
        text-align: center;
        .logo-image-block {
          background-image: url(${logoRes});
          max-width: 100%;
          background-size: contain;
        }
      }
    }
  }
`;
