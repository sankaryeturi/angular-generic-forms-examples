import React, { ReactElement, useContext, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation } from "react-router";
import { useHistory } from "react-router-dom";
import { Grid, Hidden, Menu, MenuItem, MenuProps, withStyles } from "@material-ui/core";
import { LocalizationContext } from "../../locales";
import { ThemeContext } from "../../themes";
import { Mainheader } from "./styles";
import { Whitebutton, ThemeIcon, GrayButton } from "../../themes/styles";
import { UrgentMessageController } from "../urgent-messages/urgentMessageController";
import UrgentMessagesComponent from "../urgent-messages/urgentMessagesComponent";
import { CommonService } from "../../_services/commonServices";
import { standard } from "../../themes/standard";

const StyledMenu = withStyles({
  paper: {
    border: `1px solid ${standard.hash}`,
  },
})((props: MenuProps) => (
  <Menu
    elevation={0}
    getContentAnchorEl={null}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "center",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "center",
    }}
    {...props}
  />
));

const StyledMenuItem = withStyles((theme) => ({
  root: {
    marginLeft: "10px",
    marginRight: "10px",
    marginBottom: "10px",
    backgroundColor: `${standard.darkBlue}`,
    color: theme.palette.common.white,
    fontSize: "13px",
    "&:hover": {
      backgroundColor: `${standard.darkBlue}`,
      "& .MuiListItemIcon-root, & .MuiListItemText-primary": {
        color: theme.palette.common.white,
      },
    },
  },
}))(MenuItem);

export default function MainHeader(): ReactElement {
  const [anchorEl, setAnchorEl] = useState(null);
  const history = useHistory();
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const profile = useSelector((storeState: any) => storeState.accountInfoReducer.profile);
  const authLoginState: any = localStorage.getItem("isAuthenticated");
  const browserUrl: any = useLocation();

  // logout functionality
  const logoutSubmit = (e: any): void => {
    e.preventDefault();
    CommonService.logout();
    window.location.href = "/";
  };
  /** navigat to back page */
  function navigation() {
    window.history.back();
  }
  /** navigation */
  const homeNavigation = (path) => {
    history.push("/" + path);
  };

  const savedQuote = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      {browserUrl?.pathname !== "/login" && (
        <Mainheader theme={theme} className="blue-heading">
          <div>
            <Grid container>
              <Hidden mdUp>
                <Grid item xs={1} className="ssp-dflexcenter">
                  <a href={undefined} onClick={navigation}>
                    <ThemeIcon className="angle-left-white-icon"></ThemeIcon>
                  </a>
                </Grid>
              </Hidden>
              <Grid item xs={10} md={4} className="logo">
                <a
                  href={undefined}
                  className="ssp-inline-block ssp-w100"
                  onClick={() => homeNavigation("dashboard")}
                >
                  <div className="logo-image-block"></div>
                </a>
              </Grid>
              <Hidden mdUp>
                <Grid item xs={1} className="ssp-dflexcenter">
                  <ThemeIcon className="bars-white-icon"></ThemeIcon>
                </Grid>
              </Hidden>
              <Hidden smDown>
                {authLoginState == "true" && (
                  <Grid item xs={12} md={8} className="ssp-pr3">
                    <div className="ssp-align-right">
                      <Whitebutton theme={theme}>
                        <ThemeIcon className="ssp-userheadseticon"></ThemeIcon>
                        <span>{bundle["button.contact"]}</span>
                      </Whitebutton>
                      <Whitebutton
                        theme={theme}
                        onClick={(e) => homeNavigation("settings")}
                      >
                        <ThemeIcon className="ssp-settingicon"></ThemeIcon>
                        {bundle["button.accountsettings"]}
                      </Whitebutton>
                      <Whitebutton
                        theme={theme}
                        onClick={(e) => logoutSubmit(e)}
                        className="ssp-mr0"
                      >
                        <span className="ssp-colorblack ssp-mr2">
                          {profile?.userID}
                        </span>
                        <span className="ssp-mr2">
                          {bundle["label.logOut"]}
                        </span>
                        <ThemeIcon className="ssp-logouticon"></ThemeIcon>
                      </Whitebutton>
                    </div>
                    {/* Quote block */}
                    <div className="ssp-align-right quick-links">
                      <GrayButton
                        theme={theme}
                        onClick={(e) => e.preventDefault}
                        className="ssp-mr3 bottom-radious-0"
                      >
                        <ThemeIcon className="clipboard-list-check-blue-icon"></ThemeIcon>{" "}
                        <b>{bundle["label.getAquote"]}</b>
                      </GrayButton>
                      <GrayButton
                        theme={theme}
                        onClick={savedQuote}
                        className="bottom-radious-0"
                      >
                        <ThemeIcon className="folder-open-blue-icon"></ThemeIcon>{" "}
                        <b className="ssp-pl1">
                          {bundle["label.retrieveSavedQuote"]}
                        </b>
                      </GrayButton>
                      <StyledMenu
                        id="customized-menu"
                        anchorEl={anchorEl}
                        keepMounted
                        open={Boolean(anchorEl)}
                        onClose={handleClose}
                      >
                        <StyledMenuItem>
                          <ThemeIcon className="hotel-white-icon" />
                          <span className="ssp-pl2">
                            Condo Insurance Quote #238990000 - 07/12/20
                          </span>
                        </StyledMenuItem>
                        <StyledMenuItem>
                          <ThemeIcon className="building-white-icon padding1015" />
                          Renters Insurance Quote #65331222 - 07/09/20
                        </StyledMenuItem>
                      </StyledMenu>
                    </div>
                  </Grid>
                )}
              </Hidden>
            </Grid>
          </div>
          <div className="ssp-m0 ssp-max-w100">
            {/* importanat message for responsive view */}
            <Hidden mdUp>
              <UrgentMessageController>
                <UrgentMessagesComponent />
              </UrgentMessageController>
            </Hidden>
          </div>
        </Mainheader>
      )}
    </>
  );
}
