import React, { ReactElement, useState, useContext } from "react";
import { SspformGroup } from "../../themes/styles";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";

const initialState = {
  policyNumber: "",
};
export default function PolicyListDropdownComponent(props): ReactElement {
  const [state, setState] = useState(initialState.policyNumber);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);

  const handleChange = (e) => {
    const indexValue = parseInt(e.target.value);
    props.policyTabClick(indexValue);
    setState(e.target.value);
  };
  return (
    <>
      <SspformGroup theme={theme}>
        <select
          value={state}
          className={props.dynamicClass}
          onChange={(e) => handleChange(e)}
        >
          {props.policies !== undefined &&
            props.policies.map((policyData, i) => (
              <option key={i} value={i}>
                {policyData.policyType} {bundle["text.policy"]}{" "}
                {policyData.policyNumber} ...
              </option>
            ))}
        </select>
      </SspformGroup>
    </>
  );
}
