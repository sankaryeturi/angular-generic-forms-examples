import React, { ReactElement, useContext } from "react";
import { Grid } from "@material-ui/core";
import { LocalizationContext } from "../../locales";
import { DownloadAppBlock } from "./styles";

export default function Downloadapp(): ReactElement {
  const { bundle } = useContext(LocalizationContext);

  return (
    <DownloadAppBlock>
      <div className="ssp-appcontent">
        <h2 className="ssp-darkblueheading">
          {bundle["heading.downloadapps"]}
        </h2>
        <p>{bundle["text.downloadappcontext"]}</p>
        <div className="ssp-mt60">
          <Grid container>
            <Grid item xs={6}>
              <a
                href={bundle["links.androidapp"]}
                title=""
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  alt=""
                  title=""
                  width="90%"
                  src={require("../../assets/images/google-play.png")}
                  className="ssp-mr4"
                />
              </a>
            </Grid>
            <Grid item xs={6}>
              <a
                href={bundle["links.iosapp"]}
                target="_blank"
                title=""
                rel="noopener noreferrer"
              >
                <img
                  alt=""
                  title=""
                  width="80%"
                  src={require("../../assets/images/app-store.png")}
                />
              </a>
            </Grid>
          </Grid>
        </div>
      </div>
    </DownloadAppBlock>
  );
}
