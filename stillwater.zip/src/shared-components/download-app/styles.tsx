import styled from "styled-components";

export const DownloadAppBlock = styled.div`
  .ssp-appcontent {
    background-color: #ffffff;
    max-height: 468px;
    height: 100%;
    padding: 11%;
  }
  .ssp-darkblueheading {
    text-align: left;
    letter-spacing: 0px;
    color: #003399;
    opacity: 1;
    text-transform: uppercase;
    margin: 0 0 10px 0;
    font: 24px/28px Work Sans Extra Bold;
    line-height: 1.5rem;
  }
`;
