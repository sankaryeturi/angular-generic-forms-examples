import React, { ReactElement } from "react";
import { Grid, makeStyles, Theme, createStyles } from "@material-ui/core";
import { ThemeIcon } from "../../themes/styles";
import { standard } from "../../themes/standard";

function getModalStyle() {
  const top = 50;
  const left = 50;

  return {
    top: `${top}%`,
    left: `${left}%`,
    transform: `translate(-${top}%, -${left}%)`,
    minHeight: "70%",
  };
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    paper: {
      position: "absolute",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      width: "50%",
      backgroundColor: theme.palette.background.paper,
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      [theme.breakpoints.down("md")]: {
        width: "85%",
      },
    },
    closeAlignment: {
      position: "absolute",
      top: "25px",
      right: "20px",
    },
    blueBox: {
      minHeight: "200px",
      backgroundColor: standard.darkBlue,
      color: "white",
      fontWeight: "bold",
      letterSpacing: "1px",
    },
  })
);

export default function TroubleSigninComponent(props: any): ReactElement {
  const classes = useStyles();
  const [modalStyle] = React.useState(getModalStyle);

  const navigation = (path) => {
    props.navigation(path);
  };

  return (
    <>
      <div style={modalStyle} className={`${classes.paper} `}>
        <a className={`${classes.closeAlignment}`} onClick={props.closePopup}>
          <ThemeIcon className="close-circle-blue-icon" />
        </a>
        <Grid container spacing={2} justify="center">
          <Grid item xs={6} md={4}>
            <a onClick={() => navigation("forgotpassword")}>
              <div className={`${classes.blueBox} ssp-dflexcenter`}>
                {props.bundle?.login?.forgotMyPassword}
              </div>
            </a>
          </Grid>
          <Grid item xs={6} md={4}>
            <a onClick={() => navigation("forgotuserid")}>
              <div className={`${classes.blueBox} ssp-dflexcenter`}>
                {props.bundle?.login?.forgotMyUserId}
              </div>
            </a>
          </Grid>
        </Grid>
      </div>
    </>
  );
}
