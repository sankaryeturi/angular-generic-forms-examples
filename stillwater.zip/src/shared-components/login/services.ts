class AuthServices {
  login() {
    return fetch("http://localhost:3100/users/1");
  }
}

export default AuthServices;
