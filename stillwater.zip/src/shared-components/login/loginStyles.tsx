import styled from "styled-components";

export const LoginForm = styled.div`
  .links {
    a {
      text-align: left;
      text-decoration: underline;
      font-size: 16px;
      letter-spacing: 0px;
      color: #003399;
      opacity: 1;
      font-weight: bold;
    }
  }
`;

export const Sspbluebutton = styled.button`
  background-color: ${(props) => props.theme.darkBlue};
  color: ${(props) => props.theme.white};
  padding: 15px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  border-radius: 3px;
  span {
    font-size: 17px;
  }
`;

export const Sspformgroup = styled.div`
  margin: 8px 0 20px 0;
  input,
  select {
    background-color: ${(props) => props.theme.white};
    width: 100%;
    padding: 12px 20px;
    display: inline-block;
    border: 0px;
    border-bottom: 3px solid ${(props) => props.theme.darkBlue};
    border-radius: 3px 3px 0px 0px;
    box-sizing: border-box;
    height: 55px;
  }

  label {
    letter-spacing: 0px;
    color: ${(props) => props.theme.black};
    font-weight: bold;
  }
  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    input {
      background: #f0f0f0;
      border-radius: 0;
    }

    input[type="text"],
    input[type="password"] {
      height: 50px;
    }
  }
`;
