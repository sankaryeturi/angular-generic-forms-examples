export interface IloginFormState {
  username: string;
  password: string;
  formSubmit: boolean;
  signinPopupOpen: boolean;
}
