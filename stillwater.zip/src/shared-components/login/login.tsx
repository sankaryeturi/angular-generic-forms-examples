import React, { useContext, ReactElement, useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import { LoginContext } from "./logincontroller";
import { Sspbluebutton, Sspformgroup, LoginForm } from "./loginStyles";
import { IloginFormState } from "./loginInterface";
import { ValidationService } from "../../_services/validation";
import { updatePolicies, updateUserProfile } from "../../_actions";
import TroubleSigninComponent from "../trouble-signin-popup/troubleSigninPopup";
import { Modal } from "@material-ui/core";
import { updatedTargetedAlerts } from "../../_actions";
import { ThemeIcon, ErrorMessage } from "../../themes/styles";

const initialState: IloginFormState = {
  username: "raman10",
  password: "test1234",
  formSubmit: false,
  signinPopupOpen: false,
};

export function LoginComponent(): ReactElement {
  const [state, setState] = useState(initialState);
  const { login, error } = useContext(LoginContext);
  const { bundle } = useContext(LocalizationContext);
  const { theme } = useContext(ThemeContext);
  const history = useHistory();
  const dispatch = useDispatch();
  const ref = React.createRef();

  /** submit login functionality */
  const loginSubmit = (event: any): void => {
    event.preventDefault();
    login(state.username, state.password)
      .then((response) => {
        console.log("policy list", response.policies.data.policies);
        dispatch(updatePolicies(response.policies.data.policies)); // updating the policies to redux
        const userInfo = {
          userID: state.username,
          username: response.policies.data.policies[0].policyNamed,
        };
        dispatch(updateUserProfile(userInfo));
        const targetList = response.targetedMessages?.data?.messages;
        dispatch(updatedTargetedAlerts(targetList)); // updating the targeted alerts to redux
        history.push("/");
      })
      .catch((error) => {
        console.log(
          `%c Error: login.tsx - LoginForm.onClick ${JSON.stringify(error)}`,
          "color: #FF0000"
        );
      });
  };

  /** changing input fields */
  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };

  useEffect(() => {
    ValidationService.charNumCombo();
  }, [state.formSubmit]);

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  const handleTroubleSigninPopup = () => {
    setState({
      ...state,
      signinPopupOpen: !state.signinPopupOpen,
    });
  };

  return (
    <LoginForm>
      <ValidatorForm
        onSubmit={(e) => loginSubmit(e)}
        className="ssp-loginform"
        autoComplete="off"
      >
        <Sspformgroup theme={theme}>
          <TextValidator
            label={bundle["label.userid"]}
            fullWidth
            onChange={(e) => handleChange(e, "username")}
            name="userId"
            id="userId"
            value={state.username}
            validators={[
              "required",
              "minStringLength:6",
              "maxStringLength: 32",
            ]}
            errorMessages={[
              bundle?.validation?.useridRequired,
              bundle?.validation?.useridMinimum,
              bundle?.validation?.useridMaximum,
            ]}
            InputLabelProps={{
              shrink: true,
            }}
          />
        </Sspformgroup>
        <Sspformgroup theme={theme}>
          <TextValidator
            label={bundle["label.passcode"]}
            fullWidth
            onChange={(e) => handleChange(e, "password")}
            name="password"
            id="userPassword"
            value={state.password}
            validators={["required", "minStringLength:6", "charNumCombo"]}
            errorMessages={[
              bundle?.login?.passcodeError,
              bundle["validation.passMin"],
              bundle["validation.passcodeCombo"],
            ]}
            type="password"
            InputLabelProps={{
              shrink: true,
            }}
          />
        </Sspformgroup>
        <Sspbluebutton theme={theme}>
          <span className="ssp-pr3">{bundle["label.login"]}</span>
          <ThemeIcon className="signin-icon"></ThemeIcon>
        </Sspbluebutton>

        {error && (
          <ErrorMessage
            className="orange ssp-mt2 ssp-inline-block"
            theme={theme}
          >
            <b>{error}</b>
          </ErrorMessage>
        )}
        <div className="ssp-pt2 links">
          <a href={undefined} onClick={handleTroubleSigninPopup}>
            {bundle?.login?.trouble}
          </a>
          <a
            href={undefined}
            onClick={() => navigation("signUpPage")}
            className="ssp-pullright"
          >
            {bundle?.login?.newuser}
          </a>
        </div>
      </ValidatorForm>

      <Modal
        open={state.signinPopupOpen}
        onClose={handleTroubleSigninPopup}
        aria-labelledby="simple-modal-title"
        aria-describedby="simple-modal-description"
        ref={ref}
      >
        <div>
          <TroubleSigninComponent
            bundle={bundle}
            navigation={navigation}
            closePopup={handleTroubleSigninPopup}
          />
        </div>
      </Modal>
    </LoginForm>
  );
}

export default LoginComponent;
