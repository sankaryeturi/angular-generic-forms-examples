import React, { createContext, ReactElement, ReactNode, useState } from "react";
import { LoginService } from "../../_services/loginservice";
import { PoliciesService } from "../../_services/policiesServices";
import { Policy } from "../../_interfaces/policies";
import { Profile } from "../../_interfaces/profile";
import { CommonService } from "../../_services/commonServices";

interface LoginControllerProps {
  children: ReactNode;
}

interface LoginState {
  readonly username: string | null;
  readonly loading: boolean;
  readonly profile: Profile | null;
  readonly policies: Policy[];
  readonly error: any;
  readonly currentMailAddress: any;
  readonly targetedMessages: any;
}

interface LoginStateContext extends LoginState {
  readonly login: (username: string, password: string) => any;
  readonly logout: () => void;
}

const initialState: LoginState = {
  username: null,
  loading: false,
  profile: null,
  policies: [],
  error: null,
  currentMailAddress: [],
  targetedMessages: [],
};

const initialContext: LoginStateContext = {
  ...initialState,
  login: invalidContext,
  logout: invalidContext,
};

export const LoginContext = createContext(initialContext);

export function LoginController(props: LoginControllerProps): ReactElement {
  const [state, setState] = useState(initialState);

  async function login(username: string, password: string): Promise<any> {
    try {
      const loginResponse = await LoginService.login(username, password);
      localStorage.setItem("authorizationToken", loginResponse.bearerToken);
      localStorage.setItem("isAuthenticated", "true");
      localStorage.setItem("userid", username);
      const [policies, targetedMessages]: any = await Promise.all([
        PoliciesService.getPolicies(),
        CommonService.getTargetedMessages()
      ]);

      // get the targeted alerts
      // const targetedMessages = await CommonService.getTargetedMessages();

      setState({
        ...initialState,
        username,
        policies,
        targetedMessages,
      });

      return { ...initialState, policies, targetedMessages, error: null };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          error: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }

  async function logout(): Promise<void> {
    try {
      setState({ ...state, loading: true, error: null });
      const response = await LoginService.logout();
    } catch (error) {
      setState({ ...initialState, error });
    }
  }

  const context = {
    ...state,
    login,
    logout,
  };

  return (
    <LoginContext.Provider value={context}>
      {props.children}
    </LoginContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a LoginController?");
}
