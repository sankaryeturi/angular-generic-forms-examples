import React, { ReactElement, useContext } from "react";
import { PasswordRules, ThemeIcon } from "../../themes/styles";

export default function PasswordStrengthBlock(props: any): ReactElement {
  const closeCircleIcon = "close-circle-disable-icon";
  const checkIcon = "check-green-icon";

  return (
    <div>
      <PasswordRules theme={props.theme} className="ssp-pl0">
        <ul>
          <li>
            <ThemeIcon
              className={`${props.lengthCheck ? checkIcon : closeCircleIcon}`}
            ></ThemeIcon>
            {props.passStrengthMin}
          </li>
          <li>
            <ThemeIcon
              className={`${
                props.uppercaseCheck ? checkIcon : closeCircleIcon
              }`}
            ></ThemeIcon>
            {props.passStrengthUppercase}
          </li>
          <li>
            <ThemeIcon
              className={`${props.numberCheck ? checkIcon : closeCircleIcon}`}
            ></ThemeIcon>
            {props.passStrengthNumber}
          </li>
          <li>
            <ThemeIcon
              className={`${props.charCheck ? checkIcon : closeCircleIcon}`}
            ></ThemeIcon>
            {props.passStrengthSpcChar}
          </li>
        </ul>
      </PasswordRules>
    </div>
  );
}
