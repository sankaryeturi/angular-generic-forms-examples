import styled from "styled-components";

export const Announcementblock = styled.div`
  color: ${(props) => props.theme.white};
  > div {
    //margin-bottom: 2px;
    &:last-child {
      margin-bottom: 0;
    }
  }
  .announcement-heading,
  .announcementcontent {
    > div {
      max-width: 85.4%;
      margin: 0 auto;
      @media only screen and (max-width: ${(props) => props.theme.mobileMax}) {
        max-width: 88.4%;
      }
    }
  }
  .announcement-heading {
    background-color: ${(props) => props.theme.orange};
    font: Bold 12px/28px Source Sans Pro;
    padding-top: 3px;
    height: 33px;
    overflow: hidden;
    :hover {
      cursor: pointer;
    }
    span.copy {
      font-size: 15px;
    }
    @media screen and (max-width: 767px) {
      span.copy {
        white-space: nowrap;
        width: 225px;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }
  }
  .announcementcontent {
    color: ${(props) => props.theme.black};
    background-color: #fff;
    font: Regular 16px/20px Source Sans Pro;
    line-height: 16px;
    display: inline-block;
    border-bottom: 1px solid ${(props) => props.theme.orange};
    p.copy {
      font-size: 14px;
    }
  }
`;
