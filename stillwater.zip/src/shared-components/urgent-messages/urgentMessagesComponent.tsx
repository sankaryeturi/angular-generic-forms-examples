import React, { ReactElement, useContext, useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Grid } from "@material-ui/core";
import { Error } from "@material-ui/icons";
import { ThemeContext } from "../../themes";
import { Announcementblock } from "./urgentMessagesStyles";
import { UrgentMessageContext } from "./urgentMessageController";
import { ThemeIcon } from "../../themes/styles";
import { updateImportantAlerts } from "../../_actions";
import { CommonService } from "../../_services/commonServices";

const initialState = {
  targetedToggleState: false,
};
export default function UrgentMessagesComponent(): ReactElement {
  const [state, setState] = useState(initialState);
  const dispatch = useDispatch();
  const { theme } = useContext(ThemeContext);
  const { getUrgentMessages } = useContext(UrgentMessageContext);
  const alerts = useSelector(
    (storeState: any) => storeState.importantAlertsReducer.alerts
  );
  const targetedAlerts = useSelector(
    (storeState: any) => storeState.importantAlertsReducer.targetedAlerts
  );

  useEffect(() => {
    try {
      // get urgent messages
      getUrgentMessages()
        .then((response) => {
          if (response?.urgentMessages?.status === 200) {
            let list = response.urgentMessages.data.messages;
            list = list.map((data) => {
              data.toggleStatus = false;
              data.activeStatus = true;
              return data;
            });
            dispatch(updateImportantAlerts(list));
          }
        })
        .catch((error) => {
          console.log(
            `%c Error: urgentMessagesCom.tsx - getUrgentMessages() ${JSON.stringify(
              error
            )}`,
            "color: #FF0000"
          );
        });
    } catch (error) {
      console.log("Error: urgent message comp useEffect()", error);
    }
  }, []);

  /** changing the content status(show/hide) **/
  const contentToggle = (index) => {
    const list = alerts.map((list, i) => {
      if (index === i) {
        list.toggleStatus = !list.toggleStatus;
      } else {
        list.toggleStatus = false;
      }
      return { ...list };
    });
    dispatch(updateImportantAlerts(list));
  };

  const blanketContent = (messageText) => {
    return <p className="copy">{messageText}</p>;
  };

  // for content animation
  const handleOpen = (index) => {
    contentToggle(index);
    setState({ ...state, targetedToggleState: false });
  };

  const targetHandleToggle = () => {
    setState({ ...state, targetedToggleState: !state.targetedToggleState });

    const list = alerts.map((list, i) => {
      list.toggleStatus = false;
      return { ...list };
    });
    dispatch(updateImportantAlerts(list));
  };

  return (
    <Announcementblock theme={theme}>
      {alerts.map((list, i) => {
        return (
          <div key={i}>
            <div>
              <div
                className="announcement-heading"
                onClick={() => handleOpen(i)}
              >
                <Grid container>
                  <Grid item xs={10} md={4} className="ssp-dInherit">
                    <div className="ssp-dInherit">
                      <span className="ssp-pt1 ssp-mr1">
                        <Error className="font-16" />
                      </span>
                      <span className="copy">{list.shortDescription}</span>
                    </div>
                  </Grid>
                  <Grid item xs={2} md={4} className="ssp-align-center">
                    <span>
                      {/* Down arrow */}
                      {list.toggleStatus === true && (
                        <ThemeIcon className="angle-up-white-icon"></ThemeIcon>
                      )}
                      {list.toggleStatus === false && (
                        <ThemeIcon className="angle-down-white-icon"></ThemeIcon>
                      )}
                    </span>
                  </Grid>
                </Grid>
              </div>
              {list.toggleStatus && (
                <div className="announcementcontent">
                  <div>{blanketContent(list.longDescription)}</div>
                </div>
              )}
              <hr className="ssp-m0 ssp-hr-line" />
            </div>
          </div>
        );
      })}

      {targetedAlerts.length !== 0 && (
        <div>
          <div
            className="announcement-heading"
            onClick={() => targetHandleToggle()}
          >
            <Grid container>
              <Grid item xs={10} md={4} className="ssp-dInherit">
                <div className="ssp-dInherit">
                  <span className="ssp-pt1 ssp-mr1">
                    <Error className="font-16" />
                  </span>
                  <span className="copy">Targeted Alerts Title</span>
                </div>
              </Grid>
              <Grid item xs={2} md={4} className="ssp-align-center">
                <span>
                  {/* Up arrow */}
                  {state.targetedToggleState === true && (
                    <ThemeIcon className="angle-up-white-icon"></ThemeIcon>
                  )}
                  {/* Down arrow */}
                  {state.targetedToggleState === false && (
                    <ThemeIcon className="angle-down-white-icon"></ThemeIcon>
                  )}
                </span>
              </Grid>
            </Grid>
          </div>
          {state.targetedToggleState && (
            <div className="announcementcontent ssp-w100">
              <div className="ssp-mb3">
                <Grid container spacing={2}>
                  {targetedAlerts.map((data, z) => (
                    <>
                      {data.activeStatus === true && (
                        <Grid
                          item
                          xs={12}
                          md={targetedAlerts.length === 1 ? 12 : 6}
                          className="ssp-mt3"
                          key={z}
                        >
                          <b>{data.shortDescription}</b>
                          <p className="ssp-my0">{data?.longDescription}</p>
                        </Grid>
                      )}
                    </>
                  ))}
                </Grid>
              </div>
            </div>
          )}
          <hr className="ssp-m0 ssp-hr-line" />
        </div>
      )}
    </Announcementblock>
  );
}
