import React, { createContext, ReactElement, ReactNode, useState } from "react";
import { CommonService } from "../../_services/commonServices";

interface UrgentMessageControllerProps {
  children: ReactNode;
}
interface IUrgentMessageState {
  urgentMessages: any;
  urgentMessagesResError: any;
}
const initialState: IUrgentMessageState = {
  urgentMessages: null,
  urgentMessagesResError: null,
};
interface IUrgentMessageStateContext extends IUrgentMessageState {
  readonly getUrgentMessages: () => any;
}
const initialContext: IUrgentMessageStateContext = {
  ...initialState,
  getUrgentMessages: invalidContext,
};

export const UrgentMessageContext = createContext(initialContext);

export function UrgentMessageController(
  props: UrgentMessageControllerProps
): ReactElement {
  const [state, setState] = useState(initialState);

  async function getUrgentMessages(): Promise<any> {
    try {
      const responseData = await CommonService.getUrgentMessages();
      return { ...initialState, urgentMessages: responseData };
    } catch (error) {
      setState({ ...initialState, urgentMessagesResError: error });
      throw error;
      // return { ...initialState, urgentMessagesResError: error };
    }
  }
  const context = {
    ...state,
    getUrgentMessages,
  };

  return (
    <UrgentMessageContext.Provider value={context}>
      {props.children}
    </UrgentMessageContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a UrgentMessageController?");
}
