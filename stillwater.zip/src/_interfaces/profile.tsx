export interface MailingAddress {
  line1: string;
  line2: string;
  zipCode: string;
  city: string | null;
  state: string | null;
}

export const $MailingAddress = {
  type: "object",
  properties: {
    line1: { type: "string" },
    line2: { type: "string" },
    zipCode: { type: "string" },
    city: { type: ["string", "null"] },
    state: { type: ["string", "null"] },
  },
  required: ["line1", "line2", "zipCode", "city", "state"],
};

export interface PaperlessPreference {
  policyNumber: string;
  deliveryMethod: string;
  policyType: string;
}

export const $PaperlessPreference = {
  type: "object",
  properties: {
    policyNumber: { type: "string" },
    deliveryMethod: { type: "string" },
    policyType: { type: "string" },
  },
  required: ["policyNumber", "deliveryMethod", "policyType"],
};

export interface phoneNumbers {
  type: string;
  number: string;
  smsEnabled: boolean;
}

export const $PhoneNumbers = {
  type: "string",
  number: "string",
  smsEnabled: ["true", "false"],
};

export interface Profile {
  name: string | null;
  userID: string;
  email: string | null;
  mailingAddress: MailingAddress;
  phoneNumbers: phoneNumbers[];
  paperlessPref: PaperlessPreference[];
}

export const $Profile = {
  type: "object",
  properties: {
    name: { type: ["string", "null"] },
    userID: { type: ["string"] },
    email: { type: ["string", "null"] },
    mailingAddress: $MailingAddress,
    phoneNumbers: $PhoneNumbers,
    paperlessPref: { type: "array", itemType: $PaperlessPreference },
  },
  required: [
    "name",
    "userID",
    "email",
    "mailingAddress",
    "phoneNumbers",
    "paperlessPref",
  ],
};
