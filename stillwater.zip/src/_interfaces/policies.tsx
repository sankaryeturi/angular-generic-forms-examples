export interface PolicyTerm {
  startDate: string;
  endDate: string;
}

export const $PolicyTerm = {
  type: "object",
  properties: {
    startDate: { type: "string" },
    endDate: { type: "string" },
  },
  required: ["startDate", "endDate"],
};

export interface Policy {
  policyNumber: string;
  policyType: string;
  policyStatus: string;
  policyTerm: PolicyTerm;
  details: any;
}

export const $Policy = {
  type: "object",
  properties: {
    policyNumber: { type: "string" },
    policyType: { type: "string" },
    policyStatus: { type: "string" },
    policyTerm: $PolicyTerm,
  },
  required: ["policyNumber", "policyType", "policyStatus", "policyTerm"],
};

export const $Policies = {
  type: "array",
  itemItem: $Policy,
  minItems: 1,
};
