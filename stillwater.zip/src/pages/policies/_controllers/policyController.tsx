import React, { createContext, ReactNode, ReactElement, useState } from "react";
import { PoliciesService } from "../../../_services/policiesServices";

interface PolicyControllerProps {
  children: ReactNode;
}
interface PolicyState {
  policyListResponse: any;
  policyListError: any;
  coverageResponse: any;
  coveragesError: any;
  policyDetailsResponse: any;
  policyDetailsError: any;
  error: any;
  autoIdsList: any;
  autoIdsError: any;
  helpTextResponse: any;
  helpTextError: any;
  autoIdResponse: any;
}
interface PolicyStateContext extends PolicyState {
  readonly getPolicies: () => any;
  readonly getPolicyDetails: (policyNumber) => any;
  readonly getAutoIds: (policyNumber) => any;
  readonly getHelptextInfo: (helpText) => any;
  readonly autoCardSendMail: (inputReq) => any;
}

const initialState: PolicyState = {
  policyListResponse: null,
  policyListError: null,
  coverageResponse: null,
  coveragesError: null,
  policyDetailsResponse: null,
  policyDetailsError: null,
  error: null,
  autoIdsList: null,
  autoIdsError: null,
  helpTextResponse: null,
  helpTextError: null,
  autoIdResponse: null
};

const initialContext: PolicyStateContext = {
  ...initialState,
  getPolicies: invalidContext,
  getPolicyDetails: invalidContext,
  getAutoIds: invalidContext,
  getHelptextInfo: invalidContext,
  autoCardSendMail: invalidContext
};

export const PolicyContext = createContext(initialContext);

export function PolicyController(props: PolicyControllerProps): ReactElement {
  const [state, setState] = useState(initialState);
  // get policies
  async function getPolicies(): Promise<any> {
    try {
      const responseData = await PoliciesService.getPolicies();
      setState({ ...state, policyListResponse: responseData });
      return { ...initialState, policyListResponse: responseData };
    } catch (error) {
      setState({ ...state, policyListError: error });
      return { ...initialState, policyListError: error };
    }
  }
  // get the policy details by policy number
  async function getPolicyDetails(policyNumber): Promise<any> {
    try {
      const responseData = await PoliciesService.policyDetails(policyNumber);
      setState({ ...state, policyDetailsResponse: responseData });
      return {
        ...initialState,
        policyDetailsResponse: responseData.data,
      };
    } catch (error) {
      setState({ ...state, policyDetailsError: error });
      return { ...initialState, policyInformationError: error };
    }
  }
  // get auto ids list by policy number
  async function getAutoIds(policyNumber): Promise<any> {
    try {
      const inputRequest = {
        policyNumber: policyNumber,
      };
      const responseData = await PoliciesService.getAutoIds(inputRequest);
      setState({ ...state, autoIdsList: responseData });
      return { ...initialState, autoIdsList: responseData };
    } catch (error) {
      if (error.errors) {
        setState({
          ...initialState,
          autoIdsError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  // get help text info
  async function getHelptextInfo(helpText) {
    try {
      const inputReq = { 
        HelpTextNumber: helpText
      }
      const responseData = await PoliciesService.getHelptextInfo(inputReq);
      setState({ ...initialState, helpTextResponse: responseData });
      return { ...initialState, helpTextResponse: responseData };
    } catch(error) {
      if (error.errors) {
        setState({
          ...initialState,
          helpTextError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  /** send auto id card email */
  async function autoCardSendMail(inputReq) {
    try {
      const responseData = await PoliciesService.autoCardSendMail(inputReq);
      setState({ ...initialState, autoIdResponse: responseData, error: null });
      return { ...initialState, autoIdResponse: responseData, error: null };
    } catch(error) {
      if (error.errors) {
        setState({
          ...initialState,
          error: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }    
  }

  const context = {
    ...state,
    getPolicies,
    getPolicyDetails,
    getAutoIds,
    getHelptextInfo,
    autoCardSendMail
  };
  return (
    <PolicyContext.Provider value={context}>
      {props.children}
    </PolicyContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a policyController?");
}
