export interface AutoIdInitialStateInterface {
    idCardsList: any;
    policies: any;
    activePolicyNumber: string | null;
}