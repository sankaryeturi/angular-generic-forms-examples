/* eslint-disable */
import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  Blueheadinggrid,
  ThemeIcon,
  SspformGroup,
  Bluebutton,
  Darkbluebutton,
  ErrorMessage,
  SuccessBlock,
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import InsuranceItemsComponent from "../dashboard/_components/insuranceItems";
import { Grid, Hidden } from "@material-ui/core";
import { CardBlock } from "./styles";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import PolicyListDropdownComponent from "../../shared-components/policy-list-dropdown/policy-list-dropdown";
import { CommonService } from "../../_services/commonServices";
import { PolicyContext } from "./_controllers/policyController";
import { AutoIdInitialStateInterface } from "./_interface/autoIdCard";

const initialState: AutoIdInitialStateInterface = {
  policies: [],
  idCardsList: [],
  activePolicyNumber: null
};

export default function AutoIdCardComponent(): ReactElement {
  const urlParm: any = useParams();
  const [state, setState] = useState(initialState);
  const [policiesState, setPoliciesState] = useState(initialState.policies);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);
  const { autoIdsError, getAutoIds } = useContext(PolicyContext);
  const { autoCardSendMail, error } = useContext(PolicyContext)
  let policyEmptyState = false;
  let policiesList = policies.policis;

  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policyEmptyState = true;
    if (policiesState.length == 0) {
      policiesList = policiesList.filter((data, i) => {
        if (data.policyType === "Auto") {
          if (i === 0) {
            data.activeStatus = true;
          }
          return data;
        }
      });
    }
  }
  /** get auto id cards list using policy number */
  const getAutoIdCards = (policyNumber) => {
    getAutoIds(policyNumber)
      .then((response) => {
        // console.log(response?.autoIdsList?.data?.idCardData);
        const idCards = response?.autoIdsList?.data?.idCardData;
        idCards.map((data:any, i) => {
          data.emailBlockState  = false;
          data.formSubmit = false;
          data.email = "";
          return data;
        });
        // setIdCardsState(idCards);
        setState({ 
          ...state,
          idCardsList: idCards,
          activePolicyNumber: urlParm.policyNumber
        });
        console.log("cards list", idCards);
        
      })
      .catch((error) => {
        CommonService.consolError(error, "signUpPage.tsx", "formSubmit");
      });
  }

  useEffect(() => {
    getAutoIdCards(urlParm.policyNumber);
    setPoliciesState(policiesList)
  }, [policyEmptyState]);

  /** policy tab click function */
  const policyTabClick = (policyIndex: string) => {
    console.log(policyIndex);
  };
  // submit email for the individual auto id card
  const submitEmail = (e, index) => {
    const inputRequest = {
      policyNumber: state.activePolicyNumber,
      docId: state.idCardsList[index].docId,
      emailAddresses: [{
                        emailAddress: state.idCardsList[index].email
                      }]
    }
    autoCardSendMail(inputRequest)
      .then((response) => {
        // console.log(response)
        const emailInfo = state.idCardsList;
        emailInfo[index].formSubmit = true;
        setState({ ...state, idCardsList: emailInfo });
      })
      .catch((error) => {
        CommonService.consolError(error, "signUpPage.tsx", "formSubmit");
      });    
  };
  /** handle input change */
  const handleChange = (e, index) => {
    const emailInfo = state.idCardsList;
    emailInfo[index].email = e.target.value;
    setState({ ...state, idCardsList: emailInfo });
  };
  // toggle email block
  const emailClick = (index, done?) => {
    const idCards = state.idCardsList;
    if (done) {
      idCards[index].emailBlockState = false;
      idCards[index].email = "";
      idCards[index].formSubmit = false;
    } else {
      idCards[index].emailBlockState = !state.idCardsList[index].emailBlockState;
    }
    setState({ 
      ...state,
      idCardsList: idCards
    });
  };
  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle?.label?.autoId}
            icon="setting.svg"
            iconName="file-alt-blue-icon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Hidden smDown>
              <Grid container spacing={2}>
                {policiesState.map((policyData, i) => {
                  return (
                    <InsuranceItemsComponent
                      insuranceInfo={policyData}
                      key={i}
                      ItemIndex={i}
                      policyTabClick={policyTabClick}
                      footerStatus="false"
                      xsSize="2"
                    />
                  );
                })}
              </Grid>
            </Hidden>

            {/* policy list for responsive view */}
            <Hidden mdUp>
              <form>
                <PolicyListDropdownComponent
                  policies={policiesState}
                  dynamicClass="select-field gray"
                  policyTabClick={policyTabClick}
                ></PolicyListDropdownComponent>
              </form>
            </Hidden>

            {/* error message block */}
            {autoIdsError && (
              <Grid item xs={12}>
                <ErrorMessage
                  className="orange ssp-mt2 ssp-inline-block"
                  theme={theme}
                >
                  <b>{autoIdsError}</b>
                </ErrorMessage>
              </Grid>
            )}
            <Grid container spacing={2}>
              {(state.idCardsList) && state.idCardsList.map((data, i) => {
                return (
                  <Grid item xs={12} md={6} lg={3} key={i}>
                    <Blueheadinggrid
                      theme={theme}
                      className="ssp-mr0 min-height-auto"
                    >
                      <div className="heading ssp-p2">
                        <Grid container>
                          <Grid item xs={4} className="ssp-align-center">
                            <ThemeIcon className="download-white-icon padding1015"></ThemeIcon>
                            <span className="ssp-dBlock ssp-pt2">
                              <b>{bundle?.label?.download}</b>
                            </span>
                          </Grid>
                          <Grid item xs={4} className="ssp-align-center">
                            <ThemeIcon className="print-white-icon padding1215"></ThemeIcon>
                            <span className="ssp-dBlock ssp-pt2">
                              <b>{bundle?.label?.print}</b>
                            </span>
                          </Grid>
                          <Grid item xs={4} className="ssp-align-center">
                            <a href={undefined} onClick={() => emailClick(i)}>
                              <ThemeIcon className="paper-plane-white-icon padding1215"></ThemeIcon>
                              <span className="ssp-dBlock ssp-pt2">
                                <b>{bundle?.label?.email}</b>
                              </span>
                            </a>
                          </Grid>
                        </Grid>
                      </div>
                      <div className="content ssp-p3">
                        {data.emailBlockState && (
                          <div>
                            {(!data.formSubmit) && (
                              <div>
                                <p className="ssp-m0">
                                  <b>{bundle?.text?.sendEmail}:</b>
                                </p>
                                <p className="ssp-mt0 font-14">
                                  {bundle?.autoId?.context1}
                                </p>
                                <ValidatorForm
                                  onSubmit={(e) => submitEmail(e, i)}
                                  autoComplete="off"
                                >
                                  <SspformGroup
                                    theme={theme}
                                    className="input50 ssp-mt0 ssp-mb3"
                                  >
                                    <TextValidator
                                      fullWidth
                                      onChange={(e) =>
                                        handleChange(e, i)
                                      }
                                      name="sentEmail"
                                      id="sentEmail"
                                      type="text"
                                      value={data.email}
                                      validators={["required", "isEmail"]}
                                      errorMessages={[                                        
                                        bundle?.validation?.emailRequired,
                                        bundle?.validation?.emailPattern,
                                      ]}
                                      InputLabelProps={{
                                        shrink: true,
                                      }}
                                    />
                                  </SspformGroup>
                                  <p className="ssp-mt1">
                                    <ThemeIcon className="paperclip-icon" />
                                    <span>{bundle?.label?.icCardPolicy} {data.policyNumber}{bundle?.fileExt?.pdf}</span>
                                  </p>
                                  {error && (state.idCardsList[i].email.length !== 0) && (
                                    <ErrorMessage
                                      className="orange ssp-mt2 ssp-inline-block"
                                      theme={theme}
                                    >
                                      <b>{error}</b>
                                    </ErrorMessage>
                                  )}
                                  <div className="ssp-my4 ssp-dflexcenter">
                                    <Bluebutton
                                      theme={theme}
                                      className="ssp-mr3 ssp-px6"
                                      onClick={() => emailClick(i, "done")}
                                    >
                                      {bundle["button.cancel"]}
                                    </Bluebutton>
                                    <Darkbluebutton
                                      theme={theme}
                                      className="ssp-px6"
                                    >
                                      {bundle?.label?.send}
                                    </Darkbluebutton>
                                  </div>
                                </ValidatorForm>
                              </div>
                            )}
                            {data.formSubmit === true && (
                              <SuccessBlock theme={theme} className="ssp-px4 ssp-py3 ssp-mb5">
                                <p>
                                  <b>
                                    {bundle?.autoId?.successMessageContent}:
                                  </b>
                                </p>
                                <p>{data.email}</p>
                                <div className="ssp-align-center">
                                  <Darkbluebutton
                                    theme={theme}
                                    className="ssp-px6"
                                    onClick={() => emailClick(i, "done")}
                                  >
                                    {bundle?.label?.done}
                                  </Darkbluebutton>
                                </div>
                              </SuccessBlock>
                            )}
                          </div>
                        )}
                        <CardBlock theme={theme}>
                          <div className="ssp-p2">
                            <p className="card-heading">
                              <b>{bundle?.autoId?.IDheading}</b>
                            </p>
                            <span className="bold-text">
                              {bundle["label.policyNumber"]}:
                            </span>
                            <span>{data?.policyNumber}</span>
                            <br />
                            <span className="bold-text">
                              {bundle?.label?.effective}:
                            </span>
                            <span className="ssp-mr2"> {data?.effDate} </span>
                            <span className="bold-text">
                              {bundle?.label?.expires}:
                            </span>
                            <span> {data?.expDate}</span>

                            <p className="ssp-mb0 bold-text">
                              {data?.custName}
                            </p>
                            <span className="ssp-dBlock">
                              {data?.address1}
                            </span>
                            <span className="ssp-dBlock">
                              {data?.address2}
                            </span>

                            <p className="ssp-mb0 bold-text">
                              {bundle?.label?.vehicleDesc}
                            </p>
                            <Grid container>
                              <Grid item xs={3} className="ssp-pt2">
                                <span className="ssp-dBlock">{bundle?.label?.yr}</span>
                                <span className="ssp-dBlock">{data?.makeYear}</span>
                              </Grid>
                              <Grid item xs={3} className="ssp-pt2">
                                <span className="ssp-dBlock">{bundle?.label?.yr}</span>
                                <span className="ssp-dBlock">{data?.make}</span>
                              </Grid>
                              <Grid item xs={3} className="ssp-pt2">
                                <span className="ssp-dBlock">{bundle?.label?.make}</span>
                                <span className="ssp-dBlock">{data?.model}</span>
                              </Grid>
                            </Grid>

                            <p className="ssp-mb0 ssp-mt4 bold-text">{bundle?.label?.vin}</p>
                            <span className="ssp-dBlock">{data?.vinNumber}</span>

                            <p className="ssp-mb0 bold-text">
                              {bundle?.label?.agency}
                            </p>
                            <span className="ssp-dBlock">
                              {data?.agentAddress1}
                            </span>
                            <span className="ssp-dBlock">{data?.agentAddress2}</span>
                            <span className="ssp-dBlock">{data?.agentAddress2}</span>
                            <span className="ssp-dBlock">{data?.agentPhoneNumber}</span>
                            <div className="blank"></div>
                          </div>
                        </CardBlock>
                      </div>
                    </Blueheadinggrid>
                  </Grid>
                );
              })}
            </Grid>
          </div>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
