import React, { ReactElement } from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core";
import { Darkblueheadingh5, ThemeIcon } from "../../../themes/styles";

function getModalStyle() {
    const top = 50;
    const left = 50;  
    return {
      top: `${top}%`,
      left: `${left}%`,
      transform: `translate(-${top}%, -${left}%)`,
      minHeight: "150px",
    };
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    paper: {
      position: "absolute",
      maxWidth: "810px",
      width: "100%",
      backgroundColor: theme.palette.background.paper,
      boxShadow: theme.shadows[5],
      padding: "50px 80px",
      [theme.breakpoints.down("md")]: {
        width: "85%",
      },
    },
    closeAlignment: {
      position: "absolute",
      top: "25px",
      right: "20px",
    }
  })
);

export default function HelpTextPopupComponent(props): ReactElement {
    const classes = useStyles();
    const [modalStyle] = React.useState(getModalStyle);
    const closePopup = () => {
        props.closePopup("close")
    }
    return (
        <div style={modalStyle} className={`${classes.paper} `}>
            <a className={`${classes.closeAlignment}`} onClick={closePopup}>
                <ThemeIcon className="close-circle-blue-icon" />
            </a>
            <Darkblueheadingh5 theme={props.theme}>Property Damage (PD) Liability</Darkblueheadingh5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ultrices dolor dolor, at finibus sem finibus ac. 
                Vestibulum sit amet arcu facilisis mauris mollis rutrum. Etiam elementum justo massa, in tempus sem ornare et. 
                Suspendisse nec lacus et libero blandit fringilla non eu ligula. Duis nisl tellus, sodales non sodales eget, gravida vitae ante.
            </p>
        </div>
    )
}