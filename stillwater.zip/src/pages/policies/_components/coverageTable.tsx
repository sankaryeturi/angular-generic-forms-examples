/* eslint-disable */
import React, { ReactElement, useContext, useState } from "react";
import {
  DarkblueLink,
  Whitebutton,
  Darkblueheadingh4,
  Darkblueheadingh5,
} from "../../../themes/styles";
import {
  Grid,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Modal,
  Hidden,
  withStyles,
  Theme,
  createStyles,
  makeStyles,
} from "@material-ui/core";
import { ThemeContext } from "../../../themes";
import { LocalizationContext } from "../../../locales";
import HelpTextPopupComponent from "./helpTextPopup";
import { standard } from "../../../themes/standard";
import { CoverageDiscount } from "../styles";

const WhiteTableRow = withStyles((theme: Theme) =>
  createStyles({
    root: {
      borderBottom: `4px solid ${standard.hashLight}`,
    },
  })
)(TableRow);
const StyledTableRow = withStyles((theme: Theme) =>
  createStyles({
    root: {
      "&:nth-of-type(even)": {
        backgroundColor: standard.white,
        borderBottom: "0",
      },
      [theme.breakpoints.down("md")]: {
        "&:nth-of-type(odd)": {
          backgroundColor: standard.white,
        },
        borderBottom: `7px solid ${standard.hashLight} !important`,
      },
    },
  })
)(TableRow);
const StyledTableCell = withStyles((theme: Theme) =>
  createStyles({
    body: {
      borderBottom: "0",
      padding: "8px 6px",
      borderLeft: `4px solid ${standard.hashLight}`,
      font: "Bold 16px/32px Source Sans Pro",
      lineHeight: "20px",
      maxWidth: "120px",
    },
    root: {
      borderBottom: "0",
      [theme.breakpoints.down("md")]: {
        maxWidth: "100%",
        display: "block",
        textAlign: "left",
        width: "100% !important",
      },
    },
  })
)(TableCell);

const useStyles = makeStyles({
  width35: {
    width: "35%",
  },
  width40: {
    width: "40%",
  },
  whiteRow: {
    backgroundColor: standard.white,
  },
  darkBlueColor: {
    color: standard.darkBlue,
  },
  fontBold: {
    font: "Bold 14px/22px Source Sans Pro",
  },
  descText: {
    font: "14px/14px Source Sans Pro",
  },
});

interface InitialStateInterface {
  coveragesActualInfo: any;
  coverages: any;
  totalPremium: number | null;
  activeId: string | null;
  vechicleCoveragesTotals: any;
  helpTextPopupState: boolean;
}
const initialState: InitialStateInterface = {
  coveragesActualInfo: [],
  coverages: [],
  totalPremium: null,
  activeId: null,
  vechicleCoveragesTotals: null,
  helpTextPopupState: false
};
export default function CoverageTableComponent(props): ReactElement {
  const [state, setState] = useState(initialState);
  const { bundle } = useContext(LocalizationContext);
  const { theme } = useContext(ThemeContext);
  const classes = useStyles();

  /** vehicle list */
  const vehicleListRow = (
    <Hidden smDown>
      <Table>
        <TableHead>
          {/* vehiclel list */}
          {props?.coveragePropertiesInfo && (
            <TableRow>
              <StyledTableCell
                align="center"
                className={classes.width35}
              ></StyledTableCell>
              {props?.coveragePropertiesInfo.map((data: any, vListIndex) => (
                <StyledTableCell key={vListIndex} align="center">
                  <b>{data.property}</b>
                </StyledTableCell>
              ) )}
            </TableRow>
          )}
        </TableHead>
      </Table>
    </Hidden>
  );

  const totalPrice = (
    <Darkblueheadingh4 theme={theme}>
      {bundle["policyCoverage.premiumTotal"]}: ${props.coverageTotal}
    </Darkblueheadingh4>
  );
  //modal popup functionality
  const handleHelptextPopup = (status, helpText?) => {    
    if(helpText) {
      props.getHelptext(helpText)
    }
    let popupStatus;
    if(status === "open") {
      popupStatus = true;
    } else {
      popupStatus = false;
    }
    setState({
      ...state,
      helpTextPopupState: popupStatus,
    });
  }
  return (
    <div>
      {/* edit button and total amount */}
      <Hidden smDown>
        <Grid container className="ssp-mb3">
          <Grid item xs={12} md={4}>
            
          </Grid>
          <Grid item xs={12} md={8}>
            {totalPrice}
          </Grid>
        </Grid>
      </Hidden>
      {/* vehicle list row */}
      {vehicleListRow}
      {/* ./ END vehicle list row */}
      <Table>
        <TableBody>
          <Hidden smDown>
            {/* total amounts for vehicles */}
            <WhiteTableRow className={classes.whiteRow}>
              <StyledTableCell align="right">
                <Darkblueheadingh5 theme={theme} className="capitalize">
                  {bundle["heading.premiumTotal-perVehicle"]}:
                </Darkblueheadingh5>
              </StyledTableCell>

              {(props?.coveragePropertiesInfo) && props?.coveragePropertiesInfo.map((propertyData, k) => (
                <StyledTableCell align="center" key={k}>
                  <Darkblueheadingh5 theme={theme}>
                    ${propertyData.totalPremium}
                  </Darkblueheadingh5>
                </StyledTableCell>
              ))  }
            </WhiteTableRow>
            {/* if coverages list is empty, displaying the empty record message */}
            {props?.policyCoverages?.length === 0 && (
              <WhiteTableRow className={classes.whiteRow}>
                <StyledTableCell align="center">
                  {bundle["text.emptyRecords"]}
                </StyledTableCell>
              </WhiteTableRow>
            )}
          </Hidden>
          
          {(props?.coverageInfo) && props?.coverageInfo?.map((data, i) => (
            <StyledTableRow key={i}>
              <StyledTableCell align="left" className={classes.width35}>
                <DarkblueLink
                  theme={theme}
                  href="#"
                  onClick={() => handleHelptextPopup("open", data?.propertyAmounts[0]?.helpTextId)}
                  className={`${classes.fontBold} ssp-pl2`}
                >
                  {data?.name}
                </DarkblueLink>
                <br />
                {/* <span className={classes.descText}>Each Accident: $0</span> */}
              </StyledTableCell>

              {data.propertyAmounts.map((coverInfo, j) => (
                <StyledTableCell align="center" key={j}>
                  <Hidden smDown>
                    <span className="ssp-dBlock">
                      ${coverInfo?.coveragePremium}
                    </span>                
                    {/* <span className="font-12">
                      {bundle["text.deductible"]}: $ 100
                    </span> */}
                  </Hidden>
                  {/* responsive view */}
                  <Hidden mdUp>
                    <p className="ssp-m0 ssp-pr4 clearfix">
                      <span className="ssp-pullLeft">
                        <span className="font-12 ssp-dBlock">
                          {bundle["text.deductible"]}: $
                          Deductible Amount
                        </span>
                      </span>
                      <span
                        className={`${classes.fontBold} ${classes.darkBlueColor} ssp-pullright`}
                      >
                        Amount
                      </span>
                    </p>
                  </Hidden>
                </StyledTableCell>
              ))}              
            </StyledTableRow>
          )) }          
 
          <Hidden smDown>
            <WhiteTableRow className={classes.whiteRow}>
              <StyledTableCell align="right">
                <Darkblueheadingh5 theme={theme} className="capitalize">
                  {bundle["heading.premiumTotal-perVehicle"]}:
                </Darkblueheadingh5>
              </StyledTableCell>
              {(props?.coveragePropertiesInfo) && props?.coveragePropertiesInfo.map((propertyData, k) => (
                <StyledTableCell align="center" key={k}>
                  <Darkblueheadingh5 theme={theme}>
                    ${propertyData.totalPremium}
                  </Darkblueheadingh5>
                </StyledTableCell>
              ))  }
            </WhiteTableRow>
            {state.coveragesActualInfo?.policyType === "HOME" && (
              <WhiteTableRow className={classes.whiteRow}>
                <StyledTableCell colSpan={4} align="center">
                  {" "}
                </StyledTableCell>
              </WhiteTableRow>
            )}
          </Hidden>
        </TableBody>
      </Table>

      <Hidden smDown>
        <CoverageDiscount theme={theme} className="ssp-mx1">
          <Grid container>
            <Grid item xs={12} md={4}>
              <Darkblueheadingh5 theme={theme} className="ssp-align-center capitalize">
                Total Discounts
              </Darkblueheadingh5>
            </Grid>
            <Grid item xs={12} md={8} className="ssp-align-center ssp-pt1">
              -{props?.totalDiscount}
            </Grid>
          </Grid>
        </CoverageDiscount>
        
        <div style={{backgroundColor: "#fff"}} className="ssp-mx1">
          <Grid container className="ssp-py4">
            <Grid item xs={12} md={4}></Grid>
            <Grid item xs={12} md={8}>
              {totalPrice}
            </Grid>
          </Grid>
        </div>
        
      </Hidden>

      {/* Helptext modal popup */}
      <Modal
        open={state.helpTextPopupState}
        onClose={() => handleHelptextPopup("close")}
        aria-labelledby="simple-modal-title"
        aria-describedby="simple-modal-description"
      >
        <div>
          <HelpTextPopupComponent theme={theme} closePopup={handleHelptextPopup}>
          </HelpTextPopupComponent>
        </div>
      </Modal>
    </div>
  );
}
