import styled from "styled-components";

export const CardBlock = styled.div`
  min-height: 100px;
  background-color: ${(props) => props.theme.white};
  padding: 3px;
  text-transform: uppercase;
  > div {
    border: 1px solid #ccc;
    height: 100%;
    min-height: inherit;
  }
  .card-heading {
    font-size: 1.2rem !important;
    text-align: center;
    margin-bottom: 0.5rem;
    margin-top: 0.5rem;
  }
  .bold-text {
    font-size: 14px;
    font-weight: 600;
  }
  .blank {
    min-height: 100px;
  }
`;

export const CoverageDiscount = styled.div`
  border-top: 1px solid ${(props) => props.theme.orange};
  border-bottom: 1px solid orange;
  padding: 5px 0;
  background-color: ${(props) => props.theme.white}
`