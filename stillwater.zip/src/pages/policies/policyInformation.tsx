/* eslint-disable */
import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import Slider from "react-slick";
import { Grid, Hidden } from "@material-ui/core";
import { AddCircle, RemoveCircle } from "@material-ui/icons";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import { useParams } from "react-router";
import {
  Appbodycontainer,
  Blueheadinggrid,
  DarkBlueh5title,
  DarkblueLink,
  InformationSummary,
  Bluebutton,
  Whitebutton,
  CarouselSlider,
  ThemeIcon,
} from "../../themes/styles";
import CoverageTableComponent from "./_components/coverageTable";
import {
  PolicyContext,
  PolicyController,
} from "./_controllers/policyController";
import InsuranceItemsComponent from "../dashboard/_components/insuranceItems";
import PolicyListDropdownComponent from "../../shared-components/policy-list-dropdown/policy-list-dropdown";
import { updatePolicies } from "../../_actions";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";

interface InitialStateInterface {
  discountsOpened: boolean;
  insuredDriversOpened: boolean;
  policies: any;
  policyDetails: any;
  currentPolicyNumber: string | null;
  policyCoverages: any;
  coveragePropertiesInfo: any;
  coverageTotal: number;
}
const initialState: InitialStateInterface = {
  discountsOpened: false,
  insuredDriversOpened: false,
  policies: [],
  policyDetails: null,
  currentPolicyNumber: null,
  policyCoverages: null,
  coveragePropertiesInfo: null,
  coverageTotal: 0
};
export default function PolicyInformation(): ReactElement {
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);
  const { getPolicyDetails, getHelptextInfo } = useContext(PolicyContext);
  const urlParm: any = useParams();
  const editRemoveDriver = bundle["editRemoveDriver"];
  const dispatch = useDispatch();
  const history = useHistory();

  let policyEmptyState = false;
  /** adding activeStatus to policies */
  let policiesList = policies.policis;
  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policyEmptyState = true;
    if (state.policies.length == 0) {
      policiesList = policiesList.map((data, i) => {
        if (data.policyNumber === urlParm.policyNumber) {
          data.activeStatus = true;
        } else {
          data.activeStatus = false;
        }
        return data;
      });
    }
  }

  /** get the policy details */
  function policyDetailsInfo(policyNumber, policiesList) {
    const policyFilterDetails = policiesList.find((data, i) => {
      if(data.policyNumber === policyNumber) {
        return data;
      }
    })
    
    getPolicyDetails(policyNumber).then((response) => {
      console.log("policy summary", response.policyDetailsResponse)
      const policyDetails = {...response.policyDetailsResponse, policyFilterDetails};

      // coverages schema structure
      var coveragePropertiesQnique: any = [];
      var coverageProperties: any = [];
      var coveragePropertyDescripts : any = [];
      const coveragesArray: any = [];
      var coverageTotal = 0;

      for(var i = 0; i < policyDetails.policyCoverages?.length; i++) {
        if(coveragePropertiesQnique.indexOf(policyDetails.policyCoverages[i].property) == -1) {
          coveragePropertiesQnique.push(policyDetails.policyCoverages[i].property);
          coverageProperties.push(policyDetails.policyCoverages[i]);
          coverageTotal = coverageTotal + parseInt(policyDetails.policyCoverages[i].totalPremium)
        }
        if(coveragePropertyDescripts.indexOf(policyDetails.policyCoverages[i].description) == -1) {
          coveragePropertyDescripts.push(policyDetails.policyCoverages[i].description)
        }
      }
      
      for(var j = 0; j<coveragePropertyDescripts.length; j++) {
        var coverageInfo: any = [];
        coverageInfo.name = coveragePropertyDescripts[j];
        var propertyAmounts: any = [];
        for(var k=0; k < policyDetails.policyCoverages.length; k++) {
          if(coveragePropertyDescripts[j] == policyDetails.policyCoverages[k].description) {
            propertyAmounts.push(policyDetails.policyCoverages[k]);
          }
        }
        coverageInfo.propertyAmounts = propertyAmounts;
        coveragesArray.push(coverageInfo);
      }
      // console.log("coveragesArray", coveragesArray);
      // console.log("property", coverageProperties)
      setState({
        ...state,
        policyDetails: policyDetails,
        policies: policiesList,
        currentPolicyNumber: policyNumber,
        policyCoverages: coveragesArray,
        coveragePropertiesInfo: coverageProperties,
        coverageTotal: coverageTotal
      });
    });
  }

  useEffect(() => {
    try {
      policyDetailsInfo(urlParm.policyNumber, policiesList);
    } catch (error) {
      console.log("Error policyInformation - useEffect", error);
    }
  }, [policyEmptyState]);

  /** slider properties */
  const slickSliderSettings = {
    dots: false,
    speed: 500,
    slidesToShow: 2,
    slidesToScroll: 1,
    infinite: false,
  };
  /** policy tab click function */
  const policyTabClick = (policyIndex: string) => {
    /** active state change */
    let policyNo = "";
    const policy = state.policies.map((policyData, i) => {
      if (policyIndex === i) {
        policyData.activeStatus = true;
        policyNo = policyData.policyNumber;
      } else {
        policyData.activeStatus = false;
      }
      return policyData;
    });
    dispatch(updatePolicies(policy));
    policyDetailsInfo(policyNo, policy);
  };
  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  // get the help text info
  const getHelptext = (helpText) => {
    getHelptextInfo(helpText)
      .then((response) => {
        console.log("helpText", response)
      })
      .catch((error) => {
        console.log(
          `%c Error: policyInformation.tsx - getHelptext ${JSON.stringify(error)}`,
          "color: #FF0000"
        );
      })
  }

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.policyInformation"]}
            icon="setting.svg"
            iconName="file-alt-blue-icon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <Hidden smDown>
                  <div className="ssp-p2">
                    {/* Slider */}
                    <CarouselSlider theme={theme} className="policy-slider">
                      <Slider {...slickSliderSettings}>
                        {state.policies.map((policyData, i) => {
                          return (
                            <InsuranceItemsComponent
                              insuranceInfo={policyData}
                              key={i}
                              ItemIndex={i}
                              policyTabClick={policyTabClick}
                              footerStatus="false"
                              xsSize={11}
                            />
                          );
                        })}
                      </Slider>
                    </CarouselSlider>
                    {/* ./END Slider */}
                  </div>
                </Hidden>
                {/* policy list for responsive view */}
                <Hidden mdUp>
                  <form>
                    <PolicyListDropdownComponent
                      policies={state.policies}
                      dynamicClass="select-field gray"
                      policyTabClick={policyTabClick}
                    ></PolicyListDropdownComponent>
                  </form>
                </Hidden>

                <div>
                  {/* Policy summary */}
                  <Blueheadinggrid
                    theme={theme}
                    className="ssp-mr0 min-height-auto"
                  >
                    <div className="heading ssp-p3">
                      <h3>
                        <ThemeIcon className="clipboard-list-check-white"></ThemeIcon>
                        {bundle["heading.policySummary"]}
                      </h3>
                    </div>
                    <div className="content ssp-p2">
                      <div className="bg-white ssp-p2">
                        <Grid container>
                          <Grid item xs={12} md={6}>
                            <InformationSummary theme={theme}>
                              <span className="darkblue-color">
                                {bundle["label.policyNumber"]}:{" "}
                              </span>
                              <span>{state.policyDetails?.policyNumber}</span>
                            </InformationSummary>
                          </Grid>
                          <Grid item xs={12} md={6}>
                            <InformationSummary theme={theme}>
                              <span className="darkblue-color">
                                {bundle["label.policyTerm"]}:{" "}
                              </span>
                              <span>
                                {state.policyDetails?.policyFilterDetails?.policyTerm?.startDate} -{" "}
                                {state.policyDetails?.policyFilterDetails?.policyTerm?.endDate}
                              </span>
                            </InformationSummary>
                          </Grid>
                        </Grid>
                      </div>

                      <div className="ssp-p2">
                        <Grid container>
                          <Grid item xs={12} md={6}>
                            <InformationSummary theme={theme}>
                              <span className="darkblue-color">
                                {bundle["label.policyPremium"]}:{" "}
                              </span>
                              <span>
                                <b> {bundle["label.total"]}:</b> $
                                {
                                  state?.policyDetails?.policyCoverages[0]?.totalPremium
                                }
                              </span>
                            </InformationSummary>
                          </Grid>
                        </Grid>
                      </div>
                      <div className="bg-white ssp-p2">
                        <Grid container>
                          <Grid item xs={12} md={6}>
                            <InformationSummary theme={theme}>
                              <span className="darkblue-color">
                                {bundle["label.nextPaymentDue"]}:{" "}
                              </span>
                              <span>
                                {
                                  state.policyDetails?.policyFilterDetails?.nextPaymentDueDate
                                }
                              </span>
                            </InformationSummary>
                          </Grid>
                          <Grid item xs={12} md={6}>
                            <InformationSummary theme={theme}>
                              <span className="darkblue-color">
                                {bundle["label.amountDue"]}:{" "}
                              </span>
                              <span>
                                {
                                  state.policyDetails?.policyFilterDetails?.nextPaymentDueAmount
                                }
                              </span>
                            </InformationSummary>
                          </Grid>
                        </Grid>
                        <div className="ssp-p2 ssp-dflexcenter">
                          <Grid container spacing={2}>
                            <Grid item xs={5}>
                              <Bluebutton
                                className="ssp-mr3 h-40 w-100"
                                type="button"
                                theme={theme}
                                onClick={() => navigation(`payments/${state.currentPolicyNumber}`)}
                              >
                                {bundle["label.payment"]}
                              </Bluebutton>
                            </Grid>
                            <Grid item xs={7}>
                              {state.policyDetails?.policyFilterDetails?.policyType === "Auto" && (
                                <Whitebutton
                                  className="h-40 dark-blue-border ssp-w75 ssp-ml4"
                                  type="button"
                                  theme={theme}
                                  onClick={() => navigation("autoid")}
                                >
                                  <ThemeIcon className="address-card-blue-icon bgSize-25"></ThemeIcon>{" "}
                                  {bundle["label.autiIdCard"]}
                                </Whitebutton>
                              )}
                            </Grid>
                          </Grid>
                        </div>
                      </div>
                    </div>
                  </Blueheadinggrid>
                  {/* ./END Policy summary */}
                  {/* discounts */}
                  <Blueheadinggrid
                    theme={theme}
                    className="ssp-mr0 min-height-auto"
                  >
                    <div
                      className="heading ssp-p3"
                      onClick={() => {
                        setState({
                          ...state,
                          discountsOpened: !state.discountsOpened,
                        });
                      }}
                    >
                      <h3>
                        <ThemeIcon className="piggy-bank-white-icon"></ThemeIcon>
                        <span className="ssp-pl2">
                          {bundle["heading.discounts"]}
                        </span>
                        <span className="ssp-pullright">
                          {state.discountsOpened === false && <AddCircle />}
                          {state.discountsOpened === true && <RemoveCircle />}
                        </span>
                      </h3>
                    </div>
                    {state.discountsOpened && (
                      <div className="content ssp-p2">
                        {state.policyDetails?.policyDiscounts.map(
                          (discountData: any, i, count = 0) => {
                            return (
                              <div
                                key={i}
                                className="bg-white ssp-p2 ssp-mb1 clearfix"
                              >
                                <span>{discountData?.description}</span>
                                <span className="ssp-pullright ssp-mr3">
                                  <b>{discountData?.amount}</b>
                                </span>
                              </div>
                            );
                          }
                        )}
                      </div>
                    )}
                  </Blueheadinggrid>
                  {/* ./END discounts */}
                  {/* Drivers info */}
                  {state.policyDetails?.policyFilterDetails?.policyType === "Auto" && (
                    <Blueheadinggrid
                      theme={theme}
                      className="ssp-mr0 min-height-auto"
                    >
                      <div
                        className="heading ssp-p3"
                        onClick={() => {
                          setState({
                            ...state,
                            insuredDriversOpened: !state.insuredDriversOpened,
                          });
                        }}
                      >
                        <h3>
                          <ThemeIcon className="users-white-icon bgSize-full"></ThemeIcon>
                          <span className="ssp-pl2">
                            {bundle["heading.insuredDrivers"]}
                          </span>
                          <span className="ssp-pullright">
                            {state.insuredDriversOpened === false && (
                              <AddCircle />
                            )}
                            {state.insuredDriversOpened === true && (
                              <RemoveCircle />
                            )}
                          </span>
                        </h3>
                      </div>
                      {state.insuredDriversOpened && (
                        <div className="content ssp-p2">
                          <div className="bg-white ssp-p2">
                            <Grid container>
                              <Grid item xs={6}>
                                <DarkBlueh5title theme={theme}>
                                  {bundle?.policyInfo["insuranceDrivers.text1"]}
                                </DarkBlueh5title>
                                <p className="ssp-m0">
                                  {bundle?.policyInfo["insuranceDrivers.text2"]}
                                </p>
                                <DarkblueLink
                                  theme={theme}
                                  href=""
                                  className="bold"
                                >
                                  {editRemoveDriver}
                                </DarkblueLink>
                              </Grid>
                              <Grid item xs={6}>
                                <DarkBlueh5title theme={theme}>
                                  {bundle?.policyInfo["insuranceDrivers.text3"]}
                                </DarkBlueh5title>
                                <p className="ssp-m0">
                                  {bundle?.policyInfo["insuranceDrivers.text4"]}
                                </p>
                                <DarkblueLink
                                  theme={theme}
                                  href=""
                                  className="bold"
                                >
                                  {editRemoveDriver}
                                </DarkblueLink>
                              </Grid>
                            </Grid>
                            
                          </div>
                        </div>
                      )}
                    </Blueheadinggrid>
                  )}
                  {/* ./END Drivers info */}
                </div>
              </Grid>
              <Grid item xs={12} md={8}>
                <div>
                  <Blueheadinggrid theme={theme} className="ssp-mr0">
                    <div className="heading">
                      <h3>
                        <ThemeIcon className="shield-alt-white-icon"></ThemeIcon>
                        {bundle["heading.policyCoverages"]}
                      </h3>
                    </div>
                    <div className="content ssp-p3">
                      <PolicyController>
                        <CoverageTableComponent
                          coverageInfo={state?.policyCoverages}
                          coveragePropertiesInfo={state?.coveragePropertiesInfo}
                          coverageTotal={state.coverageTotal}
                          getHelptext={getHelptext}
                          totalDiscount={state?.policyDetails?.policyDiscountTotal}
                        />
                      </PolicyController>
                    </div>
                  </Blueheadinggrid>
                </div>
              </Grid>
            </Grid>
          </div>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
