import React, { ReactElement } from "react";

export default function NotFoundPage(): ReactElement {
  return (
    <div className="white-block ssp-dflexcenter">
      <h1>404 Page</h1>
    </div>
  );
}
