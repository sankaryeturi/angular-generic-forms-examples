/* eslint-disable */
import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { Grid } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  SspformGroup,
  Blueheading,
  ErrorMessage,
} from "../../themes/styles";
import { ValidationService } from "../../_services/validation";
import { SettingsContext } from "./settingsController";
import { IChangePassword } from "./_interfaces/interface";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { CommonService } from "../../_services/commonServices";
import SuccessBlockComponent from "./_components/successBlock";
import { constantValues } from "../../config/config";
import ActionButtonsBlock from "./_components/actionButtonsBlock";
import PasswordStrengthBlock from "../../shared-components/passwordStrength/passwordStrength";

const initialState: IChangePassword = {
  currentPassword: "",
  newPassword: "",
  confirmNewPassword: "",
  lengthCheck: false,
  numberCheck: false,
  charCheck: false,
  uppercaseCheck: false,
  successMessage: "",
  failMessage: "",
  formSubmit: false,
};

export default function ChangePassword(): ReactElement {
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();
  const { submitChangePassword } = useContext(SettingsContext);
  const profile = useSelector(
    (storeState: any) => storeState.accountInfoReducer.profile
  );

  useEffect(() => {
    ValidatorForm.addValidationRule("isStrong", (value) => {
      if (state.formSubmit === false) {
        let lengthCheck = false;
        let numberCheck = false;
        let charCheck = false;
        let uppercaseCheck = false;

        if (value.length > constantValues.validationLength_8) {
          lengthCheck = true;
        }
        if (value.match(/^(?=.*[0-9]).{1,255}$/)) {
          numberCheck = true;
        }
        if (value.match(/^(?=.*[a-zA-Z]).{1,255}$/)) {
          charCheck = true;
        }
        if (value.match(/^(?=.*[A-Z]).{1,255}$/)) {
          uppercaseCheck = true;
        }
        setState({
          ...state,
          charCheck: charCheck,
          lengthCheck: lengthCheck,
          numberCheck: numberCheck,
          uppercaseCheck: uppercaseCheck,
        });
        if (lengthCheck === true && numberCheck === true && charCheck === true)
          return true;
        return false;
      } else {
        return true;
      }
    });
  });

  useEffect(() => {
    ValidationService.isPasswordMatch(state.newPassword);
  }, [state.newPassword]);

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  // changing input field value
  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };

  // submit new mailing address form
  const changePasswordFormSubmit = (e: any) => {
    alert()
    // setState({
    //   ...state,
    //   failMessage: "",
    // });
    const formInfo = {
      password: state.currentPassword,
      newPassword: state.newPassword,
      logonId: profile.userID,
    };
    submitChangePassword(formInfo)
      .then((response) => {
        setState({
          ...state,
          formSubmit: true,
          successMessage: response?.changePasswordResponseData?.data?.success,
        });
      })
      .catch((error) => {
        console.log(
          "Error: changePassword.tsx - changePasswordFormSubmit()", JSON.stringify(error)
        );
      });
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle["heading.changePasscode"]}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={8} lg={5}>
                <Blueheading theme={theme}>
                  <div className="heading">
                    <h3>
                      <span className="user-icon"></span>
                      {bundle["heading.changePasscode"]}
                    </h3>
                  </div>
                  <div className="content">
                    {/* success block */}
                    {state.formSubmit === true && (
                      <div>
                        <SuccessBlockComponent message={state.successMessage} />
                      </div>
                    )}

                    {state.formSubmit === false && (
                      <>
                        <ValidatorForm
                          onSubmit={(e) => changePasswordFormSubmit(e)}
                          autoComplete="off"
                        >
                          {/* alert message */}
                          {state.failMessage && (
                            <ErrorMessage
                              className="orange ssp-mt2 ssp-inline-block"
                              theme={theme}
                            >
                              <b>{state.failMessage}</b>
                            </ErrorMessage>
                          )}
                          <Grid container className="ssp-mt2">
                            <Grid item xs={12}>
                              <SspformGroup
                                theme={theme}
                                className="input50 ssp-mb2"
                              >
                                <TextValidator
                                  label={bundle?.changePassword?.currentPassword}
                                  fullWidth
                                  onChange={(e) => handleChange(e, "currentPassword")}
                                  name="currentPassword"
                                  value={state.currentPassword}
                                  validators={["required", "minStringLength:6"]}
                                  errorMessages={[
                                    bundle?.login?.passcodeError,
                                    bundle["validation.passMin"],
                                  ]}
                                  type="password"
                                  InputLabelProps={{
                                    shrink: true,
                                  }}
                                />
                              </SspformGroup>
                            </Grid>
                          </Grid>
                          <Grid container className="ssp-mt2">
                            <Grid item xs={12}>
                              <SspformGroup
                                className="password-strength input50 ssp-mb2"
                                theme={theme}
                              >
                                <TextValidator
                                  label={bundle?.changePassword.newPassword}
                                  fullWidth
                                  onChange={(e) =>
                                    handleChange(e, "newPassword")
                                  }
                                  name="newPassword"
                                  value={state.newPassword}
                                  validators={["required", "isStrong"]}
                                  errorMessages={[
                                    bundle?.changePassword?.newPasswordError,
                                    "",
                                  ]}
                                  type="password"
                                  InputLabelProps={{
                                    shrink: true,
                                  }}
                                />
                                {/* password strengh */}
                                <PasswordStrengthBlock
                                  theme={theme}
                                  lengthCheck={state.lengthCheck}
                                  uppercaseCheck={state.uppercaseCheck}
                                  numberCheck={state.numberCheck}
                                  charCheck={state.charCheck}
                                  passStrengthMin={
                                    bundle?.validation?.passStrengthMin
                                  }
                                  passStrengthUppercase={
                                    bundle?.validation?.passStrengthUppercase
                                  }
                                  passStrengthNumber={
                                    bundle?.validation?.passStrengthNumber
                                  }
                                  passStrengthSpcChar={
                                    bundle?.validation?.passStrengthSpcChar
                                  }
                                />
                              </SspformGroup>
                            </Grid>
                          </Grid>
                          <Grid container className="ssp-mt2">
                            <Grid item xs={12}>
                              <SspformGroup theme={theme} className="input50">
                                <TextValidator
                                  label={
                                    bundle?.changePassword?.confirmPassword
                                  }
                                  fullWidth
                                  onChange={(e) =>
                                    handleChange(e, "confirmNewPassword")
                                  }
                                  name="confirmNewPassword"
                                  value={state.confirmNewPassword}
                                  validators={["required", "isPasswordMatch"]}
                                  errorMessages={[
                                    bundle?.changePassword
                                      ?.confirmPasswordError,
                                    bundle[
                                      "validation.newConfirmPasswordMatch"
                                    ],
                                  ]}
                                  type="password"
                                  InputLabelProps={{
                                    shrink: true,
                                  }}
                                />
                              </SspformGroup>
                            </Grid>
                          </Grid>

                          <ActionButtonsBlock
                            blockClasses="ssp-mt4 ssp-align-right"
                            cancelActionName={bundle["button.cancel"]}
                            formActionName={bundle["button.submit"]}
                            navigation={navigation}
                            navigationPathName="settings"
                          />
                        </ValidatorForm>
                      </>
                    )}
                  </div>
                </Blueheading>
              </Grid>
            </Grid>
          </div>
        </div>

        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
