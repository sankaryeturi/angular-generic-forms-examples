import { URL } from "../../../config/constants";
import { CommonService } from "../../../_services/commonServices";

interface ServerResponse {
  data: any;
  headers: Headers;
}

export class SettingsService {
  /**
   * getPolicies
   */
  public static async getCurrentMailingAddress(): Promise<[]> {
    const url = URL.CURRENT_MAIL_ADDRESS;
    const { data } = await CommonService.request("get", url);
    return data;
  }

  /**
   * method for change current mail address
   */
  public static async submitMailingAddress(mailAddressInfo): Promise<[]> {
    const url = URL.CHANGE_MAILING_ADDRESS;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "post",
      url,
      mailAddressInfo,
      loginToken
    );
    return data;
  }
  /**
   * method for change email address
   */
  public static async submitChangeEmail(changeEmailInfo): Promise<[]> {
    const url = URL.CHANGE_EMAIL;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "post",
      url,
      changeEmailInfo,
      loginToken
    );
    return data;
  }
  /**
   * method for change password
   */
  public static async submitChangePassword(inputReq): Promise<[]> {
    const url = URL.CHANGE_PASSWORD;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "post",
      url,
      inputReq,
      loginToken
    );
    return data;
  }
  /**
   * method for change user id
   */
  public static async submitChangeUserid(changeUseridInfo): Promise<[]> {
    const url = URL.CHANGE_USERID;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "post",
      url,
      changeUseridInfo,
      loginToken
    );
    return data;
  }
  /** paperless statement status change */
  public static async paperlessPreference(inputData): Promise<[]> {
    const url = URL.PAPERLESS_PREFERENCE;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "post",
      url,
      inputData,
      loginToken
    );
    return data;
  }
  /** change PhoneNumber */
  public static async changePhoneNumber(inputData): Promise<[]> {
    const url = URL.CHANGE_PHONE_NO;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "post",
      url,
      inputData,
      loginToken
    );
    return data;
  }
  /** get user security questions */
  public static async getUserSecurityQus(inputReq): Promise<[]> {
    const url = URL.USER_SECURITY_QUESTIONS;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("post", url, inputReq, loginToken);
    return data;
  }
  /** update user security questions */
  public static async updateSecurityQuestions(inputReq): Promise<[]> {
    const url = URL.UPDATE_SECURITY_QUESTIONS;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("post", url, inputReq, loginToken);
    return data;
  }
  /** get user email id */
  public static async getUserEmail(): Promise<string> {
    const url = URL.GET_USER_EMAILID;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("get", url, "", loginToken);
    return data;
  }

  /** get user email id */
  public static async getUserPhoneNo(): Promise<[]> {
    const url = URL.GET_USER_PHONENO;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("get", url, "", loginToken);
    return data;
  }
  /** get mailing addresses policies */
  public static async getMailingPolicies(): Promise<[]> {
    const url = URL.GET_MAILING_POLICIES;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("get", url, "", loginToken);
    return data;
  }
  /** get user notification info */
  public static async getUserNotificationInfo(): Promise<[]> {
    const url = URL.GET_USER_NORIFICATION_INFO;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("get", url, "", loginToken);
    return data;
  }

  /** get user notification info */
  public static async submitNotificationPref(inputReq): Promise<any> {
    const url = URL.UPDATE_NOTIFICATION_PREF;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("post", url, inputReq, loginToken);
    return data;
  }
}
