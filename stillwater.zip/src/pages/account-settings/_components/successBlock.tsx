import React, { ReactElement, useContext } from "react";
import { useHistory } from "react-router-dom";
import { Darkbluebutton, GreenHeading } from "../../../themes/styles";
import { ThemeContext } from "../../../themes";

export default function SuccessBlockComponent(props): ReactElement {
  const { theme } = useContext(ThemeContext);
  const history = useHistory();

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };
  return (
    <>
      <GreenHeading theme={theme}>SUCCESS</GreenHeading>
      <p className="ssp-m0">{props.message}</p>
      <div className="ssp-align-center">
        <Darkbluebutton
          onClick={() => navigation("settings")}
          className="w-25 ssp-mt5 "
          theme={theme}
        >
          <span>Close</span>
        </Darkbluebutton>
      </div>
    </>
  );
}
