import React, { ReactElement, useContext } from "react";
import { ThemeContext } from "../../../themes";

import { Darkbluebutton, Bluebutton } from "../../../themes/styles";

export default function ActionButtonsBlock(props: any): ReactElement {
  const { theme } = useContext(ThemeContext);
  const navigation = (path) => {
    props.navigation(path);
  };
  return (
    <div className={props.blockClasses}>
      <Bluebutton
        className="ssp-mr3 ssp-px6"
        type="button"
        theme={theme}
        onClick={() => navigation(props.navigationPathName)}
      >
        {props.cancelActionName}
      </Bluebutton>
      <Darkbluebutton className="ssp-px6" theme={theme}>
        <span>{props.formActionName}</span>
      </Darkbluebutton>
    </div>
  );
}
