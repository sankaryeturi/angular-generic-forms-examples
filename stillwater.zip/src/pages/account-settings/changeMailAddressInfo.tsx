import React, { ReactElement, useContext } from "react";
import { useHistory } from "react-router-dom";
import { Grid } from "@material-ui/core";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  ListwithIcons,
  Darkbluebutton,
  Bluebutton,
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";

export default function ChangeMailAddressInfo(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  const policyDescriptionList = [
    {
      iconName: "ssp-carblackicon",
      labelName: bundle["label.auto"],
      description: bundle["changeMailingAddressInfo.autoInfo"],
    },
    {
      iconName: "ssp-homeblackicon",
      labelName: bundle["label.home"],
      description: bundle["changeMailingAddressInfo.homeinfo"],
    },
    {
      iconName: "ssp-hotelblackicon",
      labelName: bundle["label.condo"],
      description: bundle["changeMailingAddressInfo.condoInfo"],
    },
    {
      iconName: "ssp-buildingblackicon",
      labelName: bundle["label.apartment"],
      description: bundle["changeMailingAddressInfo.apartmentInfo"],
    },
    {
      iconName: "ssp-buildingblackicon",
      labelName: bundle["label.tenant"],
      description: bundle["changeMailingAddressInfo.tenantInfo"],
    },
    {
      iconName: "ssp-umbrellablackicon",
      labelName: bundle["label.umbrella"],
      description: bundle["changeMailingAddressInfo.umbrellaInfo"],
    },
    {
      iconName: "ssp-homedamageblackicon",
      labelName: bundle["label.earthquake"],
      description: bundle["changeMailingAddressInfo.earthquakeInfo"],
    },
  ];

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle["changeMailingAddress.subHeading"]}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={9} lg={6}>
                <p className="ssp-f-bold ssp-mb0">
                  {bundle["label.areYouMoving"]}
                </p>
                <p className="ssp-mt0">
                  {bundle["changeMailingAddressInfo.P1"]}
                  <a href="/">{bundle["changeMailingAddressInfo.P1A"]} </a>
                </p>

                <ListwithIcons theme={theme}>
                  {policyDescriptionList.map((data, i) => (
                    <li className={data.iconName} key={i}>
                      <b>{data.labelName}:</b>
                      {data.description}
                    </li>
                  ))}
                </ListwithIcons>

                <div className="ssp-mt4 ssp-align-center">
                  <Bluebutton
                    className="ssp-mb3 ssp-mr3 ssp-px6"
                    type="button"
                    theme={theme}
                    onClick={() => navigation("settings")}
                  >
                    {bundle["button.cancel"]}
                  </Bluebutton>
                  <Darkbluebutton
                    className="ssp-px6"
                    theme={theme}
                    onClick={() => navigation("changemailaddress")}
                  >
                    {bundle["button.continue"]}
                  </Darkbluebutton>
                </div>
              </Grid>
            </Grid>
          </div>
        </div>

        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
