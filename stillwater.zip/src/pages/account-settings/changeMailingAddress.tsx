/* eslint-disable */
import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import {
  Checkbox,
  Select,
  MenuItem,
  InputLabel,
  Grid,
} from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  Blueborder,
  Blueh6title,
  SspformGroup,
  Darkbluebutton,
  Bluebutton,
  ThemeIcon,
  ErrorMessage
} from "../../themes/styles";
import { SettingsContext } from "./settingsController";
import { IMailingAddress } from "./_interfaces/interface";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { CommonService } from "../../_services/commonServices";

const initialState: IMailingAddress = {
  address: "",
  city: "",
  stateName: "",
  zipcode: "",
  policies: [],
  selectedPolicies: [],
  formSubmit: false,
  states: [],
};

export default function ChangeMailingAddress(): ReactElement {
  const [state, setState] = useState(initialState);
  const [states, setStates] = useState(initialState.states);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const { mailingAddressError, submitMailAddress, getMailingPolicies } = useContext(SettingsContext);
  const history = useHistory();

  useEffect(() => {    
    // get the states list
    const states = CommonService.getState();
    states.then((response: any) => {
      setStates(response.data.states);
    });
    // get mailing policies list
    getMailingPolicies()
      .then((response) => {
        console.log("mailing policies", response.mailingPolicies?.data?.policiesMailingAddress);
        setState({
          ...state,
          policies: response.mailingPolicies?.data?.policiesMailingAddress,
        });
      })
      .catch((error) => {
        CommonService.consolError(error, "changeMailingAddress.tsx", "getMailingPolicies");
      })
  }, []);

  // changing input field value
  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };
  // check box functionality
  const handleCheck = (e: any, index): void => {
    const policyInfo = state.policies.map((policyData, i) => {
      if (i === index) {
        policyData.checkedStatus = !policyData.checkedStatus;
      }
      return policyData;
    });
    setState({
      ...state,
      policies: policyInfo,
    });
  };
  //state name change
  const stateNameChange = (e: any): void => {
    const val = e.target.value;
    setState({
      ...state,
      stateName: val,
    });
  };
  // submit new mailing address form
  const addressFormSubmit = (e: any): void => {
    const checkedPolicies: any = [];
    const selectedPolicies: any = [];
    state.policies.map((policyData: any, i) => {
      if (policyData.checkedStatus === true) {
        checkedPolicies.push(policyData.policyNumber);
        selectedPolicies.push(policyData);
      }
    });
    const formInfo = {
      policyNumbers: checkedPolicies,
      mailingAddress: {
        line1: state.address,
        line2: "",
        city: state.city,
        state: state.stateName,
        zipCode: state.zipcode,
      },
    };
    // console.log(formInfo);
    submitMailAddress(formInfo)
      .then((response) => {
        setState({
          ...state,
          formSubmit: true,
          selectedPolicies: selectedPolicies,
        });
      })
      .catch((error) =>{
        CommonService.consolError(error, "changeMailingAddress.tsx", "submitMailAddress");
      }
      );
  };
  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  const policiesList = state.policies.map((policyData, i) => {
    const icon = CommonService.policyIcon(policyData.policyType);
    return (
      <Blueborder
        className={`${policyData.checkedStatus ? "active" : ""} ssp-mb3`}
        theme={theme}
        key={i}
      >
        <Checkbox
          checked={policyData.checkedStatus}
          onChange={(e) => handleCheck(e, i)}
          name="checkedB"
          color="primary"
        />
        <p className="ssp-inline-block">
          <b>
            <ThemeIcon
              className={icon + (policyData.checkedStatus ? " active" : "")}
            ></ThemeIcon>
            {policyData.policyType} {bundle["text.policy"]}
            {policyData.policyNumber} - 
            {policyData.line1},
            {policyData.state},
            {policyData.zipCode},
          </b>
        </p>
      </Blueborder>
    );
  });
  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle["changeMailingAddress.subHeading"]}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={9} lg={6}>
                {/* success block for after change the mailing address */}
                {state.formSubmit === true && (
                  <div>
                    <p>{bundle["changeMailingAddress.success"]}</p>
                    <ul>
                      {state.selectedPolicies.length !== 0 &&
                        state.selectedPolicies.map((policyData, i) => (
                          <li className="ssp-py2" key={i}>
                            <ThemeIcon
                              className={
                                CommonService.policyIcon(
                                  policyData.policyType
                                ) + " active"
                              }
                            ></ThemeIcon>
                            <span className="ssp-blue bold">
                              {policyData?.policyType} {bundle["text.policy"]}
                              {policyData?.policyNumber} - {state.address}.{" "}
                              {state.city} {state.stateName} - {state.zipcode}
                            </span>
                          </li>
                        ))}
                    </ul>
                    <Blueh6title theme={theme} className="ssp-mt5">
                      {bundle["heading.newmailadd"]}
                    </Blueh6title>
                    <p className="bold">
                      {state.address} <br /> {state.city}, <br />
                      {state.stateName} {state.zipcode}
                    </p>
                  </div>
                )}
                {/* ./END success block */}
                {state.formSubmit === false && (
                  <>
                    <p>{bundle["text.addressnote"]}</p>
                    <span>
                      <b>{bundle["text.changemailingaddpolicy"]}</b>
                    </span>
                    
                    {/* Policies list */}
                    <div className="ssp-mt3">{policiesList}</div>
                    {/* ./END Policies list */}

                    <Blueh6title theme={theme} className="ssp-mt5">
                      {bundle["heading.newmailadd"]}
                    </Blueh6title>

                    <ValidatorForm
                      onSubmit={(e) => addressFormSubmit(e)}
                      autoComplete="off"
                    >
                      <Grid container className="ssp-mt2">
                        <Grid item xs={12} md={8}>
                          <SspformGroup
                            theme={theme}
                            className="gray input50 ssp-mb3"
                          >
                            <TextValidator
                              label={bundle["changemailadd.address"]}
                              fullWidth
                              onChange={(e) => handleChange(e, "address")}
                              name="address"
                              value={state.address}
                              validators={["required"]}
                              errorMessages={[
                                bundle["changemailadd.addresserror"],
                              ]}
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </SspformGroup>
                        </Grid>
                      </Grid>

                      <Grid container className="ssp-mt2">
                        <Grid item xs={12} md={8}>
                          <SspformGroup
                            theme={theme}
                            className="gray input50 ssp-mb3"
                          >
                            <TextValidator
                              label={bundle["changemailadd.city"]}
                              fullWidth
                              onChange={(e) => handleChange(e, "city")}
                              name="city"
                              value={state.city}
                              validators={["required"]}
                              errorMessages={[
                                bundle["changemailadd.cityerror"],
                              ]}
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </SspformGroup>
                        </Grid>
                      </Grid>

                      <Grid container className="ssp-mt2" spacing={2}>
                        <Grid item xs={12} md={4}>
                          <SspformGroup
                            theme={theme}
                            className="gray input50 ssp-mb3"
                          >
                            <InputLabel shrink>
                              {bundle["changemailadd.state"]}
                            </InputLabel>
                            <Select
                              className="select-field gray"
                              value={state.stateName}
                              onChange={(e) => stateNameChange(e)}
                            >
                              {states &&
                                states.map((statesData, j) => (
                                  <MenuItem value={statesData.code} key={j}>
                                    {statesData.description}
                                  </MenuItem>
                                ))}
                            </Select>
                          </SspformGroup>
                        </Grid>
                        <Grid item xs={12} md={4}>
                          <SspformGroup
                            theme={theme}
                            className="gray input50 ssp-mb3"
                          >
                            <TextValidator
                              label={bundle["changemailadd.zipcode"]}
                              fullWidth
                              onChange={(e) => handleChange(e, "zipcode")}
                              name="zipcode"
                              type="number"
                              value={state.zipcode}
                              validators={["required"]}
                              errorMessages={[
                                bundle["changemailadd.zipcodeerror"],
                              ]}
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </SspformGroup>
                        </Grid>
                      </Grid>

                      {/* error message block */}
                      {mailingAddressError && (
                        <ErrorMessage
                          className="orange ssp-mt2 ssp-inline-block"
                          theme={theme}
                        >
                          <b>{mailingAddressError}</b>
                        </ErrorMessage>
                      )}
                      <div className="ssp-mt6">
                        <Bluebutton
                          theme={theme}
                          onClick={() => navigation("settings")}
                          className="ssp-mr3 ssp-px6"
                        >
                          {bundle["button.cancel"]}
                        </Bluebutton>
                        <Darkbluebutton theme={theme} className="ssp-px6">
                          <span>{bundle["button.submit"]}</span>
                        </Darkbluebutton>
                      </div>
                    </ValidatorForm>
                  </>
                )}
              </Grid>
            </Grid>
          </div>
        </div>

        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
