import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import {
  Appbodycontainer,
  Blueheadinggrid,
  PacificBlueborder,
  Anchor,
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Grid,
  FormControlLabel,
  withStyles,
  Theme,
  createStyles,
  Switch,
  Hidden,
} from "@material-ui/core";
import { standard } from "../../themes/standard";
import { AddCircle, RemoveCircle } from "@material-ui/icons";
import { SettingsContext } from "./settingsController";

const IOSSwitch = withStyles((theme: Theme) =>
  createStyles({
    root: {
      width: 42,
      height: 26,
      padding: 0,
      margin: theme.spacing(1),
    },
    switchBase: {
      padding: 1,
      "&$checked": {
        transform: "translateX(16px)",
        color: theme.palette.common.white,
        "& + $track": {
          backgroundColor: standard.darkBlue,
          opacity: 1,
          border: "none",
        },
      },
      "&$focusVisible $thumb": {
        color: standard.darkBlue,
        border: "6px solid #fff",
      },
    },
    thumb: {
      width: 24,
      height: 24,
    },
    track: {
      borderRadius: 26 / 2,
      border: `1px solid ${theme.palette.grey[400]}`,
      backgroundColor: theme.palette.grey[50],
      opacity: 1,
      transition: theme.transitions.create(["background-color", "border"]),
    },
    checked: {},
    focusVisible: {},
  })
)(({ classes, ...props }: any) => {
  return (
    <Switch
      focusVisibleClassName={classes.focusVisible}
      disableRipple
      classes={{
        root: classes.root,
        switchBase: classes.switchBase,
        thumb: classes.thumb,
        track: classes.track,
        checked: classes.checked,
      }}
      {...props}
    />
  );
});

const initialState = {
  statementStatus: false,
  faqOpened: false,
  failMessage: null,
  successMessage: "",
};
export default function PaperlessStatementComponent(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const [state, setState] = useState(initialState);
  const { changePaperlessPreference } = useContext(SettingsContext);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);

  let policyEmptyState = false;
  let policiesList = policies.policis;

  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policyEmptyState = true;
  }

  useEffect(() => {
    const paperLessState = policiesList[0]?.paperlessYN;
    if (paperLessState === "Y") {
      setState({ 
        ...state, 
        statementStatus: true,
        successMessage: bundle["paperlessPreference.successMessage"]
      });
    }
  }, [policyEmptyState]);

  /** changing the paperless statement status */
  const handleChange = (e) => {
    let input: any;
    if (e.target.checked === true) {
      input = "Y";
    } else {
      input = "N";
    }

    setState({ ...state, statementStatus: e.target.checked });
    const inputData = {
      suppressNY: input,
    };

    // api call
    changePaperlessPreference(inputData)
      .then((response) => {
        
      })
      .catch((error) => {
        setState({
          ...state,
          failMessage: error?.errors[0]?.error,
        });
        console.log("Error: paperless.tsx - handleChange()", error);
      });
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle["heading.paperlesspreferences"]}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={12}>
                <Blueheadinggrid
                  theme={theme}
                  className="min-height-auto ssp-mr0"
                >
                  <div className="heading ssp-p3">
                    <h3>{bundle["heading.paperlesspreferences"]}</h3>
                  </div>
                  <div className="content ssp-p3">
                    <p className="ssp-w50 ssp-mt0">
                      {bundle["text.dummycontentsmall"]}
                    </p>

                    <Grid container className="ssp-mb6 ssp-mt5">
                      <Grid item xs={12} md={9} lg={6}>
                        <PacificBlueborder className="ssp-p3" theme={theme}>
                          <div>
                            <span className="ssp-blue bold ssp-pl1 ssp-dBlock ssp-mb3 font16Bold">
                              <span className="ssp-mr6">
                                {bundle["paperlessPreference.content1"]}
                              </span>
                              <FormControlLabel
                                control={
                                  <IOSSwitch
                                    checked={state.statementStatus}
                                    onChange={(e) => handleChange(e)}
                                  />
                                }
                                label=""
                              />
                            </span>
                            <i>{bundle["paperlessPreference.content2"]}</i>
                            {/* success message in responsive view */}
                            <Hidden mdUp>
                              <p className="bold">{state.successMessage}</p>
                            </Hidden>
                          </div>
                        </PacificBlueborder>

                        <Anchor
                          href="#"
                          onClick={(e) => e.preventDefault}
                          theme={theme}
                          className="text-left dark-blue bold ssp-mt5 underline"
                        >
                          {bundle["text.paperlessTermsConditions"]}
                        </Anchor>
                      </Grid>

                      {/* success message in desktop view */}
                      {state.statementStatus && 
                        <Hidden mdDown>
                          <Grid item xs={12} md={4}>
                            <p className="ssp-pt5 ssp-pl4 bold">
                              {state.successMessage}
                            </p>
                          </Grid>
                        </Hidden>
                      }
                    </Grid>
                  </div>
                </Blueheadinggrid>
              </Grid>
            </Grid>

            {/* info & FAQs */}
            <Grid container>
              <Grid item xs={12} md={12}>
                <Blueheadinggrid
                  theme={theme}
                  className="min-height-auto ssp-mr0"
                >
                  <div
                    className="heading ssp-p3"
                    onClick={() => {
                      setState({
                        ...state,
                        faqOpened: !state.faqOpened,
                      });
                    }}
                  >
                    <h3>
                      {bundle["heading.paperlesspreferencesInfo"]}
                      <span className="ssp-pullright">
                        {state.faqOpened === false && <AddCircle />}
                        {state.faqOpened === true && <RemoveCircle />}
                      </span>
                    </h3>
                  </div>
                  {state.faqOpened && <div className="content ssp-p3">Hi</div>}
                </Blueheadinggrid>
              </Grid>
            </Grid>
          </div>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
