import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { Grid } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  SspformGroup,
  Blueheading,
  Darkbluebutton,
  ErrorMessage,
  Bluebutton,
} from "../../themes/styles";
import { ValidationService } from "../../_services/validation";
import { SettingsContext } from "./settingsController";
import { IChangeUserID } from "./_interfaces/interface";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { CommonService } from "../../_services/commonServices";
import SuccessBlockComponent from "./_components/successBlock";

const initialState: IChangeUserID = {
  userId: "stillwater123",
  currentPassword: "",
  newUserid: "",
  confirmNewUserid: "",
  disableField: true,
  successMessage: null,
  failMessage: null,
  formSubmit: false,
};

export default function ChangeUserId(): ReactElement {
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();
  const { submitChangeUserid } = useContext(SettingsContext);
  const profile = useSelector(
    (storeState: any) => storeState.accountInfoReducer.profile
  );

  let emptyState = false;
  if (profile?.length === 0) {
    emptyState = true;
  }

  const enableField = (e) => {
    const currentPassword = state.currentPassword;
    let disableField;
    if (currentPassword.length >= 1) {
      disableField = false;
    } else {
      disableField = true;
    }
    setState({ ...state, disableField: disableField });
  };

  useEffect(() => {
    setState({
      ...state,
      userId: profile?.userID,
    });
  }, [emptyState]);

  useEffect(() => {
    ValidationService.isPasswordMatch(state.newUserid);
  }, [state.newUserid]);

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  // changing input field value
  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };

  // submit change User Id form
  const changeUserIdFormsubmit = (e: any): void => {
    const formInfo = {
      logonId: profile?.userID,
      newLogonId: state.newUserid,
    };
    submitChangeUserid(formInfo)
      .then((response) => {
        if (response?.changeUseridResponseData?.status === 200) {
          setState({
            ...state,
            formSubmit: true,
            successMessage: bundle?.changeUserid?.successMessage,
          });
        }
      })
      .catch((error) => {
        // const response = CommonService.cookieError(error);
        // if (response === false) {
        //   setState({
        //     ...state,
        //     failMessage: error?.errors[0]?.error,
        //   });
        // }
        console.log(
          "Error: changeUserid.tsx - changeUserIdFormsubmit()",
          error
        );
      });
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle?.changeUserid?.subHeading}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={8} lg={5}>
                <Blueheading theme={theme}>
                  <div className="heading">
                    <h3>
                      <span className="user-icon"></span>
                      {bundle["heading.changeuserid"]}
                    </h3>
                  </div>
                  <div className="content">
                    {/* success block */}
                    {state.formSubmit === true && (
                      <div>
                        <SuccessBlockComponent message={state.successMessage} />
                      </div>
                    )}
                    {state.formSubmit === false && (
                      <>
                        <div>
                          <strong>{bundle?.changeUserid?.label1}</strong>
                          <span>{state.userId}</span>
                        </div>
                        {/* alert message */}
                        {state.failMessage && (
                          <ErrorMessage
                            className="orange ssp-mt2 ssp-inline-block"
                            theme={theme}
                          >
                            <b>{state.failMessage}</b>
                          </ErrorMessage>
                        )}
                        <ValidatorForm
                          onSubmit={(e) => changeUserIdFormsubmit(e)}
                          autoComplete="off"
                        >
                          <Grid container className="ssp-mt2">
                            <Grid item xs={12}>
                              <SspformGroup
                                theme={theme}
                                className="input50 ssp-mb2"
                              >
                                <TextValidator
                                  label={bundle?.changeUserid?.oldPasswordLabel}
                                  fullWidth
                                  onChange={(e) =>
                                    handleChange(e, "currentPassword")
                                  }
                                  onKeyPress={(e) => enableField(e)}
                                  onKeyUp={(e) => enableField(e)}
                                  name="currentPassword"
                                  value={state.currentPassword}
                                  validators={["required"]}
                                  errorMessages={[
                                    bundle[
                                      "validation.currentPassworeRequired"
                                    ],
                                  ]}
                                  InputLabelProps={{
                                    shrink: true,
                                  }}
                                  type="password"
                                />
                              </SspformGroup>
                            </Grid>
                          </Grid>
                          <Grid container className="ssp-mt2">
                            <Grid item xs={12}>
                              <SspformGroup
                                theme={theme}
                                className="input50 ssp-mb2"
                              >
                                <TextValidator
                                  label={bundle?.changeUserid?.newUseridLabel}
                                  fullWidth
                                  onChange={(e) => handleChange(e, "newUserid")}
                                  name="newUserid"
                                  value={state.newUserid}
                                  type="text"
                                  validators={[
                                    "required",
                                    "minStringLength:6",
                                    "maxStringLength:32",
                                  ]}
                                  errorMessages={[
                                    bundle?.changeUserid?.newUseridError,
                                    bundle?.changeUserid?.userIdMinChar,
                                    bundle?.validation?.useridMaximum,
                                  ]}
                                  InputLabelProps={{
                                    shrink: true,
                                  }}
                                  InputProps={{
                                    readOnly: state.disableField,
                                  }}
                                />
                              </SspformGroup>
                            </Grid>
                          </Grid>
                          <Grid container className="ssp-mt2">
                            <Grid item xs={12}>
                              <SspformGroup
                                theme={theme}
                                className="input50 ssp-mb2"
                              >
                                <TextValidator
                                  label={"Confirm New User ID"}
                                  fullWidth
                                  onChange={(e) =>
                                    handleChange(e, "confirmNewUserid")
                                  }
                                  name="confirmNewUserid"
                                  type="text"
                                  value={state.confirmNewUserid}
                                  validators={["required", "isPasswordMatch"]}
                                  errorMessages={[
                                    bundle?.changeUserid?.confirmNewUseridError,
                                    bundle?.changeUserid?.userIdMatchError,
                                  ]}
                                  InputLabelProps={{
                                    shrink: true,
                                  }}
                                  InputProps={{
                                    readOnly: state.disableField,
                                  }}
                                />
                              </SspformGroup>
                            </Grid>
                          </Grid>
                          <div className="ssp-mt4 ssp-align-right">
                            <Bluebutton
                              className="ssp-mr3 min-w150"
                              type="button"
                              theme={theme}
                              onClick={() => navigation("settings")}
                            >
                              {bundle["button.cancel"]}
                            </Bluebutton>
                            <Darkbluebutton
                              disabled={state.disableField}
                              className={`min-w150 ${
                                state.disableField ? "disableField" : ""
                              }`}
                              theme={theme}
                            >
                              <span>{bundle["button.submit"]}</span>
                            </Darkbluebutton>
                          </div>
                        </ValidatorForm>
                      </>
                    )}
                  </div>
                </Blueheading>
              </Grid>
            </Grid>
          </div>
        </div>

        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
