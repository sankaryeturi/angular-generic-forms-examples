export interface IMailingAddress {
  address: string;
  city: string;
  stateName: string;
  zipcode: string;
  policies: any;
  selectedPolicies: any;
  formSubmit: boolean;
  states: any;
}

export interface IChangeEmailAddress {
  oldEmail: string | null;
  email: string | null;
  confirmEmail: string | null;
  successMessage: any;
  formSubmit: boolean;
}

export interface IChangePassword {
  currentPassword: any;
  newPassword: any;
  confirmNewPassword: any;
  numberCheck: boolean;
  charCheck: boolean;
  lengthCheck: boolean;
  uppercaseCheck: boolean;
  successMessage: any;
  failMessage: any;
  formSubmit: boolean;
}

export interface IChangeUserID {
  userId: string | null;
  currentPassword: any;
  newUserid: any;
  confirmNewUserid: any;
  successMessage: string | null;
  failMessage: string | null;
  disableField: boolean;
  formSubmit: boolean;
}

export interface IChangePhonenumber {
  primaryNumber: any;
  secondaryNumber: any;
  failMessage: any;
  successMessage: any;
  formSubmit: boolean;
}
