import styled from "styled-components";

export const DarkGrayLine = styled.hr`
    border: 1px solid #CACACA;
    width: 100%;
`