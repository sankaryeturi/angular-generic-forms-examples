import React, { ReactElement, ReactNode, useState, createContext } from "react";
import { SettingsService } from "./_services/settingsService";

interface SettingControllerProps {
  children: ReactNode;
}

interface SettingState {
  currentMailingAddr: any;
  error: any;
  mailingAddressError: any;
  changeEmailResponseData: any;
  changeEmailError: any;
  changePasswordResponseData: any;
  changePasswordError: any;
  changeUseridResponseData: any;
  changeUseridError: any;
  userProfile: any;
  profileError: any;
  paperlessPrefResponseData: any;
  paperlessPrefError: any;
  changePhoneNumberResponseData: any;
  changePhoneNumberError: any;
  UserSecurityQusResponseData: any;
  changeMailingAddress: any;
  getUserEmailError: any;
  userEmail: string | null;
  userPhoneNo: any;
  userPhoneNoError: any;
  mailingPolicies: any;
  mailingPoliciesError: any;
  updatesecurityQusRes: any;
  userNotificationsRes: any;
  submitNotificationsRes: any;
}

interface SettingStateContext extends SettingState {
  readonly submitMailAddress: (mailAddressInfo: any) => any;
  readonly submitChangeEmail: (changeEmailInfo: any) => any;
  readonly submitChangePassword: (changeEmailInfo: any) => any;
  readonly submitChangeUserid: (changeUseridInfo: any) => any;
  readonly changePaperlessPreference: (changeInfo) => any;
  readonly changeUserPhoneNumber: (phoneNoInfo) => any;
  readonly getUserSecurityQus: (userId) => any;
  readonly getUserEmail: () => any;
  readonly getUserPhoneNo: () => any;
  readonly getMailingPolicies: () => any;
  readonly updateSecurityQuestions: (inputReq) => any;
  readonly getUserNotificationInfo: () => any;
  readonly submitNotificationPref: (inputReq) => any;
}

const initialState: SettingState = {
  currentMailingAddr: null,
  error: null,
  mailingAddressError: null,
  changeEmailResponseData: [],
  changeEmailError: null,
  changePasswordResponseData: null,
  changePasswordError: null,
  changeUseridResponseData: null,
  changeUseridError: null,
  userProfile: null,
  profileError: null,
  paperlessPrefResponseData: [],
  paperlessPrefError: null,
  changePhoneNumberResponseData: [],
  changePhoneNumberError: null,
  UserSecurityQusResponseData: [],
  changeMailingAddress: [],
  getUserEmailError: null,
  userEmail: null,
  userPhoneNo: null,
  userPhoneNoError: null,
  mailingPolicies: null,
  mailingPoliciesError: null,
  updatesecurityQusRes: null,
  userNotificationsRes: null,
  submitNotificationsRes: null
};

const initialContext: SettingStateContext = {
  ...initialState,
  submitMailAddress: invalidContext,
  submitChangeEmail: invalidContext,
  submitChangePassword: invalidContext,
  submitChangeUserid: invalidContext,
  changePaperlessPreference: invalidContext,
  changeUserPhoneNumber: invalidContext,
  getUserSecurityQus: invalidContext,
  getUserEmail: invalidContext,
  getUserPhoneNo: invalidContext,
  getMailingPolicies: invalidContext,
  updateSecurityQuestions: invalidContext,
  getUserNotificationInfo: invalidContext,
  submitNotificationPref: invalidContext
};

export const SettingsContext = createContext(initialContext);

export function SettingsController(
  props: SettingControllerProps
): ReactElement {
  const [state, setState] = useState(initialState);
  /** get mailing addresses policies */
  async function getMailingPolicies(): Promise<any> {
    try {
      const responseData = await SettingsService.getMailingPolicies();
      setState({
        ...state,
        mailingPolicies: responseData,
        mailingAddressError: null,
      });
      return {
        ...initialState,
        mailingPolicies: responseData,
        mailingAddressError: null,
      };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          mailingAddressError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  // for change current mail address
  async function submitMailAddress(mailAddressInfo: any): Promise<any> {
    try {
      const mailInfo = await SettingsService.submitMailingAddress(
        mailAddressInfo
      );
      setState({
        ...state,
        changeMailingAddress: mailInfo,
        mailingAddressError: null,
      });
      return {
        ...initialState,
        changeMailingAddress: mailInfo,
        mailingAddressError: null,
      };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          mailingAddressError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  /** get user email id */
  async function getUserEmail(): Promise<any> {
    try {
      const responseData = await SettingsService.getUserEmail();
      setState({ ...state, userEmail: responseData, changeEmailError: null });
      return {
        ...initialState,
        userEmail: responseData,
        changeEmailError: null,
      };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          changeEmailError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  // for change E-mail address
  async function submitChangeEmail(changeEmailInfo: any): Promise<any> {
    try {
      const responseData = await SettingsService.submitChangeEmail(
        changeEmailInfo
      );
      setState({
        ...state,
        changeEmailResponseData: responseData,
        changeEmailError: null,
      });
      return {
        ...initialState,
        changeEmailResponseData: responseData,
        changeEmailError: null,
      };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          changeEmailError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  // change user passowrd
  async function submitChangePassword(changePasswordInfo: any): Promise<any> {
    try {
      const responseData = await SettingsService.submitChangePassword(
        changePasswordInfo
      );
      setState({ ...state, changePasswordResponseData: responseData });
      return { ...initialState, changePasswordResponseData: responseData };
    } catch (error) {
      setState({ ...initialState, changePasswordError: error });
      throw error;
      // return {...initialState, changePasswordError: error}
    }
  }
  // change user id
  async function submitChangeUserid(changeUseridInfo): Promise<any> {
    try {
      const responseData = await SettingsService.submitChangeUserid(
        changeUseridInfo
      );
      setState({ ...state, changeUseridResponseData: responseData });
      return { ...initialState, changeUseridResponseData: responseData };
    } catch (error) {
      setState({ ...initialState, changeUseridError: error });
      throw error;
      //return {...initialState, changeUseridError: error}
    }
  }
  /** change phone number */
  async function changeUserPhoneNumber(phoneNoInfo): Promise<any> {
    try {
      const responseData = await SettingsService.changePhoneNumber(phoneNoInfo);
      setState({
        ...state,
        changePhoneNumberResponseData: responseData,
        changePhoneNumberError: null,
      });
      return {
        ...initialState,
        changePhoneNumberResponseData: responseData,
        changePhoneNumberError: null,
      };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          changePhoneNumberError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  /** paperless statement status change */
  async function changePaperlessPreference(inputData): Promise<any> {
    try {
      const responseData = await SettingsService.paperlessPreference(inputData);
      setState({ ...state, paperlessPrefResponseData: responseData });
      return { ...initialState, changeUseridResponseData: responseData };
    } catch (error) {
      setState({ ...initialState, paperlessPrefError: error });
      throw error;
      //return {...initialState, changeUseridError: error}
    }
  }
  /** paperless statement status change */
  async function getUserSecurityQus(userId): Promise<any> {
    try {
      const responseData = await SettingsService.getUserSecurityQus(userId);
      setState({ ...state, UserSecurityQusResponseData: responseData, error: null });
      return { ...initialState, UserSecurityQusResponseData: responseData, error: null };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          error: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  /** get user phone numbers */
  async function getUserPhoneNo() {
    try {
      const responseData = await SettingsService.getUserPhoneNo();
      setState({ ...state, userPhoneNo: responseData });
      return { ...initialState, userPhoneNo: responseData };
    } catch (error) {
      setState({ ...initialState, userPhoneNoError: error });
      throw error;
    }
  }
  // update the user security questions
  async function updateSecurityQuestions(inputReq): Promise<any> {
    try {
      const responseData = await SettingsService.updateSecurityQuestions(inputReq);
      setState({ ...state, updatesecurityQusRes: responseData, error: null });
      return { ...initialState, updatesecurityQusRes: responseData, error: null };
    } catch(error) {
      if (error?.errors) {
        setState({
          ...initialState,
          error: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  // get user notificatoin information
  async function getUserNotificationInfo(): Promise<any> {
    try {
      const responseData = await SettingsService.getUserNotificationInfo();
      setState({ ...state, userNotificationsRes: responseData, error: null });
      return { ...initialState, userNotificationsRes: responseData, error: null };
    } catch(error) {
      if (error?.errors) {
        setState({
          ...initialState,
          error: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }

  //update user notification information
  async function submitNotificationPref(inputReq): Promise<any> {
    try {
      const responseData = await SettingsService.submitNotificationPref(inputReq);
      setState({ ...state, submitNotificationsRes: responseData, error: null });
      return { ...initialState, submitNotificationsRes: responseData, error: null };
    } catch(error) {
      if (error?.errors) {
        setState({
          ...initialState,
          error: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }

  const context = {
    ...state,
    submitMailAddress,
    submitChangeEmail,
    submitChangePassword,
    submitChangeUserid,
    changePaperlessPreference,
    changeUserPhoneNumber,
    getUserSecurityQus,
    getUserEmail,
    getUserPhoneNo,
    getMailingPolicies,
    updateSecurityQuestions,
    getUserNotificationInfo,
    submitNotificationPref
  };
  return (
    <SettingsContext.Provider value={context}>
      {props.children}
    </SettingsContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a settingsController?");
}
