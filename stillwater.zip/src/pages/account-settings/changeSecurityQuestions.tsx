import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { useSelector } from "react-redux";
import { ValidatorForm } from "react-material-ui-form-validator";
import { Grid } from "@material-ui/core";
import { Appbodycontainer, Blueheading, ErrorMessage } from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import { SettingsContext } from "./settingsController";
import { SignupService } from "../signup/_services/signupServices";
import SuccessBlockComponent from "./_components/successBlock";
import ActionButtonsBlock from "./_components/actionButtonsBlock";
import SecurityQuestionsComponent from "../../shared-components/securityQuestions/securityQuestionsComponent";

interface initialState {
  successMessage: string | null,
  userQuestions: any,
  securityQuestions: any,
  formSubmit: boolean,
  questionsList: any,
  userAttempts: any,
}
const initialState: initialState = {
  successMessage: null,
  userQuestions: [],
  securityQuestions: [],
  formSubmit: false,
  questionsList: [],
  userAttempts: [],
};

export default function ChangeSecurityQuestionsComponent(): ReactElement {
  const [state, setState] = useState(initialState);
  const [securityQuestions, setSecurityQuestions] = useState(
    initialState.securityQuestions
  );
  const history = useHistory();
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const { getUserSecurityQus, updateSecurityQuestions, error } = useContext(SettingsContext);
  const profile = useSelector(
    (storeState: any) => storeState.accountInfoReducer.profile
  );

  let emptyState = false;
  if (profile.length === 0) {
    emptyState = true;
  }
  // get user attempted questions
  const getUserQuestions = (userID) => {
    // get the user security question list
    getUserSecurityQus(userID)
      .then((response) => {
        const userQuestionsInfo = response?.UserSecurityQusResponseData?.data?.questions;
        const userAttempts: any = [];
        userQuestionsInfo.map((data, i) => {
          const info: any = {};
          info.questionID = data.questionID;
          info.question = data.questionText;
          info.index = i;
          info.answer = data.answer;
          userAttempts.push(info);
        });
        setState({
          ...state,
          userAttempts: userAttempts,
        });
      })
      .catch((error) => {
        console.log("Error: changeSecurityQuestions.tsx - getUserQuestions()", JSON.stringify(error));
      });
  }

  useEffect(() => {
    getUserQuestions(profile.userID)
    // get the security question list
    SignupService.getSecurityQuestions()
      .then((response) => {
        let questoinsList = response?.data?.questions;
        questoinsList = questoinsList.map((data) => {
          data.showPasswordField = false;
          return data;
        });
        setSecurityQuestions(questoinsList);
      })
      .catch((error) => {
        console.log("Error: changeSecurityQuestions.tsx - useEffect()", error);
      });
  }, [emptyState]);

  /** show/hide password field update */
  const ShowPassword = (questionIndex) => {
    const questionsList: any = securityQuestions;
    questionsList[questionIndex].showPasswordField = !questionsList[
      questionIndex
    ].showPasswordField;
    setState({
      ...state,
      questionsList: questionsList,
    });
  };
  // updating the question to state
  const handleQuestionChange = (value, questionIndex) => {
    const obj = {
      question: value.text,
      index: questionIndex,
      questionID: value.id,
      answer: "",
    };
    const userAttempts: any = state.userAttempts;
    const filter = userAttempts.filter((data: any, i) => {
      if (data.index === questionIndex) {
        return data;
      }
    });
    if (filter.length === 0) {
      userAttempts.push(obj);
    } else {

      const position = userAttempts.findIndex((x: any) => x.index === questionIndex);
      userAttempts[position].question = obj.question;
      userAttempts[position].index = obj.index;
    }
    setState({
      ...state,
      userAttempts: userAttempts,
    });
  };
  // updating the answer to state
  const handleAnswer = (value, answerIndex) => {
    const obj = {
      question: "",
      index: answerIndex,
      answer: value,
    };
    const userAttempts: any = state.userAttempts;
    const filter = userAttempts.filter((data: any, i) => {
      if (data.index === answerIndex) {
        return data;
      }
    });
    if (filter.length === 0) {
      userAttempts.push(obj);
    } else {
      const position = userAttempts.findIndex(
        (x: any) => x.index === answerIndex
      );
      userAttempts[position].answer = obj.answer;
      userAttempts[position].index = obj.index;
    }
    console.log("this is test", userAttempts)
    setState({
      ...state,
      userAttempts: userAttempts,
    });
  };
  // form submit
  const formSubmit = (e) => {
    const questionIDs: any = [];
    const answers: any = [];
    console.log("state.userAttempts", state.userAttempts)
    for (let i = 0; i < state.userAttempts?.length; i++) {
      questionIDs.push(state.userAttempts[i].questionID);
      answers.push(state.userAttempts[i].answer);
    }
    const inputReq = {
                        logonId: profile?.userID,
                        questionIDs: questionIDs,
                        answers: answers
                      }
    updateSecurityQuestions(inputReq)
      .then((response) => {
        setState({
          ...state,
          formSubmit: true,
          successMessage: "You have successfully changed your security questions.",
        });
      })
      .catch((error) => {
        console.log("Error: changeSecurityQuestions.tsx - formSubmit()", JSON.stringify(error));
      });    
  };

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle?.changeSecurityQuestions?.subHeading}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={8} lg={5}>
                <Blueheading theme={theme}>
                  <div className="heading">
                    <h3>
                      <span className="user-icon"></span>
                      {bundle?.changeSecurityQuestions?.subHeading}
                    </h3>
                  </div>
                  <div className="content">
                    {/* success block */}
                    {state.formSubmit === true && (
                      <div>
                        <SuccessBlockComponent message={state.successMessage} />
                      </div>
                    )}

                    {state.formSubmit === false && (
                      <ValidatorForm
                        className="ssp-mb6"
                        onSubmit={(e) => formSubmit(e)}
                        autoComplete="off"
                      >
                        {/* security questions component */}
                        <SecurityQuestionsComponent
                          theme={theme}
                          bundle={bundle}
                          questionsList={securityQuestions}
                          ShowPassword={ShowPassword}
                          handleQuestionChange={handleQuestionChange}
                          handleAnswer={handleAnswer}
                          userAttempts={state.userAttempts}
                          iconState="show"
                        />

                        {/* alert message */}
                        <span className="ssp-success">
                          <b>{state.successMessage}</b>
                        </span>

                        {/* error message block */}
                        {error && (
                          <ErrorMessage
                            className="orange ssp-mt2 ssp-inline-block"
                            theme={theme}
                          >
                            <b>{error}</b>
                          </ErrorMessage>
                        )}

                        <ActionButtonsBlock
                          blockClasses="ssp-mt6 ssp-align-right"
                          cancelActionName={bundle["button.cancel"]}
                          formActionName={bundle["button.submit"]}
                          navigation={navigation}
                          navigationPathName="settings"
                        />
                      </ValidatorForm>
                    )}
                  </div>
                </Blueheading>
              </Grid>
            </Grid>
          </div>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
