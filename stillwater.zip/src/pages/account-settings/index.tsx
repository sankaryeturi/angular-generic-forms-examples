import React, { ReactElement, useContext } from "react";
import { useHistory } from "react-router-dom";
import { Grid } from "@material-ui/core";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  Blueheadinggrid,
  Bluebutton,
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";

export default function Accountsettings(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();
  const dummyContent = bundle["text.dummycontentsmall"];

  const navigation = (path) => {
    history.push("/" + path);
  };
  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt6">
            <Grid container>
              <Grid item xs={12} md={4}>
                <Blueheadinggrid theme={theme}>
                  <div className="heading">
                    <h3>
                      <span className="user-icon"></span>
                      {bundle["heading.accsetpersonal"]}
                    </h3>
                  </div>
                  <div className="content">
                    <p>{dummyContent}</p>
                    <div className="buttons-block">
                      <Bluebutton
                        className="w-100 ssp-mb3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("changemailaddressinfo")}
                      >
                        <span>{bundle["button.changemailingadd"]}</span>
                      </Bluebutton>
                      <Bluebutton
                        className="w-100 ssp-mb3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("changeEmail")}
                      >
                        <span>{bundle["button.changemailadd"]}</span>
                      </Bluebutton>
                      <Bluebutton
                        className="w-100 ssp-mb3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("changePhoneNumber")}
                      >
                        <span>{bundle["button.changephoneno"]}</span>
                      </Bluebutton>
                    </div>
                  </div>
                </Blueheadinggrid>
              </Grid>
              <Grid item xs={12} md={4}>
                <Blueheadinggrid theme={theme}>
                  <div className="heading">
                    <h3>
                      <span className="lock-icon"></span>{" "}
                      {bundle["heading.security"]}
                    </h3>
                  </div>
                  <div className="content">
                    <p>{dummyContent}</p>
                    <div className="buttons-block">
                      <Bluebutton
                        className="w-100 ssp-mb3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("changePassword")}
                      >
                        <span>{bundle["button.changepass"]}</span>
                      </Bluebutton>
                      <Bluebutton
                        className="w-100 ssp-mb3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("changeUserid")}
                      >
                        <span>{bundle["button.changeuserid"]}</span>
                      </Bluebutton>
                      <Bluebutton
                        className="w-100 ssp-mb3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("changeSecurityQuestions")}
                      >
                        <span>{bundle["button.changeSecurityQuestions"]}</span>
                      </Bluebutton>
                    </div>
                  </div>
                </Blueheadinggrid>
              </Grid>
              <Grid item xs={12} md={4}>
                <Blueheadinggrid theme={theme}>
                  <div className="heading">
                    <h3>
                      <span className="signal-icon"></span>{" "}
                      {bundle["heading.communication"]}
                    </h3>
                  </div>
                  <div className="content">
                    <p>{dummyContent}</p>
                    <div className="buttons-block">
                      <Bluebutton
                        className="w-100 ssp-mb3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("notifications")}
                      >
                        <span>{bundle["button.notificationpref"]}</span>
                      </Bluebutton>
                      <Bluebutton
                        className="w-100 ssp-mb3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("paperlessstatement")}
                      >
                        <span>{bundle["button.paperlessset"]}</span>
                      </Bluebutton>
                    </div>
                  </div>
                </Blueheadinggrid>
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={12} md={4}>
                {/* <p className="ssp-mr3 ssp-mt0">{bundle['text.accsetcontent1']}</p> */}
              </Grid>
            </Grid>
          </div>
          <div className="white-block"></div>
        </div>
      </Appbodycontainer>
    </div>
  );
}
