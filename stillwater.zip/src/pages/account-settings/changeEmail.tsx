import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { Grid } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  Blueheading,
  SspformGroup,
  ErrorMessage,
} from "../../themes/styles";
import { ValidationService } from "../../_services/validation";
import { SettingsContext } from "./settingsController";
import { IChangeEmailAddress } from "./_interfaces/interface";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { CommonService } from "../../_services/commonServices";
import SuccessBlockComponent from "./_components/successBlock";
import ActionButtonsBlock from "./_components/actionButtonsBlock";
import { updateUserProfile } from "../../_actions";

// initial state
const initialState: IChangeEmailAddress = {
  oldEmail: "",
  email: "",
  confirmEmail: "",
  successMessage: "",
  formSubmit: false,
};

export default function ChangeEmail(): ReactElement {
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();
  const { getUserEmail, submitChangeEmail, changeEmailError } = useContext(
    SettingsContext
  );
  const profile = useSelector(
    (storeState: any) => storeState.accountInfoReducer.profile
  );
  const dispatch = useDispatch();

  let emptyState = false;
  if (profile?.length === 0) {
    emptyState = true;
  }
  useEffect(() => {
    // console.log(profile);

    if (!profile?.email) {
      getUserEmail()
        .then((response) => {
          // dispatch(updateUserEmail(response.userEmail?.data?.emailAddress));
          const userProfileInfo = profile;
          userProfileInfo.email = response.userEmail?.data?.emailAddress;
          dispatch(updateUserProfile(userProfileInfo));
          setState({
            ...state,
            oldEmail: response.userEmail?.data?.emailAddress,
          });
        })
        .catch((error) => {
          CommonService.consolError(error, "changeEmail.tsx", "getUserEmail()");
        });;
      console.log("change email", profile?.email);
    } else {
      setState({
        ...state,
        oldEmail: profile?.email,
      });
    }
  }, [emptyState]);

  useEffect(() => {
    ValidationService.emailMatch(state);
  }, [state.email]);

  // changing input field value
  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };

  // submit new mailing address form
  const emailFormSubmit = (e: any): void => {
    const formInfo = {
      oldEmailAddr: state.oldEmail,
      newEmailAddr: state.email,
    };
    submitChangeEmail(formInfo)
      .then((response) => {
        setState({
          ...state,
          formSubmit: true,
          successMessage: bundle["changemailadd.successResponse"],
        });
      })
      .catch((error) => {
        CommonService.consolError(error, "changeEmail.tsx", "emailFormSubmit()");
      });
  };

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle["heading.changeEmailAddress"]}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={8} lg={5}>
                <Blueheading theme={theme}>
                  <div className="heading">
                    <h3>
                      <span className="user-icon"></span>
                      {bundle["heading.changeEmailAddress"]}
                    </h3>
                  </div>
                  <div className="content">
                    {/* success block */}
                    {state.formSubmit === true && (
                      <div>
                        <SuccessBlockComponent message={state.successMessage} />
                      </div>
                    )}

                    {state.formSubmit === false && (
                      <>
                        <div>
                          <strong>{bundle?.changeEmailAddress?.label1}</strong>
                          <br />
                          <span>{state.oldEmail}</span>
                        </div>

                        <ValidatorForm
                          onSubmit={(e) => emailFormSubmit(e)}
                          autoComplete="off"
                        >
                          <Grid container className="ssp-mt2">
                            <Grid item xs={12}>
                              <SspformGroup
                                theme={theme}
                                className="input50 ssp-mb2"
                              >
                                <TextValidator
                                  label={bundle?.changeEmailAddress?.newEmail}
                                  fullWidth
                                  onChange={(e) => handleChange(e, "email")}
                                  name="email"
                                  type="text"
                                  value={state.email}
                                  validators={["required", "isEmail"]}
                                  errorMessages={[
                                    bundle?.changeEmailAddress?.newEmailError,
                                    bundle?.validation?.emailPattern,
                                  ]}
                                  InputLabelProps={{
                                    shrink: true,
                                  }}
                                />
                              </SspformGroup>
                            </Grid>
                          </Grid>
                          <Grid container className="ssp-mt2">
                            <Grid item xs={12}>
                              <SspformGroup
                                theme={theme}
                                className="input50 ssp-mb2"
                              >
                                <TextValidator
                                  label={
                                    bundle?.changeEmailAddress?.confirmNewEmail
                                  }
                                  fullWidth
                                  onChange={(e) =>
                                    handleChange(e, "confirmEmail")
                                  }
                                  name="confirmEmail"
                                  type="text"
                                  value={state.confirmEmail}
                                  validators={[
                                    "required",
                                    "isEmail",
                                    "emailMatch",
                                  ]}
                                  errorMessages={[
                                    bundle?.changeEmailAddress
                                      ?.confirmEmailError,
                                    bundle?.changeEmailAddress
                                      ?.confirmEmailInvaildError,
                                    bundle?.changeEmailAddress?.emailMatchError,
                                  ]}
                                  InputLabelProps={{
                                    shrink: true,
                                  }}
                                />
                              </SspformGroup>
                            </Grid>
                          </Grid>
                          {/* error message block */}
                          {changeEmailError && (
                            <ErrorMessage
                              className="orange ssp-mt2 ssp-inline-block"
                              theme={theme}
                            >
                              <b>{changeEmailError}</b>
                            </ErrorMessage>
                          )}
                          <ActionButtonsBlock
                            blockClasses="ssp-mt4 ssp-align-right"
                            cancelActionName={bundle["button.cancel"]}
                            formActionName={bundle["button.submit"]}
                            navigation={navigation}
                            navigationPathName="settings"
                          />
                        </ValidatorForm>
                      </>
                    )}
                  </div>
                </Blueheading>
              </Grid>
            </Grid>
          </div>
        </div>

        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
