import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { Grid } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  SspformGroup,
  Blueheading,
  ErrorMessage,
} from "../../themes/styles";
import { updateUserProfile } from "../../_actions";
import { IChangePhonenumber } from "./_interfaces/interface";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { SettingsContext } from "./settingsController";
import SuccessBlockComponent from "./_components/successBlock";
import ActionButtonsBlock from "./_components/actionButtonsBlock";
import { CommonService } from "../../_services/commonServices";

const initialState: IChangePhonenumber = {
  primaryNumber: "",
  secondaryNumber: "",
  failMessage: "",
  successMessage: "",
  formSubmit: false,
};

export default function ChangePhoneNumber(): ReactElement {
  const [state, setState] = useState(initialState);
  const dispatch = useDispatch();
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();
  const profile = useSelector(
    (storeState: any) => storeState.accountInfoReducer.profile
  );
  const {
    changePhoneNumberError,
    changeUserPhoneNumber,
    getUserPhoneNo,
  } = useContext(SettingsContext);

  let emptyState = false;
  if (profile?.length === 0) {
    emptyState = true;
  }

  useEffect(() => {
    if (!profile.phoneNumbers) {
      const userProfileInfo = profile;
      getUserPhoneNo()
        .then((response) => {
          const phoneNos = response?.userPhoneNo?.data;
          userProfileInfo.phoneNumbers = phoneNos;
          dispatch(updateUserProfile(userProfileInfo));
          setState({
            ...state,
            primaryNumber: response?.userPhoneNo?.data?.primaryNumber,
            secondaryNumber: response?.userPhoneNo?.data?.secondaryNumber,
          });
        })
        .catch((error) => {
          CommonService.consolError(
            error,
            "changePhoneNubmer.tsx",
            "getUserPhoneNo"
          );
        });
    } else {
      setState({
        ...state,
        primaryNumber: profile?.phoneNumbers?.primaryNumber,
        secondaryNumber: profile?.phoneNumbers?.secondaryNumber,
      });
    }
  }, [emptyState]);

  // submit new mailing address form
  const submit = (e: any): void => {
    const inputData = {
      primaryNumber: state.primaryNumber,
      secondaryNumber: state.secondaryNumber,
    };
    changeUserPhoneNumber(inputData)
      .then((response) => {
        setState({
          ...state,
          formSubmit: true,
          successMessage:
            response?.changePhoneNumberResponseData?.data?.success,
          failMessage: "",
        });
      })
      .catch((error) => {
        CommonService.consolError(
          error,
          "changePhoneNumber.tsx",
          "changeUserPhoneNumber"
        );
      });
  };

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  // changing input field value
  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle["heading.changephonenumber"]}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={8} lg={5}>
                <Blueheading theme={theme}>
                  <div className="heading">
                    <h3>
                      <span className="user-icon"></span>
                      {bundle["heading.changephonenumber"]}
                    </h3>
                  </div>
                  <div className="content">
                    {/* success block */}
                    {state.formSubmit === true && (
                      <div>
                        <SuccessBlockComponent message={state.successMessage} />
                      </div>
                    )}

                    {state.formSubmit === false && (
                      <>
                        <ValidatorForm
                          onSubmit={(e) => submit(e)}
                          autoComplete="off"
                        >
                          <SspformGroup theme={theme} className="input50">
                            <TextValidator
                              type="text"
                              label={bundle?.changePhoneNumber?.input1}
                              fullWidth
                              onChange={(e) => handleChange(e, "primaryNumber")}
                              name="primaryNumber"
                              value={state.primaryNumber}
                              validators={["required"]}
                              errorMessages={[
                                bundle?.changePhoneNumber?.input1Error,
                              ]}
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </SspformGroup>

                          <SspformGroup theme={theme} className="input50">
                            <TextValidator
                              type="text"
                              label={bundle?.changePhoneNumber?.input2}
                              fullWidth
                              onChange={(e) =>
                                handleChange(e, "secondaryNumber")
                              }
                              name="secondaryNumber"
                              value={state.secondaryNumber}
                              validators={["required"]}
                              errorMessages={[
                                bundle["changePhoneNumber.inputError"],
                              ]}
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </SspformGroup>
                          {/* alert message */}
                          {changePhoneNumberError && (
                            <ErrorMessage
                              className="orange ssp-mt2 ssp-inline-block"
                              theme={theme}
                            >
                              <b>{changePhoneNumberError}</b>
                            </ErrorMessage>
                          )}
                          <ActionButtonsBlock
                            blockClasses="ssp-mt4 ssp-align-right"
                            cancelActionName={bundle["button.cancel"]}
                            formActionName={bundle["button.save"]}
                            navigation={navigation}
                            navigationPathName="settings"
                          />
                        </ValidatorForm>
                      </>
                    )}
                  </div>
                </Blueheading>
              </Grid>
            </Grid>
          </div>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
