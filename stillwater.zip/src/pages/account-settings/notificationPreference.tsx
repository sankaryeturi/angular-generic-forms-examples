import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { 
  Grid, 
  RadioGroup, 
  FormControlLabel, 
  Radio, 
  Select, 
  Input, 
  MenuItem, 
  Checkbox, 
  ListItemText,
  withStyles } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  Blueheadinggrid,
  Darkblueheadingh5,
  SspformGroup,
  Darkbluebutton,
  Bluebutton,
  ErrorMessage
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { SettingsContext } from "./settingsController";
import { updateUserProfile } from "../../_actions";
import { DarkGrayLine } from "./styles";
import SuccessBlockComponent from "./_components/successBlock";

interface initialState {
  phoneNos: any;
  paymentPhoneSelected: any;
  marketPhoneSelected: any;
  userNotificationInfo: any;
  formSubmit: boolean;
  successMessage: string | null;
} 
const initialState: initialState = {
  phoneNos: [],
  paymentPhoneSelected: [],
  marketPhoneSelected: [],
  userNotificationInfo: [],
  formSubmit: false,
  successMessage: null
}

export default function NotificationPreference(): ReactElement {
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();
  const dispatch = useDispatch();
  const { 
    getUserEmail, 
    getUserPhoneNo, 
    getUserNotificationInfo, 
    submitNotificationPref,
    error } = useContext(SettingsContext);
  const profile = useSelector(
    (storeState: any) => storeState.accountInfoReducer.profile
  );
  const emailLabel = bundle["label.email"];

  let emptyState = false;
  if (profile?.length === 0) {
    emptyState = true;
  }

  const fetchData = () => {
    Promise.all([
      getUserNotificationInfo(),
      getUserEmail(),
      getUserPhoneNo()
    ])
    .then((response: any) => {
      const userProfileInfo = profile;
      userProfileInfo.email = response[1].userEmail?.data?.emailAddress;
      userProfileInfo.phoneNumbers = {
        primaryNumber: response[2]?.userPhoneNo?.data?.primaryNumber,
        secondaryNumber: response[2]?.userPhoneNo?.data?.secondaryNumber,
      };
      // dispatch(updateUserProfile(userProfileInfo));
      let userNotification = response[0]?.userNotificationsRes?.data;
      let userPhoneno = response[2]?.userPhoneNo?.data;
      let paymentPnoSelected:any = [];
      let marketPnoSelected:any = [];

      if(userNotification[2]?.textPrimaryNumber === "Y") {
        paymentPnoSelected.push(userPhoneno.primaryNumber);
      }
      if(userNotification[2]?.textSecondaryNumber === "Y") {
        paymentPnoSelected.push(userPhoneno.secondaryNumber);
      }
      if(userNotification[1]?.textPrimaryNumber === "Y") {
        marketPnoSelected.push(userPhoneno.primaryNumber);
      }
      if(userNotification[1]?.textSecondaryNumber === "Y") {
        marketPnoSelected.push(userPhoneno.secondaryNumber);
      }
      setState({
        ...state,
        phoneNos: userProfileInfo.phoneNumbers,
        paymentPhoneSelected: paymentPnoSelected,
        marketPhoneSelected: marketPnoSelected,
        userNotificationInfo: userNotification
      })
      // console.log("page load data", response)
    })
    .catch((error) => {
      console.log("Error: notificationPreference.tsx - fetchData()", error);
    });    
  }

  useEffect(() => {
    fetchData();    
  }, [emptyState]);
  // 
  const radioBntHandleChange = (e, field) => {
    const inputVal = e.target.value;
    var notificationInfo = state.userNotificationInfo;
    if(field === "paymentEmailCheck") {
      var notifyRes = notificationInfo.findIndex(x => x.type === "Payment");
      notificationInfo[notifyRes].email = inputVal;
      setState({
        ...state,
        userNotificationInfo: notificationInfo
      })
    } else if(field === "marketingEmailCheck") {
      var notifyRes = notificationInfo.findIndex(x => x.type === "Claim");
      notificationInfo[notifyRes].email = inputVal;
      setState({
        ...state,
        userNotificationInfo: notificationInfo
      })
    }
  }
  // select phone nos
  const handlePhoneNo = (e, type) => {
    const notificationInfo = state.userNotificationInfo;
    if(type === "payment") {      
      if(e.target.value.length === 1) {        
        if(state.phoneNos.primary === e.target.value[0]) {
          notificationInfo[2].textPrimaryNumber = "Y";  
          notificationInfo[2].textSecondaryNumber = "N";        
        } else {
          notificationInfo[2].textPrimaryNumber = "N";  
          notificationInfo[2].textSecondaryNumber = "Y";
        }
      } else if(e.target.value.length === 0) {
        notificationInfo[2].textPrimaryNumber = "N";  
        notificationInfo[2].textSecondaryNumber = "N";
      } else if(e.target.value.length === 2) {
        notificationInfo[2].textPrimaryNumber = "Y";  
        notificationInfo[2].textSecondaryNumber = "Y";
      }
      setState({
        ...state,
        paymentPhoneSelected: e.target.value,
        userNotificationInfo: notificationInfo
      })
    } else if(type === "marketing") {
      if(e.target.value.length === 1) {        
        if(state.phoneNos.primary === e.target.value[0]) {
          notificationInfo[1].textPrimaryNumber = "Y";  
          notificationInfo[1].textSecondaryNumber = "N";        
        } else {
          notificationInfo[1].textPrimaryNumber = "N";  
          notificationInfo[1].textSecondaryNumber = "Y";
        }
      } else if(e.target.value.length === 0) {
        notificationInfo[1].textPrimaryNumber = "N";  
        notificationInfo[1].textSecondaryNumber = "N";
      } else if(e.target.value.length === 2) {
        notificationInfo[1].textPrimaryNumber = "Y";  
        notificationInfo[1].textSecondaryNumber = "Y";
      }
      setState({
        ...state,
        marketPhoneSelected: e.target.value,
        userNotificationInfo: notificationInfo
      })
    }
  }
  // submit new mailing address form
  const submit = (e: any): void => {
    const inputReq = {
      notificationPreferenceList: state.userNotificationInfo
    }
    submitNotificationPref(inputReq)
      .then((response) => {
        console.log("submitNotificationPref", response)
        setState({
          ...state,
          formSubmit: true,
          successMessage: bundle["notificationpref.formSuccessMessage"],
        })
      })
      .catch((error) => {
        console.log(`%c Error: notificationPreference.tsx - submit ${JSON.stringify(error)}`, "color: #FF0000");
      })
  };
  // page navigation
  const navigation = (path) => {
    history.push("/" + path);
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.accountsettings"]}
            subTitle={bundle["button.notificationpref"]}
            icon="setting.svg"
            iconName="ssp-settingicon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12}>
                <Blueheadinggrid theme={theme}>
                  <div className="heading">
                    <h3>{bundle["button.notificationpref"]}</h3>
                  </div>
                  <div className="content">
                    {/* success block */}
                    
                    {state.formSubmit === true && (
                      <div className="MuiGrid-grid-md-4">
                        <SuccessBlockComponent message={state.successMessage} />
                      </div>
                    )}

                    {state.formSubmit === false && (
                      <ValidatorForm
                        onSubmit={(e) => submit(e)}
                        autoComplete="off"
                      >
                        <Grid container>
                          <Grid item xs={12} md={6}>
                            <p className="ssp-mt0">
                              {bundle["text.dummycontentsmall"]}
                            </p>
                          </Grid>
                        </Grid>
                        <Grid container className="ssp-mt2">
                          {/* payment block  */}
                          <Grid item xs={12} md={6}>
                            <Darkblueheadingh5 theme={theme}>
                              {bundle["label.payment"]}
                            </Darkblueheadingh5>
                            <p className="ssp-mt0">
                              <b>{bundle["notificationpref.content2"]}</b>
                            </p>
                            <div className="ssp-px3">
                              <Grid container spacing={2}>
                                <Grid item xs={12} md={6}>
                                  {/* Email field */}
                                  <SspformGroup theme={theme} className="ssp-mt0">
                                    <label>{emailLabel}</label>
                                    <RadioGroup
                                      row
                                      name="paymentEmailRadioGroup"
                                      defaultValue="top"
                                      className="ssp-my2"
                                    >
                                      <FormControlLabel
                                        value="Y"
                                        name="paymentEmailYes"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.yes"]}
                                        checked={state?.userNotificationInfo[2]?.email === "Y"}
                                        onChange={(e) =>
                                          radioBntHandleChange(e, "paymentEmailCheck")
                                        }
                                      />
                                      <FormControlLabel
                                        value="N"
                                        name="paymentEmailNo"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.no"]}
                                        checked={state?.userNotificationInfo[2]?.email === "N"}
                                        onChange={(e) =>
                                          radioBntHandleChange(e, "paymentEmailCheck")
                                        }
                                      />
                                    </RadioGroup>

                                    <TextValidator
                                      className="ssp-inputwhite"
                                      fullWidth
                                      name="paymentEmail"
                                      value={profile?.email}
                                      InputLabelProps={{
                                        shrink: true,
                                      }}
                                      InputProps={{
                                        readOnly: true,
                                      }}
                                    />
                                  </SspformGroup>
                                </Grid>
                                <Grid item xs={12} md={5}>
                                  {/* phone number field */}
                                  <SspformGroup theme={theme} className="ssp-mt0">
                                    <label>{bundle["label.text"]}</label>
                                    <RadioGroup
                                      row
                                      aria-label="position"
                                      name="position"
                                      defaultValue="top"
                                      className="ssp-my2"
                                    >
                                      <FormControlLabel
                                        value="top"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.yes"]}
                                      />
                                      <FormControlLabel
                                        value="end"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.no"]}
                                      />
                                    </RadioGroup>
                                    
                                    <Select
                                      id="payment-phone-numbers-check"
                                      multiple
                                      fullWidth
                                      value={state.paymentPhoneSelected}
                                      onChange={(e) => handlePhoneNo(e, "payment")}
                                      input={<Input />}
                                      renderValue={(selected:any) => selected.join(', ')}
                                      style={{backgroundColor: "#fff", height: "55px", borderBottom: "2px solid #003399"}}
                                    >
                                      <MenuItem value={state?.phoneNos?.primaryNumber}>
                                        <Checkbox checked={state.paymentPhoneSelected.indexOf(state?.phoneNos?.primaryNumber) > -1} />
                                        <ListItemText primary={state.phoneNos.primaryNumber} />
                                      </MenuItem>
                                      {state?.phoneNos?.secondaryNumber !== "" && (
                                        <MenuItem value={state?.phoneNos?.secondaryNumber}>
                                          <Checkbox checked={state.paymentPhoneSelected.indexOf(state?.phoneNos?.secondaryNumber) > -1} />
                                          <ListItemText primary={state?.phoneNos?.secondaryNumber} />
                                        </MenuItem>
                                        )}
                                    </Select>
                                  </SspformGroup>
                                </Grid>
                              </Grid>
                            </div>
                          </Grid>

                          

                          {/* policy block */}
                          <Grid item xs={12} md={6}>
                            <Darkblueheadingh5 theme={theme}>
                              {bundle["text.policy"]}
                            </Darkblueheadingh5>
                            <p className="ssp-mt0">
                              <b>{bundle["notificationpref.content3"]}</b>
                            </p>
                            <div className="ssp-px3">
                              <Grid container spacing={2}>
                                <Grid item xs={12} md={6}>
                                  <SspformGroup theme={theme} className="ssp-mt0">
                                    <label className="">{emailLabel}</label>
                                    <RadioGroup
                                      row
                                      aria-label="position"
                                      name="position"
                                      defaultValue="top"
                                      className="ssp-my2"
                                    >
                                      <FormControlLabel
                                        value="top"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.yes"]}
                                      />
                                      <FormControlLabel
                                        value="end"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.no"]}
                                      />
                                    </RadioGroup>

                                    <TextValidator
                                      className="ssp-inputwhite"
                                      fullWidth
                                      name="userId"
                                      value={profile?.email}
                                      InputLabelProps={{
                                        shrink: true,
                                      }}
                                      InputProps={{
                                        readOnly: true,
                                      }}
                                    />
                                  </SspformGroup>
                                </Grid>
                              </Grid>
                            </div>
                          </Grid>
                        </Grid>
                        <DarkGrayLine />
                        {/* Marketing block */}
                        <Grid container className="ssp-mt4">
                          <Grid item xs={12} md={6}>
                            <Darkblueheadingh5 theme={theme}>
                              {bundle["label.marketing"]}
                            </Darkblueheadingh5>
                            <p className="ssp-mt0">
                              <b>{bundle["notificationpref.content5"]}</b>
                            </p>
                            <div className="ssp-px3">
                              <Grid container spacing={2}>
                                <Grid item xs={12} md={6}>
                                  <SspformGroup theme={theme} className="ssp-mt0">
                                    <label>{emailLabel}</label>
                                    <RadioGroup
                                      row
                                      name="marketingEmailRaioGroup"
                                      defaultValue="top"
                                      className="ssp-my2"
                                    >
                                      <FormControlLabel
                                        value="Y"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.yes"]}
                                        checked={state.userNotificationInfo[1]?.email === "Y"}
                                        onChange={(e) =>
                                          radioBntHandleChange(e, "marketingEmailCheck")
                                        }
                                      />

                                      <FormControlLabel
                                        value="N"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.no"]}
                                        checked={state.userNotificationInfo[1]?.email === "N"}
                                        onChange={(e) =>
                                          radioBntHandleChange(e, "marketingEmailCheck")
                                        }
                                      />
                                    </RadioGroup>
                                    <TextValidator
                                      className="ssp-inputwhite"
                                      fullWidth
                                      name="userId"
                                      value={profile?.email}
                                      InputLabelProps={{
                                        shrink: true,
                                      }}
                                      InputProps={{
                                        readOnly: true,
                                      }}
                                    />
                                  </SspformGroup>
                                </Grid>
                                <Grid item xs={12} md={5}>
                                  {/* phone number field */}
                                  <SspformGroup theme={theme} className="ssp-mt0">
                                    <label>{bundle["label.text"]}</label>
                                    <RadioGroup
                                      row
                                      aria-label="position"
                                      name="position"
                                      defaultValue="top"
                                      className="ssp-my2"
                                    >
                                      <FormControlLabel
                                        value="top"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.yes"]}
                                      />
                                      <FormControlLabel
                                        value="end"
                                        control={<Radio color="primary" />}
                                        label={bundle["label.no"]}
                                      />
                                    </RadioGroup>
                                    
                                    <Select
                                      id="payment-phone-numbers-check"
                                      multiple
                                      fullWidth
                                      value={state.marketPhoneSelected}
                                      onChange={(e) => handlePhoneNo(e, "marketing")}
                                      input={<Input />}
                                      renderValue={(selected:any) => selected.join(', ')}
                                      style={{backgroundColor: "#fff", height: "55px", borderBottom: "2px solid #003399"}}
                                    >
                                      <MenuItem value={profile?.phoneNumbers?.primaryNumber}>
                                        <Checkbox checked={state.marketPhoneSelected.indexOf(profile?.phoneNumbers?.primaryNumber) > -1} />
                                        <ListItemText primary={state.phoneNos.primaryNumber} />
                                      </MenuItem>
                                      {profile?.phoneNumbers?.secondary !==
                                        "" && (
                                        <MenuItem value={profile?.phoneNumbers?.secondaryNumber}>
                                          <Checkbox checked={state.marketPhoneSelected.indexOf(profile?.phoneNumbers?.secondaryNumber) > -1} />
                                          <ListItemText primary={state.phoneNos.secondaryNumber} />
                                        </MenuItem>
                                        )}
                                    </Select>
                                  </SspformGroup>
                                </Grid>
                              </Grid>
                            </div>
                          </Grid>
                        </Grid>

                        {error &&(
                          <ErrorMessage
                            className="orange ssp-mt2 ssp-inline-block"
                            theme={theme}
                          >
                            <b>{error}</b>
                          </ErrorMessage>
                        )}

                        <div className="ssp-mt6 dflexcenter ssp-pb6">
                          <Bluebutton
                            className="ssp-mr3 min-w150"
                            type="button"
                            theme={theme}
                            onClick={() => navigation("settings")}
                          >
                            {bundle["button.cancel"]}
                          </Bluebutton>

                          <Darkbluebutton theme={theme} className="min-w150">
                            <span>{bundle["button.save"]}</span>
                          </Darkbluebutton>
                        </div>
                      </ValidatorForm>
                    )}
                  </div>
                </Blueheadinggrid>
              </Grid>
            </Grid>
          </div>
          <div className="white-block"></div>
        </div>
      </Appbodycontainer>
    </div>
  );
}
