import styled from "styled-components";
import Bannerimage from "../../assets/images/thumbnail_blue_bkgrd_self_service.png";
import dashboardCarBanner from "../../assets/images/dashboard-car-banner.png";
import shieldCheck from "../../assets/images/icons/dashboard-page-icons/shield-check.svg";
import homeIcon from "../../assets/images/icons/dashboard-page-icons/home.svg";
import carIcon from "../../assets/images/icons/dashboard-page-icons/car.svg";
import bookIcon from "../../assets/images/icons/dashboard-page-icons/book-open.svg";

export const Bannerarea = styled.div`
  background: ${(props) => props.theme.pacificBlue};
  background-image: url(${Bannerimage});
  padding: 30px;
  color: ${(props) => props.theme.white};
  min-height: 560px;
  height: 100%;
  text-align: center;
  margin-top: 1rem;
  h1 {
    text-transform: uppercase;
    font: 58px/60px Work Sans Extra Bold;
  }
  .gradient-bg {
    background-color: rgba(206, 242, 255, 0.64);
    min-height: 200px;
    width: 90%;
    margin: 0 auto;
    padding: 30px 7%;
    overflow: hidden;
  }
  .banner-slider {
    width: 100%;
    margin: 0 auto;
  }
  .quick-links-block {
    width: 712px;
    margin: 0 auto;
  }

  @media screen and (max-width: 767px) {
    padding: 20px;
    margin-top: 0;
    h1 {
      font: 34px/36px Work Sans Extra Bold;
    }
    .gradient-bg {
      width: 100%;
      padding: 20px;
      margin-top: 20px;
    }
    .quick-links-block {
      width: 100%;
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1299px) {
    h1 {
      font: 45px/47px Work Sans Extra Bold;
    }
    .gradient-bg {
      width: 95%;
    }

    .quick-links-block {
      width: 100%;
      max-width: 600px;
    }
  }
`;
export const Borderblocks = styled.div`
    border: 2px solid ${(props) => props.theme.darkBlue};
    min-height: 300px;
    height: 100%;
    padding: 20px;
    &.left-block {
        margin-right: 20px;
        h2 {
            color: ${(props) => props.theme.darkBlue};
            font-size: 32px;
            font: 28px/32px Work Sans Extra Bold;
        }
    }
    &.right-block {
        text-align: center;
        // background-image: url(${dashboardCarBanner});
        background-size: 100%;
        h2 {
            margin: 0;
            line-height: 42px;
            &.dark-blue {
                font-size: 44px;
                color: ${(props) => props.theme.darkBlue};
                font: 44px/52px Work Sans Extra Bold;
            }
            &.pacific-blue {
                font-size: 58px;
                color: ${(props) => props.theme.pacificBlue};
                font: 58px/53px Work Sans Extra Bold;
            }
        }
        p {
            color: ${(props) => props.theme.black};
            text-align: left;
            width: 51%;
            margin: 10px auto 30px auto;
        }
    }
    .align-center {
        text-align: center;
    }
    @media screen and (max-width: ${(props) => props.theme.mobileMax}) {        
        &.left-block, &.right-block {
            margin: 20px;
        }
    }
    @media screen and (min-width: ${(props) =>
      props.theme.mobileMin}) and (max-width: ${(props) =>
  props.theme.tabMax}) {
        &.left-block h2 {
            font: 20px/22px Work Sans Extra Bold;
        }
    }
`;

export const PacificBlueborder = styled.div`
  border: 3px solid #0099cc;
  padding: 20px;
  min-height: 190px;
  background-repeat: no-repeat;
  background-position: 20px -25px;

  > div {
    max-width: 90%;
    margin: 0 auto 0 8%;
    padding-top: 30px;
    h2 {
      font: 44px/52px Work Sans Extra Bold;
      margin: 0;
      color: ${(props) => props.theme.darkBlue};
    }
  }

  &.shield-check-icon {
    background-image: url(${shieldCheck});
  }
  &.home-icon {
    background-image: url(${homeIcon});
  }
  &.car-icon {
    background-image: url(${carIcon});
  }
  &.book-open {
    background-image: url(${bookIcon});
  }
  @media screen and (max-width: ${(props) => props.theme.mobileMax}) {
    background-position: center -27px;
    margin: 0 20px;
    > div {
      max-width: 100%;
      padding-top: 0;
      margin: 0;
    }
  }
`;
