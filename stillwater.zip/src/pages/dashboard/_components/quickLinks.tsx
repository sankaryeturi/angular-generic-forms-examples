import React, { ReactElement, useContext } from "react";
import { Grid } from "@material-ui/core";
import { ThemeContext } from "../../../themes";
import { Insurancegridtype, ThemeIcon } from "../../../themes/styles";
import { Link } from "react-router-dom";

export default function QuickLinksComponent(props): ReactElement {
  const { theme } = useContext(ThemeContext);
  return (
    <>
      <Grid item xs={4} md={2}>
        <Insurancegridtype className="shortlinks" theme={theme}>
          <div className="content dflexcenter">
            <ThemeIcon className={props.iconname}></ThemeIcon>
          </div>
          <div className="footer">
            <Link to={props.link}>{props.title}</Link>
          </div>
        </Insurancegridtype>
      </Grid>
    </>
  );
}
