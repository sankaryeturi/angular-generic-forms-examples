import React, { ReactElement, useContext } from "react";
import { ThemeContext } from "../../../themes";
import { DashboardAlerts, ThemeIcon } from "../../../themes/styles";
import { LocalizationContext } from "../../../locales";
import { Link } from "react-router-dom";
import { HighlightOff } from "@material-ui/icons";
import { CommonService } from "../../../_services/commonServices";

export default function AlertsComponent(props): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);

  const closePolicyAlert = (info, index) => {
    props.closePolicyAlert(info, index);
  };

  return (
    <DashboardAlerts theme={theme}>
      <div className="ssp-list">
        <ThemeIcon
          className={
            CommonService.policyIcon(props.alertInfo.policyType) + " active"
          }
        ></ThemeIcon>
        <span>
          <b>
            <span className="policy-type-name">
              {props.alertInfo.alertType}
            </span>
            {props.alertInfo.alertType === "claim" && (
              <span className="claim-number">
                {" "}
                #{props.alertInfo.claimNumber}
              </span>
            )}
            {props.alertInfo.alertType === "Payment" && <span> Due </span>}
          </b>{" "}
          -{" "}
          <span className="policy-type-name">{props.alertInfo.policyType}</span>{" "}
          -
        </span>

        {props.alertInfo.alertType === "claim" && (
          <Link to="/claims">{bundle["label.viewDetails"]}</Link>
        )}
        {props.alertInfo.alertType === "Payment" && (
          <a href="#" onClick={(e) => e.preventDefault()}>
            {bundle["label.makePayment"]}
          </a>
        )}
        {/* close icon */}
        <a
          href="#"
          onClick={() => closePolicyAlert(props.alertInfo, props.index)}
          className="_closebtn"
        >
          <HighlightOff />
        </a>
      </div>
    </DashboardAlerts>
  );
}
