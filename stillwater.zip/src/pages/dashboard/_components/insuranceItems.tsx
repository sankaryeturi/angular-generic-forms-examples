/* eslint-disable */
import React, { ReactElement, useContext, useState } from "react";
import { Insurancegridtype } from "../../../themes/styles";
import { Grid } from "@material-ui/core";
import { ThemeContext } from "../../../themes";
import { CommonService } from "../../../_services/commonServices";
import { LocalizationContext } from "../../../locales";
import { ThemeIcon } from "../../../themes/styles";

export default function InsuranceItemsComponent(props): ReactElement {
  const [state] = useState(props);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);

  const activeClass = (activeStatus) => {
    let activeClass = "";
    if (activeStatus === true) {
      activeClass = "active";
    }
    return activeClass;
  };

  function tabClick(index) {
    props.policyTabClick(index);
  }
  // for road assistance page class
  function roadAssistance(val, activeClass) {
    let className;
    if (val === "Y" && activeClass === true) {
      className = "trafic-green-icon bg-small";
    } else if (val === "N" && activeClass === true) {
      className = "trafic-red-icon bg-small";
    } else if (activeClass === false) {
      className = "trafic-gray-icon bg-small";
    }
    return className;
  }

  return (
    <Grid item xs={props.xsSize} onClick={() => tabClick(props.ItemIndex)}>
      <Insurancegridtype
        className={`${activeClass(state.insuranceInfo.activeStatus)} ${
          props.dynamicClass
        }`}
        theme={theme}
      >
        <div
          className={`content ${
            props.footerStatus == "true" ? "" : "border-bottem"
          } ${props.dynamicClass} `}
        >
          <div
            className={CommonService.policyIcon(
              state.insuranceInfo.policyType
            )}
          >
            {props.roadAssisMessage === true && (
              <div className="ssp-align-left ssp-pl2 ssp-pt2">
                <ThemeIcon
                  className={roadAssistance(
                    props.insuranceInfo?.policyRoadside,
                    state.insuranceInfo.activeStatus
                  )}
                ></ThemeIcon>
              </div>
            )}
          </div>
          <span>
            {state.insuranceInfo.policyType} Policy
            {state.insuranceInfo.policyNumber} -
          </span>
          {/* Auto policy vehicle info */}
          {(props.insuranceInfo?.policyType.includes("Auto")) && (
            <span>
              {props.insuranceInfo?.policyVehicles &&
                props.insuranceInfo?.policyVehicles.map((data, i) => {
                  if (i < 2) {
                    return (
                      <span key={i}>
                        {data?.modelYear} {data?.make} {data?.model},
                      </span>
                    );
                  }
                })}
            </span>
          )}
          {/* Home property info */}
          {(props.insuranceInfo?.policyType.includes("Home")) && 
            <span>
              {props.insuranceInfo &&
                <span>
                  {props.insuranceInfo?.policyPropertyAddress1} {props.insuranceInfo?.policyPropertyAddress2}
                </span>
              }
            </span>
          }
        </div>
        {props.footerStatus == "true" && (
          <div className="footer">
            <a href="/">
              {bundle["label.nextPaymentDue"]}:
              {state.insuranceInfo?.nextPaymentDueDate}{" "}
              {bundle["label.amount"]}: $
              {state.insuranceInfo?.nextPaymentDueAmount}
            </a>
          </div>
        )}
      </Insurancegridtype>
      {/* Roadside assistance message block */}
      {props.roadAssisMessage === true &&
        state.insuranceInfo.activeStatus === true && (
          <span
            className={`${
              props.insuranceInfo?.policyRoadside == "Y"
                ? "ssp-success"
                : "ssp-error"
            }`}
          >
            {props.insuranceInfo?.policyRoadside == "Y"
              ? bundle.autoId?.roadAssistanceSuccess
              : bundle.autoId?.roadAssistanceError}
          </span>
        )}
    </Grid>
  );
}
