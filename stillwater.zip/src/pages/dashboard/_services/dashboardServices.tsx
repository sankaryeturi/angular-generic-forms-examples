import { URL } from "../../../config/constants";
import { CommonService } from "../../../_services/commonServices";

export class DashboardService {
  /**
   * get note alerts
   */
  public static async getNoteAlerts(): Promise<[]> {
    const url = URL.NOTE_ALERTS;
    const { data } = await CommonService.request("post", url);
    return data;
  }
}
