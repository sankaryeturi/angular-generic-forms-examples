import React, { ReactElement, ReactNode, useState, createContext } from "react";
import { CommonService } from "../../_services/commonServices";
import { DashboardService } from "./_services/dashboardServices";

interface DashboardControllerProps {
  children: ReactNode;
}

interface DashboardState {
  policyList: any;
  policyDetails: any;
  error: any;
  policyDetailserror: any;
  claimsError: any;
  policyAlertsResponseData: any;
  policyAlertsResponseError: any;
}
interface DashboardStateContext extends DashboardState {
  readonly getPoliciesList: () => any;
  readonly getNoteAlerts: () => any;
  readonly updatePolicyAlerts: (alertInfo, userId) => any;
}

const initialState: DashboardState = {
  policyList: null,
  policyDetails: null,
  error: null,
  policyDetailserror: null,
  claimsError: null,
  policyAlertsResponseData: [],
  policyAlertsResponseError: null,
};

const initialContext: DashboardStateContext = {
  ...initialState,
  getPoliciesList: invalidContext,
  updatePolicyAlerts: invalidContext,
  getNoteAlerts: invalidContext,
};

export const DashboardContext = createContext(initialContext);

export function DashboardController(
  props: DashboardControllerProps
): ReactElement {
  const [state, setState] = useState(initialState);
  /** get policies list */
  async function getPoliciesList(): Promise<any> {
    try {
      return { ...initialState };
    } catch (error) {
      setState({ ...initialState, error });
      return { ...initialState };
    }
  }
  /** get note alerts */
  async function getNoteAlerts(): Promise<any> {
    try {
      const responseData = await DashboardService.getNoteAlerts();
      return { ...initialState, noteAlertsResponse: responseData };
    } catch (error) {
      setState({ ...initialState, error });
      throw error;
    }
  }
  /** update policy alert */
  async function updatePolicyAlerts(alertInfo, userId): Promise<any> {
    try {
      const responseData = await CommonService.updatePolicyAlerts(
        alertInfo,
        userId
      );
      setState({ ...state, policyAlertsResponseData: responseData });
      return { ...initialState, policyAlertsResponseData: responseData };
    } catch (error) {
      setState({ ...initialState, policyAlertsResponseError: error });
      return { ...initialState, policyAlertsResponseError: error };
    }
  }

  const context = {
    ...state,
    getPoliciesList,
    updatePolicyAlerts,
    getNoteAlerts,
  };

  return (
    <DashboardContext.Provider value={context}>
      {props.children}
    </DashboardContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a DashboardController?");
}
