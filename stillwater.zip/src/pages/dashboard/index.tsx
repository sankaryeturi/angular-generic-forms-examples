/* eslint-disable */
import React, { ReactElement, useContext, useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import Slider from "react-slick";
import { Grid, Hidden } from "@material-ui/core";
import AlertsComponent from "./_components/alerts";
import InsuranceItemsComponent from "./_components/insuranceItems";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import { Bannerarea, PacificBlueborder } from "./styles";
import {
  Appbodycontainer,
  CarouselSlider,
  OrangeButton,
  ThemeIcon,
  Whitebutton,
} from "../../themes/styles";
import { InitialStateInterface } from "./interface";
import { updatePolicies } from "../../_actions";
import PolicyListDropdownComponent from "../../shared-components/policy-list-dropdown/policy-list-dropdown";
import QuickLinksComponent from "./_components/quickLinks";
import { DashboardContext } from "./dashboardController";

const initialState: InitialStateInterface = {
  policies: [],
  policyHolderName: "",
  claims: [],
  parameterPolicyNumber: "",
};

export default function DashboardPageComponent(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const [dashboardState, setDashboardState] = useState(initialState);
  const [claimsState, setClaimsState] = useState(initialState.claims);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);
  const profile = useSelector(
    (storeState: any) => storeState.accountInfoReducer.profile
  );
  const dispatch = useDispatch();
  const history = useHistory();
  const { updatePolicyAlerts } = useContext(DashboardContext);
  const { getNoteAlerts } = useContext(DashboardContext);

  let policyEmptyState = false;
  let urlPolicyNumber = "";
  /** adding activeStatus to policies */
  let policiesList = policies.policis;
  let alertsList: any = [];
  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policyEmptyState = true;
    if (dashboardState.policies.length === 0) {
      policiesList = policiesList.map((data, i) => {
        // making first policy active
        if (i === 0) {
          data.activeStatus = true;
          urlPolicyNumber = data.policyNumber;
        } else {
          data.activeStatus = false;
        }
        return data;
      });
    }
  }
  useEffect(() => {
    getNoteAlerts()
      .then((response) => {
        setClaimsState(response.noteAlertsResponse?.data?.alerts);
      })
      .catch((error) => {
        console.log("Error: dashboardIndex.tsx - getNoteAlerts()", error);
      });
    setDashboardState({
      ...dashboardState,
      policies: policiesList,
      claims: alertsList,
      parameterPolicyNumber: urlPolicyNumber,
    });
  }, [policyEmptyState]);

  /*** Policy tab clcik functionality  ***/
  const policyTabClick = (policyIndex: string) => {
    let policyNumber;
    const policy = dashboardState.policies.map((policyData, i) => {
      if (policyIndex === i) {
        policyData.activeStatus = true;
        policyNumber = policyData.policyNumber;
      } else {
        policyData.activeStatus = false;
      }
      return policyData;
    });
    // const claims = getClaims(policy);

    dispatch(updatePolicies(policy));

    setDashboardState({
      ...dashboardState,
      policies: policy,
      // claims: claims,
      parameterPolicyNumber: policyNumber,
    });
  };

  /** policy quick links */
  let quickLinksList;
  if (
    dashboardState.policies === undefined ||
    dashboardState.policies.length === 0
  ) {
    quickLinksList = [];
  } else {
    quickLinksList = dashboardState.policies.map((policyData, i) => {
      if (policyData.activeStatus === true) {
        let autoLink;
        if (policyData.policyType === "Auto") {
          autoLink = (
            <>
              <QuickLinksComponent
                xs="4"
                md="2"
                title={bundle["label.autiIdCard"]}
                link={`/autoid/${dashboardState.parameterPolicyNumber}`}
                iconname="address-card-blue-icon medium-size"
              />
              <QuickLinksComponent
                xs="4"
                md="2"
                title={bundle["label.roadsideAssistance"]}
                iconname="trafic-blue-icon medium-size"
                link="/roadAssistance"
              />
            </>
          );
        }
        return (
          <Grid key={i} container spacing={2} justify="center">
            <QuickLinksComponent
              xs="4"
              md="2"
              title={bundle["heading.payments"]}
              link={`/payments/${dashboardState.parameterPolicyNumber}`}
              iconname="ssp-walletblue-big-icon medium-size"
            />
            <QuickLinksComponent
              xs="4"
              md="2"
              title={bundle["label.docNotes"]}
              link={`/docsnotes/${dashboardState.parameterPolicyNumber}`}
              iconname="file-alt-blue-icon medium-size"
            />
            <QuickLinksComponent
              xs="4"
              md="2"
              title={bundle["label.policyInfo"]}
              link={`/policy-information/${dashboardState.parameterPolicyNumber}`}
              iconname="info-blue-icon medium-size"
            />
            <QuickLinksComponent
              xs="4"
              md="2"
              title={bundle["label.claims"]}
              link={`/claims/${dashboardState.parameterPolicyNumber}`}
              iconname="ssp-clipboardcheck-big-icon medium-size"
            />
            {autoLink}
          </Grid>
        );
      }
    });
  }

  /** banner slider settings */
  const slickSliderSettings = {
    dots: false,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    infinite: false,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
        },
      },
    ],
  };
  /** info slider settings */
  const infoSliderSettings = {
    dots: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    infinite: true,
    autoplay: true,
    arrows: false,
  };

  /** policy featurs slider info */
  const policyFeaturesInfo = bundle?.dashboard?.policyFeaturesInfo;

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };
  // hide the policy alert
  const closePolicyAlert = (info, index) => {
    const alerts = claimsState;
    alerts[index].status = "DeActive";
    let alertData = {
      policyNumber: dashboardState?.parameterPolicyNumber,
      alertType: info?.alertType,
      claimNumber: info?.claimNumber,
    };
    updatePolicyAlerts(alertData, profile.userID)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.log(
          `%c Error: index.tsx - closePolicyAlert() ${JSON.stringify(error)}`,
          "color: #FF0000"
        );
      });
    setClaimsState(alerts);
  };

  return (
    <div>
      {/* body */}
      <Appbodycontainer theme={theme}>
        <div className="mobile-fullLayout">
          {/* Alerts list */}
          <div className="clearfix">
            {claimsState?.length !== 0 &&
              claimsState.map((data, i) => {
                return (
                  <div key={i}>
                    {data.status === "Active" && (
                      <AlertsComponent
                        closePolicyAlert={closePolicyAlert}
                        alertInfo={data}
                        index={i}
                      />
                    )}
                  </div>
                );
              })}
          </div>
          {/* Banner area */}
          <Bannerarea theme={theme}>
            <h1 className="ssp-m0">
              {profile?.username} {bundle["heading.dashboardMain"]}
            </h1>
            <div className="gradient-bg">
              {/* policy list for responsive */}
              <Hidden mdUp>
                <form>
                  <PolicyListDropdownComponent
                    policies={dashboardState.policies}
                    policyTabClick={policyTabClick}
                  ></PolicyListDropdownComponent>
                </form>
              </Hidden>
              {/* ./END policy list for responsive */}

              {/* Banner Slider starts */}
              <CarouselSlider theme={theme} className="banner-slider">
                <Slider {...slickSliderSettings}>
                  {dashboardState.policies !== undefined &&
                    dashboardState.policies.map((policyData, i) => {
                      return (
                        <Grid container spacing={1} key={i}>
                          <InsuranceItemsComponent
                            insuranceInfo={policyData}                            
                            ItemIndex={i}
                            policyTabClick={policyTabClick}
                            footerStatus="true"
                            dynamicClass="banner-grid"
                            xsSize="12"
                          />
                        </Grid>
                      );
                    })}
                </Slider>
              </CarouselSlider>
              {/* ./END slider  */}

              {/* Quick links for policy */}
              <div className="quick-links-block">
                <Grid container spacing={2} justify="center">
                  {quickLinksList}
                </Grid>
              </div>
              {/* ./END quick links for policy */}

              {/* payment & claim buttons */}
              <div className="ssp-mt3">
                <Whitebutton
                  className="h-40 dark-blue-border min-w350 ssp-mb3"
                  type="button"
                  theme={theme}
                  onClick={(e) => navigation("payments")}
                >
                  <ThemeIcon className="ssp-walletblue-icon"></ThemeIcon>{" "}
                  {bundle?.button?.makepay}
                </Whitebutton>
                <Whitebutton
                  className="h-40 dark-blue-border min-w350"
                  type="button"
                  theme={theme}
                >
                  <ThemeIcon className="ssp-clipboardcheck"></ThemeIcon>{" "}
                  {bundle["button.fileClaim"]}
                </Whitebutton>
              </div>
              {/* ./END payment & claim buttons */}
            </div>
          </Bannerarea>
          {/* ./END  Banner area */}

          {/* policy features list */}
          <div className="ssp-py3">
            <CarouselSlider theme={theme}>
              <Slider className="ssp-pl0" {...infoSliderSettings}>
                {policyFeaturesInfo.map((info, k) => {
                  return (
                    <div className="ssp-p2" key={k}>
                      <PacificBlueborder
                        theme={theme}
                        className={`${info?.backgroundImageClass}`}
                      >
                        <div>
                          <Grid container>
                            <Grid item xs={12} md={8}>
                              <h2>{info?.title}</h2>
                              <p>
                                <b>{info?.subTitle}</b>
                              </p>
                            </Grid>
                            <Grid
                              item
                              xs={12}
                              md={4}
                              className="ssp-dflex-centerleft"
                            >
                              <OrangeButton
                                theme={theme}
                                type="button"
                                className="shadow"
                              >
                                <ThemeIcon
                                  className={`${info.buttonIconClass}`}
                                ></ThemeIcon>
                                <span className="ssp-pl2">
                                  {info?.buttonContent}
                                </span>
                              </OrangeButton>
                            </Grid>
                          </Grid>
                        </div>
                      </PacificBlueborder>
                    </div>
                  );
                })}
              </Slider>
            </CarouselSlider>
          </div>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
