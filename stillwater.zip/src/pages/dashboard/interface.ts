export interface InitialStateInterface {
  policies: any;
  policyHolderName: string | null;
  claims: any;
  parameterPolicyNumber: string | null;
}