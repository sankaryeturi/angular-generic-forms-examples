import styled from "styled-components";
import downloadappbannerimg from "../../assets/images/mobile-app-graphic.png";

export const Downloadapparea = styled.div`
  max-height: 468px;
  height: 100%;
  background-color: #b0e1ef;
  opacity: 1;
`;

export const Downloadappcontainer = styled.div`
  max-width: ${(props) => props.theme.containerWidth};
  margin: 0 auto;
  height: 100%;
`;
export const Downloadappbanner = styled.div`
  max-height: 468px;
  height: 100%;
  overflow: hidden;
  background-image: url(${downloadappbannerimg});
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;
`;
