import React, { ReactElement, useContext, useEffect } from "react";
import Grid from "@material-ui/core/Grid";
import Hidden from "@material-ui/core/Hidden";
import BannerComponent from "../../shared-components/banner/banner";
import Downloadapp from "../../shared-components/download-app/downloadapp";
import {
  Downloadapparea,
  Downloadappcontainer,
  Downloadappbanner,
} from "./loginStyles";
import { ThemeContext } from "../../themes";
import UrgentMessagesComponent from "../../shared-components/urgent-messages/urgentMessagesComponent";
import { UrgentMessageController } from "../../shared-components/urgent-messages/urgentMessageController";
import { ThemeIcon } from "../../themes/styles";
import { IMAGES } from "../../config/config";

export default function LoginPage(): ReactElement {
  const { theme } = useContext(ThemeContext);

  return (
    <div>
      {/* this header for mobile view */}
      <Hidden mdUp>
        <div className="ssp-loginresponseheader">
          <div className="ssp-homelogo ssp-dflexcenter">
            <Grid container>
              <Grid item xs={11}>
                <img alt="" title="" src={IMAGES.logo} />
              </Grid>
              <Grid item xs={1} className="ssp-dflexcenter">
                <ThemeIcon className="bars-blue-icon"></ThemeIcon>
              </Grid>
            </Grid>
          </div>
        </div>
      </Hidden>
      <Hidden mdUp>
        <UrgentMessageController>
          <UrgentMessagesComponent />
        </UrgentMessageController>
      </Hidden>

      {/* Banner Area*/}
      <BannerComponent />

      {/* App info area*/}
      <Hidden smDown>
        <Downloadapparea theme={theme}>
          <Downloadappcontainer theme={theme}>
            <Grid container>
              <Grid item md={5} lg={4}>
                {/* download apps component */}
                <Downloadapp />
              </Grid>
              <Grid item md={7} lg={8}>
                <Downloadappbanner></Downloadappbanner>
              </Grid>
            </Grid>
          </Downloadappcontainer>
        </Downloadapparea>

        <div className="white-block"></div>
      </Hidden>
    </div>
  );
}
