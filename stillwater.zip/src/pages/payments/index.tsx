/* eslint-disable */
import React, { ReactElement, useContext, useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useParams } from "react-router";
import Slider from "react-slick";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import EFTformComponent from "./_components/eftForm";
import {
  Appbodycontainer,
  Blueheadinggrid,
  Darkblueheadingh3,
  ThemeIcon,
  CarouselSlider,
  Bluebutton,
  SspformGroup,
  Darkbluebutton,
  Darkblueheadingh5,
  OrangeButton,
  Anchor,
  PopupBlock,
  ErrorMessage
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import {
  Grid,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Box,
  Typography,
  makeStyles,
  Hidden,
  Popover,
  Modal
} from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import InsuranceItemsComponent from "../dashboard/_components/insuranceItems";
import { withStyles } from "@material-ui/core/styles";
import { PaymentContext } from "./paymentController";
import { InitialStateInterface } from "./_interfaces/interface";
import { CommonService } from "../../_services/commonServices";
import { updatePolicies } from "../../_actions";
import PolicyListDropdownComponent from "../../shared-components/policy-list-dropdown/policy-list-dropdown";
import { standard } from "../../themes/standard";
import { FilterForm } from "./paymentStyles";
import { IMAGES } from "../../config/config";

const initialState: InitialStateInterface = {
  policies: [],
  currentPolicyNumber: null,
  paymentHistory: [],
  paymentSummary: [],
  tansactionFilterBlock: false,
  filterFromDay: "",
  filterFromMonth: "",
  filterFromYear: "",
  filterToDay: "",
  filterToMonth: "",
  filterToYear: "",
  updateBankInfo: false,
  guidancePopup: false,
  changeEFTblock: false,
  changeEFTsubmit: false,
  confirmEFTblock: false,
  modifyEFTblock: false,
  accountType : [
    "Savings accounts", 
    "Checking accounts", 
    "Money market accounts",  
    "Brokerage accounts", 
    "Individual retirement accounts",
    "Certificates of deposit"
  ],
  makePayDisable: false,
  paymentActionButtons: true
};

const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: standard.darkBlue,
    color: theme.palette.common.white,
    font: "Bold 16px/20px Source Sans Pro;",
    textTransform: "uppercase",
  },
  body: {
    fontSize: 14,
    font: "Bold 16px/20px Source Sans Pro;",
  },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.action.hover,
    color: standard.black,
    font: "Bold 16px/20px Source Sans Pro",
  },
}))(TableRow);

const useStyles = makeStyles({
  darkBlueColor: {
    color: standard.darkBlue,
  },
});

export default function PaymentComponent(): ReactElement {
  const [state, setState] = useState(initialState);
  const [historyState, setHistoryState] = useState(initialState.paymentHistory);
  const [paymentSummary, setPaymentSummary] = useState(
    initialState.paymentSummary
  );
  const [policiesListInfo, setPoliciesListInfo] = useState(
    initialState.policies
  );
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);
  const [selectedValue, setSelectedValue] = React.useState("");
  const { getPaymentHistory, getPolicyDetails, eftSubmit, error } = useContext(PaymentContext);
  const history = useHistory();
  const dispatch = useDispatch();
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const urlParm: any = useParams();

  let policiesEmptyState = false;
  /** adding activeStatus to policies */
  let policiesList = policies.policis;
  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policiesEmptyState = true;
    if (paymentSummary.length == 0) {
      policiesList = policiesList.map((data, i) => {
        if (i === 0) {
          data.activeStatus = true;
        } else {
          data.activeStatus = false;
        }
        return data;
      });
    }
  }

  /**  */
  const handleChange = (event, field?) => {
    setSelectedValue(event.target.value);
  };
  /** filter fields update */
  const handleFilterFieldChange = (event, field?) => {
    var value = event.target.value;
    setState({
      ...state,
      [field]: value,
    });
  };

  /** get the policy details */
  function policyDetails(policyNumber) {
    const policyFilterDetails = policiesList.find((data, i) => {
      if(data.policyNumber === policyNumber) {
        return data;
      }
    })

    getPolicyDetails(policyNumber)
      .then((response) => {
        const policyDetails = {...response.policyDetailsResponse, policyFilterDetails};
        console.log("policy summary", policyDetails)
        setPaymentSummary(policyDetails);        
      })
      .catch((error) => {
        setPaymentSummary([]);
        setHistoryState([]);
        setPoliciesListInfo(policiesListInfo);
      });

      const historyData = {
        policyNumber: urlParm.policyNumber,
        startDate: policyFilterDetails?.policyTerm?.startDate,
        endDate: policyFilterDetails?.policyTerm?.endDate
      }
      getPaymentHistoryDetails(historyData);
  }
  /** get payment history list */
  function getPaymentHistoryDetails(inputData) {
    getPaymentHistory(inputData).then((response) => {
      setHistoryState(response.transactionHistory);
    });
  }
  useEffect(() => {
    try {
      policyDetails(urlParm.policyNumber); // get policy summary      
      setPoliciesListInfo(policiesList); // set policies list to state
      setState({
        ...state,
        currentPolicyNumber: urlParm.policyNumber
      })
    } catch (error) {
      console.log("Error paymentInformation - useEffect", error);
    }
  }, [policiesEmptyState]);

  /** policy tab click function */
  const policyTabClick = (policyIndex) => {
    /** active state change */
    let policyNo = "";
    const policy = policiesListInfo.map((policyData: any, i) => {
      if (policyIndex === i) {
        policyData.activeStatus = true;
        policyNo = policyData.policyNumber;
      } else {
        policyData.activeStatus = false;
      }
      return policyData;
    });
    setPoliciesListInfo(policy);
    dispatch(updatePolicies(policy));
    const historyData = {
      policyNumber: policyNo,
      startDate: "",
      endDate: ""
    }
    getPaymentHistoryDetails(historyData);
    policyDetails(policyNo);
  };

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  /** slider properties */
  const slickSliderSettings = {
    dots: false,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    infinite: false,
  };

  /** transaction filter submit  */
  const filterSubmit = (e) => {
    const historyData = {
      policyNumber: urlParm.policyNumber,
      startDate: state.filterFromMonth +"/"+ state.filterFromDay +"/"+ state.filterFromYear,
      endDate: state.filterToMonth +"/"+ state.filterToDay +"/"+ state.filterToYear,
    }
    getPaymentHistoryDetails(historyData);
    handleFilterClose();
  };
  /** filter form open */
  const openFilterBlock = Boolean(anchorEl);
  /** closing the filter block */
  const handleFilterClose = () => {
    setAnchorEl(null);
    setState({
      ...state,
      filterFromDay: "",
      filterFromMonth: "",
      filterFromYear: "",
      filterToDay: "",
      filterToMonth: "",
      filterToYear: "",
    });
  };
  const handleFilterClick = (e) => {
    setAnchorEl(e.currentTarget);
  };

  const handleChangeEFT = () => {
    setState({
      ...state,
      changeEFTblock: !state.changeEFTblock
    })
  }

  const handleGuidancePopup = (e, type?) => {
    setState({
      ...state,
      guidancePopup: !state.guidancePopup
    })
  }
  const eftFormSubmit = (formInfo) => {
    console.log(formInfo);
    var inputReq = formInfo;
    eftSubmit(inputReq).
      then((response) => {
        setState({
          ...state,
          changeEFTblock: false,
          confirmEFTblock: true,
          makePayDisable: true
        })
      })
      .catch((error) => {
        console.log(error)
      });
  }
  const changeEFTDone = () => {
    setState({
      ...state,
      changeEFTsubmit: true,
      confirmEFTblock: false,
      paymentActionButtons: false
    })
  }
  const updateBankingInfo = () => {
    setState({
      ...state,
      modifyEFTblock: true
    })
  }
  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.payments"]}
            icon="wallet-blue-big.svg"
            iconName="ssp-walletblue-big-icon"
          />
          {/* ./END page title block */}
          {/* Policies list */}
          <div className="ssp-mt3">
            <Hidden smDown>
              {/* Slider */}
              <CarouselSlider theme={theme} className="policy-slider">
                <Slider {...slickSliderSettings}>
                  {policiesListInfo &&
                    policiesListInfo.map((policyData, i) => {
                      return (
                        <InsuranceItemsComponent
                          insuranceInfo={policyData}
                          ItemIndex={i}
                          policyTabClick={policyTabClick}
                          footerStatus="false"
                          xsSize={10}
                          key={i}
                        />
                      );
                    })}
                </Slider>
              </CarouselSlider>
            </Hidden>

            {/* policy list for responsive view */}
            <Hidden mdUp>
              <form>
                <PolicyListDropdownComponent
                  policies={policiesList}
                  dynamicClass="select-field gray"
                  policyTabClick={policyTabClick}
                ></PolicyListDropdownComponent>
              </form>
            </Hidden>
          </div>

          <Grid container className="ssp-mb3">
            <Grid item xs={12} md={12} lg={10}>
              <Blueheadinggrid
                theme={theme}
                className="min-height-auto ssp-mr0"
              >
                <div className="heading ssp-p3">
                  <h3>
                    <ThemeIcon className="wallet-white-icon"></ThemeIcon>
                    {bundle["heading.billing"]}
                  </h3>
                </div>
                <div className="content ssp-p3">
                  <Grid container>
                    <Grid item xs={12} md={4}>
                      {/* Payment Summary details */}
                      <Blueheadinggrid theme={theme}>
                        <div className="heading ssp-p3">
                          <h3>{bundle["heading.paymentSummary"]}</h3>
                        </div>
                        <div className="content white">
                          <div className="display-flex-p">
                            <div className="ssp-p1">
                              {bundle["label.lastPaymentReceived"]}:
                            </div>
                            <div className="ssp-p1">
                              {paymentSummary?.policyFilterDetails?.lastPaymentDate}
                            </div>
                          </div>
                          <div className="display-flex-p">
                            <div className="ssp-p1">
                              {bundle["label.paymentDueDate"]}:
                            </div>
                            <div className="ssp-p1">
                              {paymentSummary?.policyFilterDetails?.nextPaymentDueDate}
                            </div>
                          </div>
                          <div className="display-flex-p">
                            <div className="ssp-p1">
                              {bundle["label.lastPaymentAmount"]}:
                            </div>
                            <div className="ssp-p1">
                              ${paymentSummary?.policyFilterDetails?.lastPaymentAmount}
                            </div>
                          </div>
                          <div className="display-flex-p orange">
                            <div className="ssp-p1">
                              {bundle["label.minimumAmountDue"]}:
                            </div>
                            <div className="ssp-p1">
                              ${paymentSummary?.policyFilterDetails?.nextPaymentDueAmount}
                            </div>
                          </div>
                          <div className="display-flex-p">
                            <div className="ssp-p1">
                              {bundle["label.totalAmountDue"]}:
                            </div>
                            <div className="ssp-p1">
                              ${paymentSummary?.policyFilterDetails?.totalDueAmount}
                            </div>
                          </div>
                        </div>
                      </Blueheadinggrid>
                      {/* ./END Payment Summary details */}
                    </Grid>
                    <Grid item xs={12} md={8}>
                      <Blueheadinggrid theme={theme} className="ssp-mr0">
                        <div className="heading ssp-p3">
                          <h3>{bundle?.payments?.yourPaymentPlan}</h3>
                        </div>
                        <Box p={3} component="div" className="content white ssp-pt4">
                          <Typography component="span">
                            <b>{bundle?.payments?.yourCurrentPaymentPlan}:</b> {bundle?.payments?.yourCurrentPaymentPlanContent}
                          </Typography>                          
                          <Box fontSize={16} className="ssp-blue MuiGrid-grid-md-8" mt={3}>
                            <b>{bundle?.payments?.paymentContactInfo}</b>
                          </Box>

                          {state.paymentActionButtons && (
                            <Box mt={3}>
                              <Bluebutton 
                                theme={theme} 
                                className={`${ state.changeEFTblock || state.confirmEFTblock ? "disableField" : "" } ssp-px3 ssp-mr2`}
                                onClick={handleChangeEFT}
                                disabled={state.changeEFTblock}
                              >
                                {bundle?.button?.changePayPlan}
                              </Bluebutton>
                              <OrangeButton 
                                theme={theme}
                                disabled={state.makePayDisable}
                                className={`${ state.makePayDisable ? "disableField" : "" }`}
                              >
                                {bundle?.button?.makepay}
                              </OrangeButton>
                            </Box>
                          )}

                          {/* error message block */}
                          {error && (
                            <ErrorMessage
                              className="orange ssp-mt2 ssp-inline-block"
                              theme={theme}
                            >
                              <b>{error}</b>
                            </ErrorMessage>
                          )}

                          {state.changeEFTsubmit && 
                            <Darkbluebutton className="ssp-mt4" onClick={() => updateBankingInfo()}>
                              {bundle?.button?.updateBankingInfo}
                            </Darkbluebutton>
                          }
                          {/* change EFT form block */}
                          {state.changeEFTblock && (                          
                            <Box mt={4}>
                              <Darkblueheadingh5 theme={theme} className="extra-bold">
                                {bundle?.heading?.changePayToEFT}
                              </Darkblueheadingh5>
                              {/* EFT form component */}
                              <EFTformComponent 
                                theme={theme}
                                bundle={bundle} 
                                parentState={state} 
                                handleGuidancePopup={handleGuidancePopup}
                                eftFormSubmit={eftFormSubmit} />
                            </Box>
                          )}
                          {/* ./ END change EFT form block */}
                          {/* Confirm EFT block */}
                          {state.confirmEFTblock && (
                            <Box my={3}>
                              <Darkblueheadingh5 
                                theme={theme} 
                                className="extra-bold">{bundle?.heading?.payPlanChange}
                              </Darkblueheadingh5>
                              <p>We have changed the Pay Plan on your policy to EFT. Allow at least 3 business days for this change to occur. </p>
                              <p>The first debit from you account will occur on or after MM/DD/YYYY. Prior to this date you will receive a letter from Stillwater detailing the amount and date of the withdrawal. </p>
                              <p><span className="ssp-dBlock">Date and time you authorized this change. Thu Sep 3, 2020 8:30 AM</span> Policy Number: NP80564655</p>

                              <Grid container>
                                <Grid item sm={12} md={8}>
                                  <Grid container>
                                    <Grid item sm={12} md={6}>
                                      <p className="ssp-m0 ssp-mb1"><b>Routing #:</b> 11123620134</p>
                                      <p className="ssp-m0 ssp-mb1"><b>Account #:</b> ****6343</p>
                                      <p className="ssp-m0 ssp-mb1"><b>Account Type:</b> Checking</p>
                                    </Grid>
                                    <Grid item sm={12} md={6}>
                                      <p className="ssp-m0">Capital One, <br />N.A. P.O. <br />BOX 84539 Richmond, VA</p>
                                    </Grid>
                                  </Grid>
                                </Grid>
                              </Grid>
                              <Box component="p" mt={3}>
                                <Box component="span" fontWeight="bold">
                                  DocuSign will be sent to email associated with your account:
                                </Box>
                                  jay.minnick@stillwater.com
                              </Box>
                              <Darkbluebutton className="ssp-mt3 ssp-px4" onClick={() => changeEFTDone()}>
                                Done
                              </Darkbluebutton>
                              <Anchor href={undefined}
                                      className="text-left underline ssp-blue ssp-mt4 bold"
                                      >
                                        Print Confirmation
                              </Anchor>
                              <Anchor href={undefined}
                                      className="text-left underline ssp-blue ssp-mt3 bold"
                                      >
                                        About Electronic Debits
                              </Anchor>
                              <Box my={5}></Box>
                            </Box>                            
                          ) }
                          {/* ./ END Confirm EFT block */}
                          {/* Modify EFT account block */}
                          {state.modifyEFTblock && (
                            <Box mt={4}>
                              <Darkblueheadingh5 
                                theme={theme} 
                                className="extra-bold">MODIFY EFT ACCOUNT - ENDORSEMENT
                              </Darkblueheadingh5>
                              <Grid container>
                                <Grid item sm={12} md={8}>
                                  <Grid container>
                                    <Grid item sm={6}>
                                      <p className="ssp-m0 ssp-mb1">Current:</p>
                                      <p className="ssp-m0 ssp-mb1"><b>Routing #:</b> 11123620134</p>
                                      <p className="ssp-m0 ssp-mb1"><b>Account #:</b> ****6343</p>
                                      <p className="ssp-m0 ssp-mb1"><b>Account Type:</b> Checking</p>
                                    </Grid>
                                    <Grid item sm={6}>
                                      <p className="ssp-m0 ssp-mt4">Capital One, <br />N.A. P.O. <br />BOX 84539 Richmond, VA</p>
                                    </Grid>
                                  </Grid>
                                </Grid>
                              </Grid>
                              <EFTformComponent theme={theme} parentState={state} />
                            </Box>
                          )}
                          {/* ./ END Modify EFT account block */}
                        </Box>
                      </Blueheadinggrid>
                    </Grid>
                  </Grid>
                </div>
              </Blueheadinggrid>
            </Grid>
          </Grid>

          <Darkblueheadingh3 theme={theme}>
            {bundle["heading.transactionHistory"]}
          </Darkblueheadingh3>

          <div className="ssp-mt3">
            <Grid container>
              <Grid item xs={12} md={12} lg={10}>
                <TableContainer
                  className="tablecontainer"
                  style={{ overflowX: "inherit" }}
                >
                  <Table aria-label="simple table">
                    <TableHead>
                      <TableRow>
                        <StyledTableCell>
                          {bundle["label.processDate"]} &nbsp;
                          <ThemeIcon className="ssp-sort-white"></ThemeIcon>
                        </StyledTableCell>
                        <StyledTableCell align="left">
                          {bundle["label.transaction"]}
                        </StyledTableCell>
                        <StyledTableCell align="left">
                          {bundle["label.amount"]}
                        </StyledTableCell>
                        <StyledTableCell align="left">
                          {bundle["label.balence"]}
                        </StyledTableCell>
                        <StyledTableCell
                          align="left"
                          style={{ position: "relative" }}
                        >
                          <Bluebutton
                            className="h-20 uppercase ssp-py1 ssp-px1"
                            type="button"
                            theme={theme}
                            onClick={(e) => handleFilterClick(e)}
                          >
                            {bundle?.label?.filter}
                          </Bluebutton>
                          <Popover
                            style={{ marginTop: "10px" }}
                            open={openFilterBlock}
                            anchorEl={anchorEl}
                            onClose={handleFilterClose}
                            anchorOrigin={{
                              vertical: "bottom",
                              horizontal: "center",
                            }}
                            transformOrigin={{
                              vertical: "top",
                              horizontal: "center",
                            }}
                          >
                            <FilterForm theme={theme}>
                              <p className="ssp-mt0">
                                <b>{bundle?.payments?.filterContent}</b>
                              </p>
                              <ValidatorForm
                                onSubmit={(e) => filterSubmit(e)}
                                className="ssp-loginform ssp-px3"
                                autoComplete="off"
                              >
                                <label className="dark-label">
                                  {bundle?.label?.fromDate}
                                </label>
                                <Grid container className="ssp-mt2" spacing={1}>
                                  <Grid item xs={4} className="ssp-pb0">
                                    <SspformGroup
                                      theme={theme}
                                      className="gray input50"
                                    >
                                      <TextValidator
                                        fullWidth
                                        onChange={(e) =>
                                          handleFilterFieldChange(
                                            e,
                                            "filterFromMonth"
                                          )
                                        }
                                        name="filterFromMonth"
                                        value={state.filterFromMonth}
                                        placeholder="MM"
                                        type="number"
                                        InputLabelProps={{
                                          shrink: true,
                                        }}
                                      />
                                    </SspformGroup>
                                  </Grid>
                                  <Grid item xs={4} className="ssp-pb0">
                                    <SspformGroup
                                      theme={theme}
                                      className="gray input50"
                                    >
                                      <TextValidator
                                        fullWidth
                                        onChange={(e) =>
                                          handleFilterFieldChange(
                                            e,
                                            "filterFromDay"
                                          )
                                        }
                                        name="filterFromDay"
                                        value={state.filterFromDay}
                                        placeholder="DD"
                                        type="number"
                                        InputLabelProps={{
                                          shrink: true,
                                        }}
                                      />
                                    </SspformGroup>
                                  </Grid>
                                  <Grid item xs={4} className="ssp-pb0">
                                    <SspformGroup
                                      theme={theme}
                                      className="gray input50"
                                    >
                                      <TextValidator
                                        fullWidth
                                        onChange={(e) =>
                                          handleFilterFieldChange(
                                            e,
                                            "filterFromYear"
                                          )
                                        }
                                        name="filterFromYear"
                                        value={state.filterFromYear}
                                        placeholder="YYYY"
                                        type="number"
                                        InputLabelProps={{
                                          shrink: true,
                                        }}
                                      />
                                    </SspformGroup>
                                  </Grid>
                                </Grid>

                                <label className="dark-label">
                                  {bundle?.label?.toDate}
                                </label>
                                <Grid container className="ssp-mt2" spacing={1}>
                                  <Grid item xs={4} className="ssp-pb0">
                                    <SspformGroup
                                      theme={theme}
                                      className="gray input50"
                                    >
                                      <TextValidator
                                        fullWidth
                                        onChange={(e) =>
                                          handleFilterFieldChange(
                                            e,
                                            "filterToMonth"
                                          )
                                        }
                                        name="filterToMonth"
                                        value={state.filterToMonth}
                                        placeholder="MM"
                                        type="number"
                                        InputLabelProps={{
                                          shrink: true,
                                        }}
                                      />
                                    </SspformGroup>
                                  </Grid>
                                  <Grid item xs={4} className="ssp-pb0">
                                    <SspformGroup
                                      theme={theme}
                                      className="gray input50"
                                    >
                                      <TextValidator
                                        fullWidth
                                        onChange={(e) =>
                                          handleFilterFieldChange(
                                            e,
                                            "filterToDay"
                                          )
                                        }
                                        name="filterToDay"
                                        value={state.filterToDay}
                                        placeholder="DD"
                                        type="text"
                                        InputLabelProps={{
                                          shrink: true,
                                        }}
                                      />
                                    </SspformGroup>
                                  </Grid>
                                  <Grid item xs={4} className="ssp-pb0">
                                    <SspformGroup
                                      theme={theme}
                                      className="gray input50"
                                    >
                                      <TextValidator
                                        fullWidth
                                        onChange={(e) =>
                                          handleFilterFieldChange(
                                            e,
                                            "filterToYear"
                                          )
                                        }
                                        name="filterToYear"
                                        value={state.filterToYear}
                                        placeholder="YYYY"
                                        type="number"
                                        InputLabelProps={{
                                          shrink: true,
                                        }}
                                      />
                                    </SspformGroup>
                                  </Grid>
                                </Grid>

                                <div className="ssp-align-center">
                                  <Bluebutton
                                    className="ssp-mr1 ssp-px4"
                                    type="button"
                                    theme={theme}
                                    onClick={handleFilterClose}
                                  >
                                    {bundle["button.cancel"]}
                                  </Bluebutton>
                                  <Darkbluebutton
                                    className="ssp-px4"
                                    theme={theme}
                                  >
                                    {bundle["button.submit"]}
                                  </Darkbluebutton>
                                </div>
                              </ValidatorForm>
                            </FilterForm>
                          </Popover>
                        </StyledTableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {historyState?.length === 0 && (
                        <StyledTableRow>
                          <StyledTableCell colSpan={5} align="center">
                            {bundle["text.emptyRecords"]}
                          </StyledTableCell>
                        </StyledTableRow>
                      )}

                      {(historyState) &&
                        historyState.map((historyInfo: any, i) => (
                          <StyledTableRow key={i}>
                            <StyledTableCell component="th" scope="row">
                              {historyInfo.processDate}
                            </StyledTableCell>
                            <StyledTableCell align="left">
                              <a
                                href={`${historyInfo.tranDetailDocURL}`}
                                target="_blank"
                                className={`${classes.darkBlueColor}`}
                              >
                                {historyInfo.transactionInfo}
                              </a>
                            </StyledTableCell>
                            <StyledTableCell align="left">
                              ${CommonService.priceFormat(historyInfo.amount)}
                            </StyledTableCell>
                            <StyledTableCell align="left">
                              ${CommonService.priceFormat(historyInfo.balance)}
                            </StyledTableCell>
                            <StyledTableCell align="left"></StyledTableCell>
                          </StyledTableRow>
                        ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Grid>
            </Grid>
          </div>
        </div>
        <div className="white-block"></div>
        {/* guidence popup */}
        <Modal
          open={state.guidancePopup}
          onClose={handleGuidancePopup}
          aria-labelledby="simple-modal-title"
          aria-describedby="simple-modal-description"
        >
          <PopupBlock theme={theme} className="guidanceCheckPopup">
            <a className="close-icon" onClick={handleGuidancePopup}>
              <ThemeIcon className="close-circle-blue-icon" />
            </a>
            <img src={IMAGES.check} className="ssp-mt5 ssp-w100" />
          </PopupBlock>
        </Modal>
      </Appbodycontainer>
    </div>
  );
}
