export interface InitialStateInterface {
  policies: any;
  currentPolicyNumber: string | null;
  paymentHistory: any;
  paymentSummary: any;
  tansactionFilterBlock: boolean;
  filterFromDay: string;
  filterFromMonth: string;
  filterFromYear: string;
  filterToDay: string;
  filterToMonth: string;
  filterToYear: string;
  updateBankInfo: boolean;
  guidancePopup: boolean;
  changeEFTblock: boolean;
  changeEFTsubmit: boolean;
  confirmEFTblock: boolean;
  modifyEFTblock: boolean;
  accountType: any;
  makePayDisable: boolean;
  paymentActionButtons: boolean;
}
