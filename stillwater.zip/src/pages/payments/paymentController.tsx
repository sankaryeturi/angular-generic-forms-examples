import React, { createContext, ReactNode, ReactElement, useState } from "react";
import { PaymentService } from "./paymentServices";
import { PoliciesService } from "../../_services/policiesServices";

interface PymentControllerProps {
  children: ReactNode;
}

interface PaymentState {
  transactionHistory: any;
  transactionHistoryError: any;
  policyDetailsResponse: any;
  policyDetailsError: any;
  eftResponse: any;
  error: any;
}
interface PaymentStateContext extends PaymentState {
  readonly getPaymentHistory: (inputData) => any;
  readonly getPolicyDetails: (polucyNumber) => any;
  readonly eftSubmit: (inputReq) => any;
}
const initialState: PaymentState = {
  transactionHistory: null,
  transactionHistoryError: null,
  policyDetailsResponse: null,
  policyDetailsError: null,
  eftResponse: null,
  error: null
};
const initialContext: PaymentStateContext = {
  ...initialState,
  getPaymentHistory: invalidContext,
  getPolicyDetails: invalidContext,
  eftSubmit: invalidContext
};

export const PaymentContext = createContext(initialContext);

export function PaymentController(props: PymentControllerProps): ReactElement {
  const [state, setState] = useState(initialState);
  async function getPaymentHistory(inputData): Promise<any> {
    try {
      const responseData: any = await PaymentService.getPaymentHistory(
        inputData
      );
      setState({ ...state, transactionHistory: responseData });
      return {
        ...initialState,
        transactionHistory: responseData.data?.transactionHistory,
      };
    } catch (error) {
      setState({ ...state, transactionHistoryError: error });
      return { ...initialState, transactionHistoryError: error };
    }
  }

  async function getPolicyDetails(policyNumber): Promise<any> {
    try {
      const responseData = await PoliciesService.policyDetails(policyNumber);
      setState({ ...state, policyDetailsResponse: responseData.data });
      return {
        ...initialState,
        policyDetailsResponse: responseData.data,
      };
    } catch (error) {
      setState({ ...state, policyDetailsError: error });
      throw error;
    }
  }

  async function eftSubmit(inputReq) {
    try {
      const responseData = await PaymentService.eftSubmit(inputReq);
      setState({ ...state, eftResponse: responseData, error: null });
      return { ...initialState, eftResponse: responseData, error: null };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          error: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }

  const context = {
    ...state,
    getPaymentHistory,
    getPolicyDetails,
    eftSubmit
  };
  return (
    <PaymentContext.Provider value={context}>
      {props.children}
    </PaymentContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a paymentController?");
}
