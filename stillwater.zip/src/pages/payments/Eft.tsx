import React, { ReactElement, useContext, useState } from "react";
import { Grid, Select, InputLabel, MenuItem } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { SspformGroup, Bluebutton, OrangeButton } from "../../themes/styles";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";

const initialState = {
  routing: "",
  account: "",
  accountType: "",
  formSubmit: false,
};

export default function EFTComponent(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const [state, setState] = useState(initialState);
  const { bundle } = useContext(LocalizationContext);

  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };

  const emailFormSubmit = (e: any): void => {
    console.log(e);
  };
  return (
    <div>
      <h3>{bundle?.payments?.eftLabel1}</h3>
      <div className="font-14 ssp-f-bold ssp-error">
        {bundle?.payments?.errorInfo}
      </div>
      <Grid item xs={12} md={12}>
        <ValidatorForm onSubmit={(e) => emailFormSubmit(e)} autoComplete="off">
          <Grid item xs={12} md={4}>
            <Grid container className="ssp-mt2">
              <Grid item xs={12}>
                <SspformGroup theme={theme} className="gray">
                  <TextValidator
                    label="Routing #"
                    fullWidth
                    name="routing"
                    onChange={(e) => handleChange(e, "routing")}
                    value={state.routing}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </SspformGroup>
              </Grid>
              <Grid item xs={12}>
                <SspformGroup theme={theme} className="gray">
                  <TextValidator
                    label="Account #"
                    fullWidth
                    name="account"
                    onChange={(e) => handleChange(e, "account")}
                    value={state.account}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </SspformGroup>
              </Grid>
              <Grid item xs={12}>
                <SspformGroup theme={theme} className="gray">
                  <InputLabel htmlFor="age-native-simple">
                    {bundle["label.accountType"]}
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    onChange={(e) => handleChange(e, "accountType")}
                    value={state.accountType}
                    className="select-field gray"
                    inputProps={{
                      name: "accountType",
                      id: "age-native-simple",
                    }}
                  >
                    <MenuItem value={10}>Saving</MenuItem>
                    <MenuItem value={20}>Current</MenuItem>
                    <MenuItem value={30}>Salary</MenuItem>
                  </Select>
                </SspformGroup>
              </Grid>
            </Grid>
          </Grid>
          <div className="font-16 ssp-pb4 ssp-pt4 ssp-f-bold">
            {bundle?.payments?.context1}
          </div>
          <div className="font-14 ssp-pb1 ssp-f-bold">
            {bundle?.payments?.context2}
          </div>
          <div className="font-14 ssp-pb4 ssp-f-bold">
            <a href="#">{bundle["label.printAcknowledgment"]}</a>
          </div>
          <div className="font-14 ssp-f-bold">
            {bundle["label.click"]} <a href="#">{bundle["label.here"]}</a>{" "}
            {bundle?.payments?.context3}
          </div>
          <Grid item xs={12} md={4}>
            <div className="ssp-mt4 ssp-align-center">
              <Bluebutton className="w-25 ssp-mb3 ssp-mr3 p25-30" theme={theme}>
                <span>{bundle["button.cancel"]}</span>
              </Bluebutton>
              <OrangeButton theme={theme} type="button" className="p25-30">
                <span>{bundle["button.submitPayment"]}</span>
              </OrangeButton>
            </div>
          </Grid>
        </ValidatorForm>
      </Grid>
    </div>
  );
}
