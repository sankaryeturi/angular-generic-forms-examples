import styled from "styled-components";

export const FilterForm = styled.div`
  border: 1px solid ${(props) => props.theme.darkBlue};
  //min-height: 10px;
  width: 340px;
  padding: 25px;
  background-color: ${(props) => props.theme.white};
  color: ${(props) => props.theme.black};
`;
