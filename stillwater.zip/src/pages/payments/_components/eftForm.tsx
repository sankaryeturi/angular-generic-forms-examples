import React, { ReactElement, useEffect, useState } from "react";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import {
    Bluebutton,
    SspformGroup,
    Darkbluebutton,
    Anchor,
} from "../../../themes/styles";
import {
    Grid,
    Box,
    InputLabel,
    Select,
    MenuItem,
    Checkbox,
    FormControlLabel
} from "@material-ui/core";
import { ValidationService } from "../../../_services/validation";
import { stat } from "fs";

const initialState = {
    accountType: "",
    routingNumber: "",
    accountNumber: "",
    confirmAccountNumber: "",
    termsConditions: true
}

export default function EFTformComponent(props): ReactElement {
  const [state, setState] = useState(initialState);

  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };

  const handleCheck = (e) => {
    setState({
      ...state,
      termsConditions: !state.termsConditions
    })
  }

  useEffect(() => {
    ValidationService.isPasswordMatch(state.accountNumber);
  }, [state.accountNumber]);

  const guidancePopup = () => {
    props.handleGuidancePopup();
  }

  const formSubmit = () => {
    props.eftFormSubmit(state);
  }

  return (
    <ValidatorForm
      onSubmit={(e) => formSubmit()}
      autoComplete="off"
    >
      <Grid container className="ssp-mt2" spacing={2}>
        <Grid item xs={12} md={6}>
          <SspformGroup
            theme={props.theme}
            className={`gray input50`}
          >
            <InputLabel shrink>{props?.bundle["label.accountType"]}</InputLabel>
            <Select
              className={`gray select-field`}
              value={state.accountType}
              onChange={(e) => handleChange(e, "accountType")}
            >
              {props?.parentState?.accountType?.map((accountData, i) => (
                <MenuItem value={accountData}>
                  {accountData}
                </MenuItem>
              ))}
            </Select>
          </SspformGroup>
        </Grid>
        <Grid item xs={12} md={6}>
          <SspformGroup
            theme={props.theme}
            className="input50 ssp-mb2 gray"
          >
            <InputLabel shrink>
              <Anchor
                href={undefined}
                className="ssp-blue underline text-left"
                onClick={() => guidancePopup()}
              >{props?.bundle?.label?.routingNumber}</Anchor>
            </InputLabel>
            <TextValidator
                fullWidth
                onChange={(e) => handleChange(e, "routingNumber")}
                name="routingNumber"
                type="text"
                value={state.routingNumber}
                validators={["required"]}
                errorMessages={[props?.bundle?.validation?.routingNoRequired]}
                InputLabelProps={{
                  shrink: true,
                }}
            />
          </SspformGroup>
        </Grid>
        <Grid item xs={12} md={6}>
          <SspformGroup
            theme={props.theme}
            className="input50 ssp-mb2 gray"
          >
            <InputLabel shrink>
              <Anchor
                href={undefined}
                className="ssp-blue underline text-left"
                onClick={() => guidancePopup()}
              >{props?.bundle?.label?.accountNumber}</Anchor>
            </InputLabel>
            <TextValidator
                fullWidth
                onChange={(e) => handleChange(e, "accountNumber")}
                name="accountNumber"
                type="text"
                value={state.accountNumber}
                validators={["required"]}
                errorMessages={[props?.bundle?.validation?.accountNoRequired]}
                InputLabelProps={{
                  shrink: true,
                }}
            />
          </SspformGroup>
        </Grid>
        <Grid item xs={12} md={6}>
          <SspformGroup
            theme={props.theme}
            className="input50 ssp-mb2 gray"
          >
            <InputLabel shrink>{props?.bundle?.label?.confirmAccountNumber}</InputLabel>
            <TextValidator
                fullWidth
                onChange={(e) => handleChange(e, "confirmAccountNumber")}
                name="confirmAccountNumber"
                type="text"
                value={state.confirmAccountNumber}
                validators={["required", "isPasswordMatch"]}
                errorMessages={[props?.bundle?.validation?.confirmAccountNoRequired, props?.bundle?.validation?.accountNoShouldMatch]}
                InputLabelProps={{
                  shrink: true,
                }}
            />
          </SspformGroup>
        </Grid>
      </Grid>
      <Box>
        <Anchor
          href={undefined}
          onClick={(e) => e.preventDefault}
          theme={props.theme}
          className="dark-blue ssp-inline-block underline"
        >
          {props?.bundle?.label?.clickHere}
        </Anchor> 
        <span> {props?.bundle?.payments?.context3}</span>
        <Box mt={2}>
          <FormControlLabel
            control={<Checkbox checked={state.termsConditions} onChange={(e) => handleCheck(e)} name="" color="primary" />}
            label={props?.bundle?.payments?.termsConditionsLabel}
          />
        </Box>
        <div className="ssp-my4">
          <Bluebutton
            className="ssp-mr3 ssp-px5"
            type="button"
            theme={props.theme}
            onClick={(e) => e.preventDefault}
          >
            {props?.bundle["button.cancel"]}
          </Bluebutton>
          <Darkbluebutton className="ssp-px5" theme={props.theme}>
            <span>{props?.bundle["button.save"]}</span>
          </Darkbluebutton>
        </div>
      </Box>
    </ValidatorForm>
  )
}