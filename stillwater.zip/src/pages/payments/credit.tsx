import React, { ReactElement, useContext, useState } from "react";
import { Grid, Radio } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { ThemeContext } from "../../themes";
import { SspformGroup, Bluebutton, OrangeButton } from "../../themes/styles";
import { LocalizationContext } from "../../locales";

const initialState = {
  cardNumber: "",
  cardHolderName: "",
  month: "",
  year: "",
  cvv: "",
  creditAddress: "",
  billingAddress: "",
  formSubmit: false,
};

export default function CreditComponent(): ReactElement {
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const [selectedValue] = React.useState("address");
  const { bundle } = useContext(LocalizationContext);

  const emailFormSubmit = (e: any): void => {
    console.log(e);
  };

  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };

  return (
    <div>
      <h3>{bundle["heading.creditCardInfo"]}</h3>
      <Grid item xs={12} md={4}>
        <ValidatorForm onSubmit={(e) => emailFormSubmit(e)} autoComplete="off">
          <Grid container className="ssp-mt2">
            <Grid item xs={12}>
              <SspformGroup theme={theme} className="gray">
                <TextValidator
                  label="Card Number"
                  fullWidth
                  name="cardNumber"
                  onChange={(e) => handleChange(e, "cardNumber")}
                  value={state.cardNumber}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </SspformGroup>
            </Grid>
          </Grid>
          <Grid container className="ssp-mt2">
            <Grid item xs={12}>
              <SspformGroup theme={theme} className="gray">
                <TextValidator
                  label="Card Holder's Name"
                  fullWidth
                  name="cardHolderName"
                  onChange={(e) => handleChange(e, "cardHolderName")}
                  value={state.cardHolderName}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </SspformGroup>
            </Grid>
          </Grid>
          <div className="ssp-dflexright">
            <div>
              <label className="dark-label">
                {bundle["label.expirationDate"]}
              </label>
              <Grid container className="ssp-mt2" spacing={1}>
                <Grid item xs={4} md={4} className="ssp-pb0">
                  <SspformGroup theme={theme} className="gray input100">
                    <TextValidator
                      fullWidth
                      name="month"
                      onChange={(e) => handleChange(e, "month")}
                      value={state.month}
                      placeholder="MM"
                      type="number"
                      InputLabelProps={{
                        shrink: true,
                      }}
                      onInput={(e) => {
                        e.target.value = Math.max(0, parseInt(e.target.value))
                          .toString()
                          .slice(0, 2);
                      }}
                    />
                  </SspformGroup>
                </Grid>
                <div className="ssp-crossLine"></div>
                <Grid item xs={4} md={4} className="ssp-pb0">
                  <SspformGroup theme={theme} className="gray input100">
                    <TextValidator
                      fullWidth
                      name="year"
                      onChange={(e) => handleChange(e, "year")}
                      value={state.year}
                      placeholder="YY"
                      type="number"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </SspformGroup>
                </Grid>
              </Grid>
            </div>
            <div>
              <label className="dark-label">{bundle["label.cvv"]}#</label>
              <Grid item xs={4} md={8} className="ssp-pb0">
                <SspformGroup theme={theme} className="gray input120">
                  <TextValidator
                    fullWidth
                    name="cvv"
                    onChange={(e) => handleChange(e, "cvv")}
                    value={state.cvv}
                    type="number"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </SspformGroup>
              </Grid>
            </div>
          </div>

          <Grid container>
            <Grid item xs={12}>
              <h4>{bundle["heading.billingAddressCard"]}</h4>
              <div className="display-flex">
                <Radio
                  checked={selectedValue === "address"}
                  onChange={(e) => handleChange(e, "creditAddress")}
                  value={state.creditAddress}
                  color="primary"
                  name="address"
                  inputProps={{ "aria-label": "address" }}
                  className="ssp-align"
                />
                <div className="ssp-inline-block">
                  <div className="heading-color">
                    {bundle?.payments?.creditDebitCard}
                  </div>
                  <div className="paragraph-color">
                    <span className="ssp-dBlock">931 OAKES ST</span>
                    <span className="ssp-dBlock">PALO ALTO,</span>
                    <span className="ssp-dBlock">CA 94303-2555</span>
                  </div>
                </div>
              </div>

              <div>
                <Radio
                  checked={selectedValue === "billingAddress"}
                  onChange={(e) => handleChange(e, "billingAddress")}
                  value={state.billingAddress}
                  color="primary"
                  name="address"
                  inputProps={{ "aria-label": "BILLINGADDRESS" }}
                />
                <div className="ssp-inline-block">
                  <div className="heading-color">
                    {bundle?.payments?.eftLabel}
                  </div>
                </div>
              </div>
            </Grid>
          </Grid>
          <div className="ssp-mt4 ssp-align-center">
            <Bluebutton className="w-25 ssp-mb3 ssp-mr3" theme={theme}>
              <span>{bundle["button.cancel"]}</span>
            </Bluebutton>
            <OrangeButton theme={theme} type="button" className="p25-30">
              <span>{bundle["button.submitPayment"]}</span>
            </OrangeButton>
          </div>
        </ValidatorForm>
      </Grid>
    </div>
  );
}
