import { URL } from "../../config/constants";
import { CommonService } from "../../_services/commonServices";

export class PaymentService {
  // get payments history
  public static async getPaymentHistory(inputData): Promise<[]> {
    const url = URL.PAYMENT_HISTORY;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "post",
      url,
      inputData,
      loginToken
    );
    return data;
  }

  public static async eftSubmit (inputReq): Promise<[]> {
    const url = URL.EFT_SUBMIT;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("post", url, inputReq, loginToken);
    return data;
  }
}
