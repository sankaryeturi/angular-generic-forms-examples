import React, { ReactElement, useContext, useState } from "react";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  Blueheadinggrid,
  ThemeIcon,
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { Grid, Radio } from "@material-ui/core";
import EFTComponent from "./Eft";
import CreditComponent from "./credit";

export default function MakePaymentComponent(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const [selectedValue, setSelectedValue] = useState("credit");

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["heading.payments"]}
            icon="wallet-blue-big.svg"
            iconName="ssp-walletblue-big-icon"
          />
          {/* ./END page title block */}
          <Grid container>
            <Grid item xs={12} md={10}>
              <Blueheadinggrid
                theme={theme}
                className="ssp-mt3 min-height-auto"
              >
                <div className="heading ssp-p3">
                  <h3>
                    <ThemeIcon className="wallet-white-icon"></ThemeIcon>
                    {bundle["heading.billing"]}
                  </h3>
                </div>
                <div className="content ssp-sm-px3 ssp-px6">
                  <Grid container>
                    <Grid item xs={12} md={12}>
                      <Blueheadinggrid
                        theme={theme}
                        className="min-height-auto ssp-mr0"
                      >
                        <div className="heading ssp-p3">
                          <h3>{bundle["label.makePayment"]}</h3>
                        </div>
                        <div className="content white">
                          <Grid item xs={12} md={4}>
                            <div className="display-flex-p ssp-mt3">
                              <div>
                                <div className="ssp-pb2">
                                  {bundle["label.paymentPlan"]}:{" "}
                                </div>
                                <div>{bundle["label.paymentDueDate"]}: </div>
                              </div>
                              <div>
                                <div className="ssp-pb2">100% Full Pay </div>
                                <div>05/18/20</div>
                              </div>
                            </div>
                          </Grid>

                          <div className="ssp-mt4">
                            <Grid item xs={12} md={4}>
                              <div className="ssp-blue font-16">
                                <b>{bundle["label.amount"]} - $820</b>
                              </div>
                              <div className="font-12 ssp-f-bold">
                                {bundle?.payments?.makepayContext1}
                              </div>
                            </Grid>
                          </div>

                          <div className="ssp-mt5">
                            <div className="ssp-pb2">
                              <Radio
                                checked={selectedValue === "credit"}
                                onChange={handleChange}
                                value="credit"
                                color="primary"
                                name="radio-button-Card"
                                inputProps={{ "aria-label": "CREDIT" }}
                              />
                              <div className="ssp-inline-block heading-color">
                                {bundle?.payments?.creditDebitCard}
                              </div>
                            </div>

                            <div>
                              <Radio
                                checked={selectedValue === "eft"}
                                onChange={handleChange}
                                value="eft"
                                color="primary"
                                name="radio-button-Eft"
                                inputProps={{ "aria-label": "EFT" }}
                              />
                              <div className="ssp-inline-block">
                                <div className="heading-color">
                                  {bundle?.payments?.eftLabel}
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="ssp-mt5">
                            {selectedValue === "credit" ? (
                              <CreditComponent />
                            ) : (
                              <EFTComponent />
                            )}
                          </div>
                        </div>
                      </Blueheadinggrid>
                    </Grid>
                  </Grid>
                </div>
              </Blueheadinggrid>
            </Grid>
          </Grid>
        </div>
      </Appbodycontainer>
    </div>
  );
}
