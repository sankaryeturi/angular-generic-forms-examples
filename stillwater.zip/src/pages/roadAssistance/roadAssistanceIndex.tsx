/* eslint-disable */
import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  ThemeIcon,
  Darkblueheadingh4,
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import InsuranceItemsComponent from "../dashboard/_components/insuranceItems";
import { Grid, Hidden } from "@material-ui/core";
import PolicyListDropdownComponent from "../../shared-components/policy-list-dropdown/policy-list-dropdown";
const initialState = {
  policies: [],
};

export default function RoadAssistance(): ReactElement {
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);

  let policyEmptyState = false;
  let policiesList = policies.policis;

  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policyEmptyState = true;
    if (state.policies.length == 0) {
      policiesList = policiesList.filter((data, i) => {
        if (data.policyType === "Auto") {
          if (i === 0) {
            data.activeStatus = true;
          }
          return data;
        }
      });
    }
  }

  useEffect(() => {
    setState({ ...state, policies: policiesList });
  }, [policyEmptyState]);

  /** policy tab click function */
  const policyTabClick = (policyIndex: any) => {
    console.log(policyIndex);
    /** active state change */
    let policyNo = "";
    const policy: any = state.policies.map((policyData: any, i) => {
      if (policyIndex === i) {
        policyData.activeStatus = true;
        policyNo = policyData.policyNumber;
      } else {
        policyData.activeStatus = false;
      }
      return policyData;
    });
    setState({ ...state, policies: policy });
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["label.roadsideAssistance"]}
            icon="setting.svg"
            iconName="trafic-blue-icon"
          />
          {/* ./END page title block */}
          <div className="ssp-mt3">
            <Hidden smDown>
              <Grid container spacing={2}>
                {state.policies.map((policyData, i) => {
                  return (
                    <>
                      <InsuranceItemsComponent
                        insuranceInfo={policyData}
                        key={i}
                        ItemIndex={i}
                        policyTabClick={policyTabClick}
                        footerStatus="false"
                        xsSize="2"
                        roadAssisMessage={true}
                      />
                    </>
                  );
                })}
              </Grid>
            </Hidden>

            {/* policy list for responsive view */}
            <Hidden mdUp>
              <form>
                <PolicyListDropdownComponent
                  policies={state.policies}
                  dynamicClass="select-field gray"
                  policyTabClick={policyTabClick}
                ></PolicyListDropdownComponent>
              </form>
            </Hidden>

            <Grid container>
              <Grid item xs={12} md={5}>
                <Grid container className="ssp-mt6">
                  <Grid item xs={1}>
                    <div className="ssp-pt2">
                      <ThemeIcon className="trafic-blue-icon"></ThemeIcon>
                    </div>
                  </Grid>
                  <Grid item xs={11}>
                    <Darkblueheadingh4 theme={theme} className="ssp-align-left">
                      {bundle.autoId?.roadAssistanceToPolicy}
                    </Darkblueheadingh4>
                    <p className="ssp-mt0">
                      <b>
                        Call: <span className="ssp-blue">(866)890-1234</span>
                      </b>
                    </p>
                  </Grid>
                </Grid>

                <Grid container className="ssp-mt4">
                  <Grid item xs={1}>
                    <div className="ssp-pt2">
                      <ThemeIcon className="life-ring-blue-icon"></ThemeIcon>
                    </div>
                  </Grid>
                  <Grid item xs={11}>
                    <Darkblueheadingh4 theme={theme} className="ssp-align-left">
                      {bundle.autoId?.roadAssistanceNeedHelp}
                    </Darkblueheadingh4>
                    <p className="ssp-mt0">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit
                    </p>
                    <p className="ssp-mt0">
                      <b>
                        {bundle.label?.call}:{" "}
                        <span className="ssp-blue">
                          {bundle.autoId?.addPolicyContact}
                        </span>
                      </b>
                    </p>
                  </Grid>
                </Grid>

                <Grid container className="ssp-mt4">
                  <Grid item xs={1}>
                    <div className="ssp-pt1">
                      <ThemeIcon className="toolbox-blue-icon"></ThemeIcon>
                    </div>
                  </Grid>
                  <Grid item xs={11}>
                    <Darkblueheadingh4 theme={theme} className="ssp-align-left">
                      {bundle.autoId?.roadAssistanceCover}
                    </Darkblueheadingh4>
                    <ul className="style-inside ssp-mt2">
                      <li>{bundle.autoId.assistanceCoverList.towing}</li>
                      <li>
                        {bundle.autoId.assistanceCoverList.batteryService}
                      </li>
                      <li>
                        {bundle.autoId.assistanceCoverList.deliveryService}
                      </li>
                      <li>
                        {bundle.autoId.assistanceCoverList.flatTireChange}
                      </li>
                      <li>
                        {bundle.autoId.assistanceCoverList.lockoutService}
                      </li>
                    </ul>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12} md={5}>
                <Grid container className="ssp-mt4">
                  <Grid item xs={1}>
                    <div className="ssp-pt2">
                      <ThemeIcon className="steering-wheel-blue-icon"></ThemeIcon>
                    </div>
                  </Grid>
                  <Grid item xs={11}>
                    <Darkblueheadingh4 theme={theme} className="ssp-align-left">
                      {bundle.autoId?.roadAssistanceDriverConfidently}
                    </Darkblueheadingh4>
                    <p className="ssp-mt2">{bundle["text.dummycontent"]}</p>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </div>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
