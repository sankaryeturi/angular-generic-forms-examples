import React, { ReactElement, ReactNode, useState, createContext } from "react";
import { SettingsService } from "../../account-settings/_services/settingsService";
import { ForgotService } from "../_services/services";

interface ForgotControllerProps {
  children: ReactNode;
}

interface ForgotState {
  UserSecurityQusResponseData: any;
  securityQuestionsError: any;
  ForgotPasswordResponse: any;
  ForgotUserIdResponse: any;
  ForgotPasswordError: any;
  ForgotUserIdError: any;
}
interface ForgotStateContext extends ForgotState {
  readonly getSecurityQuestions: (inputReq) => any;
  readonly submitForgotPassword: (inputData) => any;
  readonly submitForgotUserId: (inputData) => any;
}

const initialState: ForgotState = {
  UserSecurityQusResponseData: [],
  securityQuestionsError: "",
  ForgotPasswordResponse: [],
  ForgotUserIdResponse: [],
  ForgotPasswordError: "",
  ForgotUserIdError: "",
};
const initialContext: ForgotStateContext = {
  ...initialState,
  getSecurityQuestions: invalidContext,
  submitForgotPassword: invalidContext,
  submitForgotUserId: invalidContext,
};

export const ForgotContext = createContext(initialContext);

export function ForgotController(props: ForgotControllerProps): ReactElement {
  const [state, setState] = useState(initialState);
  /** get security Questoins by user id */
  async function getSecurityQuestions(inputReq: any): Promise<any> {
    try {
      const responseData = await SettingsService.getUserSecurityQus(inputReq);
      setState({ ...state, UserSecurityQusResponseData: responseData, ForgotPasswordError: null });
      return { ...initialState, UserSecurityQusResponseData: responseData, ForgotPasswordError: null };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          ForgotPasswordError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  /** submit forgot password form */
  async function submitForgotPassword(inputData): Promise<any> {
    try {
      const responseData = await ForgotService.submitForgotPassword(inputData);
      setState({ ...state, ForgotPasswordResponse: responseData, ForgotPasswordError: null });
      return { ...initialState, ForgotPasswordResponse: responseData, ForgotPasswordError: null };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          ForgotPasswordError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  /** submit forgot userid form */
  async function submitForgotUserId(inputData): Promise<any> {
    try {
      const responseData = await ForgotService.submitForgotUserId(inputData);
      setState({ ...initialState, ForgotUserIdResponse: responseData });
      return { ...initialState, ForgotUserIdResponse: responseData };
    } catch (error) {
      setState({ ...initialState, ForgotUserIdError: error });
      throw error;
    }
  }
  const context = {
    ...state,
    getSecurityQuestions,
    submitForgotPassword,
    submitForgotUserId,
  };
  return (
    <ForgotContext.Provider value={context}>
      {props.children}
    </ForgotContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a forgotController?");
}
