import React, { ReactElement, useContext, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import {
  Grid,
  Radio,
  Modal,
  RadioGroup,
  FormControlLabel,
} from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import {
  Appbodycontainer,
  Darkblueheadingh3,
  DarkblueLink,
  Bluebutton,
  Darkbluebutton,
  SspformGroup,
  ErrorMessage,
} from "../../themes/styles";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import { PasswordInitialStateInterface } from "./_interface/interface";
import { ForgotContext } from "./_controller/forgotController";
import ClientIdPopup from "./_components/clientIdPopup";
import SuccessBlockComponent from "./_components/successBlock";

const initialState: PasswordInitialStateInterface = {
  submitDisable: true,
  sessionType: null,
  userId: "",
  clientId: "",
  clientPopupOpen: false,
  userIdInputBlock: false,
  clientIdInputBlock: false,
  formSubmit: false,
  questionsBlock: false,
  securityQuestions: [],
  successMessage: null,
  failMessage: null,
};

export default function ForgotPassword(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const [state, setState] = useState(initialState);
  const history = useHistory();
  const { getSecurityQuestions, submitForgotPassword, ForgotPasswordError } = useContext(
    ForgotContext
  );

  /** handle change for input fields */
  const handleTypeChange = (e: any, field: any = undefined) => {
    const inputVal = e.target.value;
    const dynamicData = { ...state, [field]: inputVal, failMessage: null };
    if (inputVal === "useridCheck") {
      dynamicData.userIdInputBlock = true;
      dynamicData.clientIdInputBlock = false;
      dynamicData.clientId = "";
    } else if (inputVal === "clientidCheck") {
      dynamicData.userIdInputBlock = false;
      dynamicData.clientIdInputBlock = true;
      dynamicData.questionsBlock = false;
      dynamicData.userId = "";
    }
    setState(dynamicData);
  };
  // change input fields
  const handleChange = (e: any, field: any) => {
    const val = e.target.value;
    setState({
      ...state,
      [field]: val,
      submitDisable: false,
    });
  };
  // updating the state for user answers
  const handleAnswer = (e, index) => {
    const value = e.target.value;
    const userAttempts = state.securityQuestions;
    userAttempts[index].answer = value;
    setState({
      ...state,
      securityQuestions: userAttempts,
    });
  };
  // form submit
  const submit = () => {
    const postRequest: any = {};

    if (state.sessionType === "useridCheck") {
      postRequest.userId = state.userId;
      postRequest.questions = state.securityQuestions;
      postRequest.type = "userid";
    } else {
      postRequest.clientId = state.clientId;
      postRequest.type = "cientid";
    }

    submitForgotPassword(postRequest)
      .then((response) => {
        setState({
          ...state,
          successMessage: bundle.login?.forgotPasswordSuccessMessage,
          formSubmit: true,
        });
      })
      .catch((error) => {
        setState({
          ...state,
          failMessage: error.errors[0]?.errorDescription,
        });
      });
  };
  // popup toggle state change
  const handleClientPopup = () => {
    setState({ ...state, clientPopupOpen: !state.clientPopupOpen });
  };
  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };
  // activating the security question after blur on the user id input field
  const userIdonblur = () => {
    if (state.userId) {
      const inputReq = {
        userId: state.userId,
      };
      getSecurityQuestions(inputReq)
        .then((response) => {
          const questions =
            response?.UserSecurityQusResponseData?.data?.questions;
          const userAttempts: any = [];
          // console.log("questoins", questions);
          questions.map((data, i) => {
            const info: any = {};
            info.questionText = data.questionText;
            info.questionID = data.questionID;
            info.index = i;
            info.answer = "";
            userAttempts.push(info);
          });
          setState({
            ...state,
            securityQuestions: userAttempts,
            questionsBlock: true,
            failMessage: null
          });
        })
        .catch((error) => {
          console.log("Error userIdonblur() - forgotPassword.tsx", error);
          setState({
            ...state,
            failMessage: error?.errors[0]?.errorDescription,
            questionsBlock : false,
            securityQuestions: []
          });
        });
    }
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          <Darkblueheadingh3 theme={theme}>
            {bundle?.heading?.forgotPassword}
          </Darkblueheadingh3>
          <Grid container>
            <Grid item xs={12} md={8} lg={5}>
              {state.formSubmit === true && (
                <SuccessBlockComponent
                  successMessage={state.successMessage}
                  navigation={() => navigation("login")}
                  theme={theme}
                  returnLogin={bundle?.button?.returnLogin}
                />
              )}
              {state.formSubmit === false && (
                <ValidatorForm onSubmit={(e) => submit()} autoComplete="off">
                  <DarkblueLink
                    theme={theme}
                    href="#"
                    onClick={() => navigation("forgotuserid")}
                    className="bold ssp-mt2"
                  >
                    {bundle?.troubleLogging?.userIdNavigateText}
                  </DarkblueLink>

                  {/* fail alert message */}
                  {state.failMessage && (
                    <ErrorMessage
                      className="orange ssp-mt2 ssp-dBlock"
                      theme={theme}
                    >
                      <b>{state.failMessage}</b>
                    </ErrorMessage>
                  )}

                  <div className="ssp-mt2">
                    <RadioGroup>
                      <FormControlLabel
                        name="useridCheck"
                        id="useridCheck"
                        value="useridCheck"
                        control={<Radio color="primary" />}
                        onChange={(e) => handleTypeChange(e, "sessionType")}
                        checked={state.sessionType === "useridCheck"}
                        label={bundle?.troubleLogging?.passcodeContent1}
                        className="bold"
                      />
                    </RadioGroup>
                  </div>
                  {/* user id input field block */}
                  {state.userIdInputBlock === true && (
                    <div>
                      <Grid container className="ssp-ml6">
                        <Grid item xs={10} md={8}>
                          <SspformGroup
                            theme={theme}
                            className="input50 ssp-mb2 gray"
                          >
                            <TextValidator
                              label={bundle["label.userid"]}
                              fullWidth
                              onChange={(e) => handleChange(e, "userId")}
                              onBlur={(e) => userIdonblur()}
                              name="userId"
                              id="userId"
                              type="text"
                              value={state.userId}
                              validators={["required"]}
                              errorMessages={[
                                bundle?.validation?.useridRequired,
                              ]}
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </SspformGroup>
                        </Grid>
                      </Grid>
                      {state.questionsBlock === true &&
                        state.securityQuestions.map((questionsData, i) => {
                          return (
                            <div key={i}>
                              <Grid container className="ssp-ml6">
                                <Grid item xs={10} md={8}>
                                  <SspformGroup
                                    theme={theme}
                                    className="input50 ssp-mb2 gray"
                                  >
                                    <TextValidator
                                      label={questionsData?.questionText}
                                      fullWidth
                                      onChange={(e) => handleAnswer(e, i)}
                                      name="email"
                                      type="text"
                                      value={state.securityQuestions[i].answer}
                                      validators={["required"]}
                                      errorMessages={[
                                        bundle["validation.answerRequired"],
                                      ]}
                                      InputLabelProps={{
                                        shrink: true,
                                      }}
                                    />
                                  </SspformGroup>
                                </Grid>
                              </Grid>
                            </div>
                          );
                        })}
                    </div>
                  )}

                  {/* client id bock start */}
                  <div>
                    <RadioGroup>
                      <FormControlLabel
                        name="clientidCheck"
                        id="clientidCheck"
                        value="clientidCheck"
                        control={<Radio color="primary" />}
                        onChange={(e) => handleTypeChange(e, "sessionType")}
                        checked={state.sessionType === "clientidCheck"}
                        label={bundle?.troubleLogging?.passcodeContent2}
                      />
                    </RadioGroup>
                    {/* client id input field block */}
                    {state.clientIdInputBlock === true && (
                      <div>
                        <Grid container className="ssp-ml6">
                          <Grid item xs={10} md={8}>
                            <SspformGroup
                              theme={theme}
                              className="input50 ssp-mb2 gray position-relative"
                            >
                              <DarkblueLink
                                theme={theme}
                                href="#"
                                onClick={handleClientPopup}
                                className="bold label-right"
                              >
                                {bundle?.label?.whatsThis}
                              </DarkblueLink>
                              <TextValidator
                                label={bundle?.label?.clientId}
                                fullWidth
                                onChange={(e) => handleChange(e, "clientId")}
                                name="clientId"
                                type="text"
                                value={state.clientId}
                                validators={["required"]}
                                errorMessages={[
                                  bundle["validation.clientIdRequired"],
                                ]}
                                InputLabelProps={{
                                  shrink: true,
                                }}
                              />
                            </SspformGroup>
                          </Grid>
                        </Grid>
                      </div>
                    )}
                  </div>

                  <div className="ssp-mt4 ssp-align-center">
                    <Bluebutton
                      className="ssp-mr3 min-w150"
                      type="button"
                      theme={theme}
                      onClick={() => navigation("login")}
                    >
                      {bundle["button.cancel"]}
                    </Bluebutton>
                    <Darkbluebutton
                      disabled={state.submitDisable}
                      className={`min-w150 ${
                        state.submitDisable ? "disableField" : ""
                      }`}
                      theme={theme}
                    >
                      <span>{bundle["button.submit"]}</span>
                    </Darkbluebutton>
                  </div>
                </ValidatorForm>
              )}
            </Grid>
          </Grid>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>

      <Modal
        open={state.clientPopupOpen}
        onClose={handleClientPopup}
        aria-labelledby="simple-modal-title"
        aria-describedby="simple-modal-description"
      >
        <ClientIdPopup navigation={navigation} closePopup={handleClientPopup} />
      </Modal>
    </div>
  );
}
