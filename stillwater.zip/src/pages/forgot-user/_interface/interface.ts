export interface PasswordInitialStateInterface {
  submitDisable: boolean;
  sessionType: string | null;
  userId: string | null;
  clientId: string | null;
  clientPopupOpen: boolean;
  userIdInputBlock: boolean;
  clientIdInputBlock: boolean;
  formSubmit: boolean;
  questionsBlock: boolean;
  securityQuestions: any;
  successMessage: string | null;
  failMessage: string | null;
}

export interface UsaerIdInitialStateInterface {
  formSubmit: boolean;
  clientPopupOpen: boolean;
  successMessage: string | null;
  failMessage: string | null;
  email: string;
  clientId: string;
}
