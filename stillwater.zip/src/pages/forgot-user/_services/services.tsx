import { URL } from "../../../config/constants";
import { CommonService } from "../../../_services/commonServices";

export class ForgotService {
  /** submit forgot password */
  public static async submitForgotPassword(inputData): Promise<[]> {
    let url;
    const inputRequest: any = {};
    if (inputData?.type === "userid") {
      const data = inputData.questions.map((data, i) => {
        return {
          questionID: data.questionID,
          questionText: data.questionText,
          answer: data.answer,
        };
      });
      inputRequest.userId = inputData.userId;
      inputRequest.questions = data;
      url = URL.FORGOT_PASSWORD_VERIFY_ANS;
    } else {
      inputRequest.clienId = inputData.clientId;
      url = URL.FORGOT_PASSWORD_CLIENTURL;
    }
    const { data } = await CommonService.request("post", url, inputRequest);
    return data;
  }
  /** submit forgot user id*/
  public static async submitForgotUserId(inputData): Promise<[]> {
    const url = URL.FORGOT_USERID;
    const { data } = await CommonService.request("post", url, inputData);
    return data;
  }
}
