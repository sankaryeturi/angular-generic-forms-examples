import React, { ReactElement, useContext, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import {
  Appbodycontainer,
  Darkblueheadingh3,
  DarkblueLink,
  Bluebutton,
  Darkbluebutton,
  SspformGroup,
  ErrorMessage,
} from "../../themes/styles";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import { Grid, Modal } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import ClientIdPopup from "./_components/clientIdPopup";
import { UsaerIdInitialStateInterface } from "./_interface/interface";
import { ForgotContext } from "./_controller/forgotController";
import SuccessBlockComponent from "./_components/successBlock";

const initialState: UsaerIdInitialStateInterface = {
  email: "",
  clientId: "",
  formSubmit: false,
  clientPopupOpen: false,
  successMessage: null,
  failMessage: null,
};
export default function ForgotUserId(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const [state, setState] = useState(initialState);
  const history = useHistory();
  const { submitForgotUserId } = useContext(ForgotContext);

  // change input fields
  const handleChange = (e: any, field: any) => {
    const val = e.target.value;
    setState({
      ...state,
      [field]: val,
    });
  };

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  // form submit
  const submit = () => {
    const postRequest = {
      email: state.email,
      clientID: state.clientId,
    };

    submitForgotUserId(postRequest)
      .then((response) => {
        setState({
          ...state,
          successMessage: bundle.login?.forgotUserIDSuccessMessage,
          formSubmit: true,
        });
      })
      .catch((error) => {
        const errorMessage = error?.errors[0]?.errorDescription;
        setState({
          ...state,
          failMessage: errorMessage,
        });
      });
  };

  // popup toggle state change
  const handleClientPopup = () => {
    setState({ ...state, clientPopupOpen: !state.clientPopupOpen });
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          <Darkblueheadingh3 theme={theme}>
            {bundle?.heading?.forgotUserid}
          </Darkblueheadingh3>
          <Grid container>
            <Grid item xs={12} md={8} lg={5}>
              {state.formSubmit === true && (
                <SuccessBlockComponent
                  successMessage={state.successMessage}
                  navigation={() => navigation("login")}
                  theme={theme}
                  returnLogin={bundle?.button?.returnLogin}
                />
              )}
              {state.formSubmit === false && (
                <ValidatorForm onSubmit={(e) => submit()} autoComplete="off">
                  <DarkblueLink
                    theme={theme}
                    onClick={() => navigation("forgotpassword")}
                    className="bold ssp-mt2 ssp-inline-block"
                  >
                    {bundle?.troubleLogging?.forfotPassClick}
                  </DarkblueLink>
                  {state.failMessage && (
                    <ErrorMessage
                      className="orange ssp-mt2 ssp-dBlock"
                      theme={theme}
                    >
                      <b>{state.failMessage}</b>
                    </ErrorMessage>
                  )}
                  <div>
                    <SspformGroup
                      theme={theme}
                      className="input50 ssp-mb2 gray position-relative"
                    >
                      {/* link for open the popup */}
                      <DarkblueLink
                        theme={theme}
                        onClick={handleClientPopup}
                        className="bold label-right underline"
                      >
                        {bundle?.label?.whatsThis}
                      </DarkblueLink>
                      <TextValidator
                        label={bundle?.label?.clientId}
                        fullWidth
                        name="clientId"
                        id="clientId"
                        type="text"
                        onChange={(e) => handleChange(e, "clientId")}
                        value={state.clientId}
                        validators={["required"]}
                        errorMessages={[bundle["validation.clientIdRequired"]]}
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                    </SspformGroup>
                  </div>

                  <div>
                    <SspformGroup
                      theme={theme}
                      className="input50 ssp-mb2 gray"
                    >
                      <TextValidator
                        label={bundle?.label?.email}
                        fullWidth
                        name="email"
                        id="email"
                        type="text"
                        onChange={(e) => handleChange(e, "email")}
                        value={state.email}
                        validators={["required", "isEmail"]}
                        errorMessages={[
                          bundle?.validation?.emailRequired,
                          bundle?.validation?.emailPattern,
                        ]}
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                    </SspformGroup>
                  </div>
                  <div className="ssp-mt4 ssp-align-right">
                    <Bluebutton
                      className="ssp-mr3 ssp-px6"
                      type="button"
                      theme={theme}
                      onClick={() => navigation("login")}
                    >
                      {bundle["button.cancel"]}
                    </Bluebutton>
                    <Darkbluebutton className="ssp-px6" theme={theme}>
                      <span>{bundle["button.submit"]}</span>
                    </Darkbluebutton>
                  </div>
                </ValidatorForm>
              )}
            </Grid>
          </Grid>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>

      <Modal
        open={state.clientPopupOpen}
        onClose={handleClientPopup}
        aria-labelledby="simple-modal-title"
        aria-describedby="simple-modal-description"
      >
        <ClientIdPopup navigation={navigation} closePopup={handleClientPopup} />
      </Modal>
    </div>
  );
}
