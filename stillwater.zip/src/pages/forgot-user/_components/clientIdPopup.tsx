import React, { ReactElement, useContext } from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import { standard } from "../../../themes/standard";
import { Darkblueheadingh3, ThemeIcon } from "../../../themes/styles";
import { ThemeContext } from "../../../themes";
import { LocalizationContext } from "../../../locales";
import clientImage from "../../../assets/images/clientid-info.png";

function getModalStyle() {
  const top = 50;
  const left = 50;

  return {
    top: `${top}%`,
    left: `${left}%`,
    transform: `translate(-${top}%, -${left}%)`,
    minHeight: "40%",
  };
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    paper: {
      position: "absolute",
      width: "40%",
      backgroundColor: theme.palette.background.paper,
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      [theme.breakpoints.down("md")]: {
        width: "85%",
      },
    },
    closeAlignment: {
      position: "absolute",
      top: "25px",
      right: "20px",
    },
  })
);

export default function ClientIdPopup(props): ReactElement {
  const classes = useStyles();
  const [modalStyle] = React.useState(getModalStyle);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);

  return (
    <>
      <div style={modalStyle} className={`${classes.paper} `}>
        <a className={`${classes.closeAlignment}`} onClick={props.closePopup}>
          <ThemeIcon className="close-circle-blue-icon" />
        </a>
        <div>
          <Darkblueheadingh3 theme={theme} className="ssp-mt5">
            {bundle?.label?.clientId}
          </Darkblueheadingh3>
          <p>{bundle?.troubleLogging?.passcodeContent3}</p>
          <div className="ssp-dflexcenter">
            <img
              className="ssp-mt4"
              src={clientImage}
            />
          </div>
        </div>
      </div>
    </>
  );
}
