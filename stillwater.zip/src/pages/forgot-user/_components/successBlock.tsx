import React, { ReactElement, useContext } from "react";
import { Darkbluebutton } from "../../../themes/styles";

export default function SuccessBlockComponent(props): ReactElement {
  return (
    <>
      <p>
        <b>{props.successMessage}</b>
      </p>
      <Darkbluebutton
        onClick={() => {
          props?.navigation();
        }}
        className="ssp-px6"
        theme={props?.theme}
      >
        {props?.returnLogin}
      </Darkbluebutton>
    </>
  );
}
