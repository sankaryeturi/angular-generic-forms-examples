import { URL } from "../../config/constants";
import { CommonService } from "../../_services/commonServices";

export class ClaimsService {
  // get claims list
  public static async getClaimsHistory(inputReq): Promise<[]> {
    const url = URL.GET_CLAIM_hISTORY;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "post",
      url,
      inputReq,
      loginToken
    );
    return data;
  }
  /** get PROPERTY LOSS TYPE list */
  public static async getPropertyLossType(): Promise<[]> {
    const url = URL.GET_PROPERTYLOSSTYPE;
    const { data } = await CommonService.request("get", url);
    return data;
  }
  /** get   */
  public static async getPropertyLossCauseList(): Promise<[]> {
    const url = URL.GET_PROPERTYLOSSCAUSELIST;
    const { data } = await CommonService.request("get", url);
    return data;
  }
  /** submit claim */
  public static async submitClaimInfo(requestData): Promise<[]> {
    const url = URL.submitClaim(requestData.policyNumber);
    const { data } = await CommonService.request("post", url, requestData);
    return data;
  }
}
