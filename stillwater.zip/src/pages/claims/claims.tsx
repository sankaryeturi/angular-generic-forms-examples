/* eslint-disable */
import React, { ReactElement, useContext, useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import Slider from "react-slick";
import {
  Appbodycontainer,
  Blueheadinggrid,
  BlueBorderBtn,
  ThemeIcon,
  CarouselSlider,
  Anchor,
} from "../../themes/styles";
import { ThemeContext } from "../../themes";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { LocalizationContext } from "../../locales";
import { Grid, Hidden, Button } from "@material-ui/core";
import InsuranceItemsComponent from "../dashboard/_components/insuranceItems";
import PolicyListDropdownComponent from "../../shared-components/policy-list-dropdown/policy-list-dropdown";
import { ClaimsContext } from "./claimsController";
import { updatePolicies } from "../../_actions";

const initialState = {
  toDoPlaceholder: false,
  viewClaim: false,
  viewClaim2: false,
  currentPolicyNumber: "",
  policies: [],
  claimsHistory: [],
};

export default function ClaimsComponent(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const [state, setState] = useState(initialState);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);
  const [policiesListInfo, setPoliciesListInfo] = useState(
    initialState.policies
  );
  const [claimsHistory, setClaimsHistory] = useState(
    initialState.claimsHistory
  );
  const { getClaimsList, error } = useContext(ClaimsContext);
  const dummyContentLabel = bundle["text.dummycontentsmall"];
  const claimNumberLabel = bundle?.claims?.claimNumber;
  const dateOfLossLabel = bundle?.claims?.dateOfLoss;
  const dateReportedLabel = bundle?.claims?.dateReported;
  const lossDescriptionLabel = bundle?.claims?.lossDescription;
  const claimExaminerLabel = bundle?.claims?.claimExaminer;
  const claimExaminerPhoneLabel = bundle?.claims?.claimExaminerPhone;
  const claimExaminerEmailLabel = bundle?.claims?.claimExaminerEmail;
  const dispatch = useDispatch();
  const history = useHistory();

  let policiesEmptyState = false;
  /** adding activeStatus to policies */
  let policiesList = policies.policis;
  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policiesEmptyState = true;
  }
  /** get the claims history */
  function getClaimsHistory(policyNumber) {
    const inputReq = {policyNumber:policyNumber}
    getClaimsList(inputReq).then((response) => {
      const claimsList = response.claimsList.map((claimData) => {
        claimData.expand = false;
        return claimData;
      });
      setClaimsHistory(claimsList);
    });
  }

  useEffect(() => {
    try {
      let activePolicy = policiesList.filter((data, i) => {
        if (data.activeStatus === true) {
          return data;
        }
      });
      if (activePolicy.length === 0) {
        policiesList[0].activeStatus = true;
        setState({
          ...state,
          currentPolicyNumber: policiesList[0].policyNumber,
        });
      } else {
        setState({
          ...state,
          currentPolicyNumber: activePolicy[0].policyNumber,
        });
      }
      setPoliciesListInfo(policiesList);
      getClaimsHistory(state.currentPolicyNumber);
    } catch (error) {
      console.log("Error paymentInformation - useEffect", error);
    }
  }, [policiesEmptyState]);

  const policyListStaticArray = [];
  /** policy tab click function */
  const policyTabClick = (policyIndex) => {
    /** active state change */
    let policyNo = "";
    const policy: any = policiesListInfo.map((policyData: any, i) => {
      if (policyIndex === i) {
        policyData.activeStatus = true;
        policyNo = policyData.policyNumber;
      } else {
        policyData.activeStatus = false;
      }
      return policyData;
    });
    setPoliciesListInfo(policy);
    dispatch(updatePolicies(policy));
  };
  // expand block toggle
  const toggleTodoPlaceholder = (claimNumber, type = "") => {
    if (type === "") {
      const claimsList: any = claimsHistory.map((data: any, i) => {
        if (data.claimnumber === claimNumber) {
          data.expand = !data.expand;
        }
        return data;
      });
      setClaimsHistory(claimsList);
    }
  };

  const toggleViewClaim = (e) => {
    setState({
      ...state,
      viewClaim: !state.viewClaim,
    });
  };

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  /** slider properties */
  const slickSliderSettings = {
    dots: false,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    infinite: false,
    centerMode: false
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["label.claims"]}
            iconName="ssp-walletblue-big-icon"
          />
          {/* ./END page title block */}
          {/* Policies list */}
          <div className="ssp-mt3">
            <Hidden smDown>
              {/* Slider */}
              <CarouselSlider theme={theme} className="policy-slider">
                <Slider {...slickSliderSettings}>
                  {policiesListInfo &&
                    policiesListInfo.map((policyData, i) => {
                      return (
                        <InsuranceItemsComponent
                          insuranceInfo={policyData}
                          ItemIndex={i}
                          policyTabClick={policyTabClick}
                          footerStatus="false"
                          xsSize="10"
                        />
                      );
                    })}
                </Slider>
              </CarouselSlider>
              {/* ./END Slider */}
            </Hidden>

            {/* policy list for responsive view */}
            <Hidden mdUp>
              <form>
                <PolicyListDropdownComponent
                  policies={policiesListInfo}
                  dynamicClass="select-field gray"
                  policyTabClick={policyTabClick}
                ></PolicyListDropdownComponent>
              </form>
            </Hidden>
          </div>
          {/* ./ END Policies list */}

          <Grid container className="ssp-mb3">
            <Grid item xs={12} md={12}>
              <Blueheadinggrid
                theme={theme}
                className="min-height-auto ssp-mr0"
              >
                <div className="heading ssp-p3">
                  <h3>{bundle["label.reportAclaim"]}</h3>
                </div>
                <div className="content ssp-p3">
                  <p className="ssp-w50 ssp-mt0">{dummyContentLabel}</p>
                  <Button
                    variant="contained"
                    className="ssp-orange"
                    onClick={() => navigation("submitclaim")}
                  >
                    {bundle["label.reportAclaim"]}
                  </Button>
                </div>
              </Blueheadinggrid>
            </Grid>

            <Grid item xs={12} md={6}>
              <Blueheadinggrid
                theme={theme}
                className="min-height-auto ssp-mr1"
              >
                <div className="heading ssp-p3">
                  <h3>{bundle["label.activeClaims"]}</h3>
                </div>
                {claimsHistory.length === 0 && (
                  <>
                    <div className="content ssp-p0 ssp-mb2">
                      <p className="ssp-m0 ssp-p4">
                        You have no active claims for this policy. If you feel
                        this is an error, 
                        <Anchor href={undefined} className="ssp-blue text-left ssp-inline-block underline"> please contact our customer support team</Anchor>
                      </p>
                    </div>
                  </>
                )}
                {claimsHistory &&
                  claimsHistory.map((claimData: any, j) => {
                    if (claimData.status === "ACTIVE") {
                      return (
                        <div className="content ssp-p0 ssp-mb2" key={j}>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {claimNumberLabel}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.claimnumber}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {dateOfLossLabel}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.dateofloss}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {dateReportedLabel}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.dateofreport}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {lossDescriptionLabel}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.description}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {claimExaminerLabel}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.examinerdetails.name}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {claimExaminerPhoneLabel}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.examinerdetails.phonenumber}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {claimExaminerEmailLabel}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.examinerdetails.email}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border ssp-bg-lightCyan">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {bundle?.claims?.claimUpdates}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.updates}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {bundle?.claims?.thingsToDo}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.thingstodo}</b>
                                <BlueBorderBtn
                                  theme={theme}
                                  className="ssp-px4 ssp-mt2 ssp-mb2 ssp-dBlock bold"
                                  onClick={() =>
                                    toggleTodoPlaceholder(
                                      claimData.claimnumber,
                                      "activeClaim"
                                    )
                                  }
                                >
                                  <span className="ssp-pr3">
                                    {bundle["label.itemToDo"]}
                                  </span>
                                  <ThemeIcon
                                    className={`${
                                      claimData.expand === true
                                        ? "angle-up-blue-icon"
                                        : "angle-down-blue-icon"
                                    } ssp-inline-block angle-icon-adjust`}
                                  ></ThemeIcon>
                                </BlueBorderBtn>
                              </Grid>
                              <Grid item xs={12}>
                                {claimData.expand && (
                                  <div className="ssp-dflexcenter ssp-m3 white-block ssp-dash-border">
                                    {bundle["label.toDoPlaceholder"]}
                                  </div>
                                )}
                              </Grid>
                            </Grid>
                          </div>
                        </div>
                      );
                    }
                  })}
              </Blueheadinggrid>
            </Grid>

            <Grid item xs={12} md={6}>
              <Blueheadinggrid
                theme={theme}
                className="min-height-auto ssp-mr0"
              >
                <div className="heading ssp-p3">
                  <h3>{bundle["label.claimHistory"]}</h3>
                </div>
                {claimsHistory.length === 0 && (
                  <>
                    <div className="content ssp-p0 ssp-mb2">
                      <p className="ssp-m0 ssp-p4">
                        You have no previous claims for this policy. If you feel
                        this is an error, 
                        <Anchor href={undefined} className="ssp-blue text-left ssp-inline-block underline">
                          please contact our customer support team
                        </Anchor>                        
                      </p>
                    </div>
                  </>
                )}
                {claimsHistory &&
                  claimsHistory.map((claimData: any, k) => {
                    if (claimData.status === "CLOSED") {
                      return (
                        <div className="content ssp-p0 ssp-mb2" key={k}>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {claimNumberLabel}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.claimnumber}</b>
                              </Grid>
                            </Grid>
                          </div>
                          <div className="ssp-gray-border">
                            <Grid container className="ssp-p1">
                              <Grid item xs={5} md={4}>
                                <label className="ssp-px3">
                                  {bundle?.claims?.claimClosed}:
                                </label>
                              </Grid>
                              <Grid item xs={7} md={8}>
                                <b>{claimData.claimclosed}</b>
                              </Grid>
                            </Grid>
                            <BlueBorderBtn
                              theme={theme}
                              className="ssp-px4 ssp-ml3 ssp-mt2 ssp-mb2 bold"
                              onClick={() =>
                                toggleTodoPlaceholder(claimData.claimnumber)
                              }
                            >
                              <span className="ssp-pr3">
                                {bundle?.claims?.viewClaimDetails}
                              </span>
                              <ThemeIcon
                                className={`${
                                  claimData.expand === true
                                    ? "angle-up-blue-icon"
                                    : "angle-down-blue-icon"
                                } ssp-inline-block angle-icon-adjust`}
                              ></ThemeIcon>
                            </BlueBorderBtn>
                            {claimData.expand && (
                              <div>
                                <hr />
                                <div className="ssp-gray-border">
                                  <Grid container className="ssp-p1">
                                    <Grid item xs={5} md={4}>
                                      <label className="ssp-px3">
                                        {dateOfLossLabel}:
                                      </label>
                                    </Grid>
                                    <Grid item xs={7} md={8}>
                                      <b>{claimData.dateofloss}</b>
                                    </Grid>
                                  </Grid>
                                </div>
                                <div className="ssp-gray-border">
                                  <Grid container className="ssp-p1">
                                    <Grid item xs={5} md={4}>
                                      <label className="ssp-px3">
                                        {dateReportedLabel}:
                                      </label>
                                    </Grid>
                                    <Grid item xs={7} md={8}>
                                      <b>{claimData.dateofreport}</b>
                                    </Grid>
                                  </Grid>
                                </div>
                                <div className="ssp-gray-border">
                                  <Grid container className="ssp-p1">
                                    <Grid item xs={5} md={4}>
                                      <label className="ssp-px3">
                                        {lossDescriptionLabel}:
                                      </label>
                                    </Grid>
                                    <Grid item xs={7} md={8}>
                                      <b>{claimData.description}</b>
                                    </Grid>
                                  </Grid>
                                </div>
                                <div className="ssp-gray-border">
                                  <Grid container className="ssp-p1">
                                    <Grid item xs={5} md={4}>
                                      <label className="ssp-px3">
                                        {claimExaminerLabel}:
                                      </label>
                                    </Grid>
                                    <Grid item xs={7} md={8}>
                                      <b>{claimData.examinerdetails.name}</b>
                                    </Grid>
                                  </Grid>
                                </div>
                                <div className="ssp-gray-border">
                                  <Grid container className="ssp-p1">
                                    <Grid item xs={5} md={4}>
                                      <label className="ssp-px3">
                                        {claimExaminerPhoneLabel}:
                                      </label>
                                    </Grid>
                                    <Grid item xs={7} md={8}>
                                      <b>
                                        {claimData.examinerdetails.phonenumber}
                                      </b>
                                    </Grid>
                                  </Grid>
                                </div>
                                <div className="ssp-gray-border">
                                  <Grid container className="ssp-p1">
                                    <Grid item xs={5} md={4}>
                                      <label className="ssp-px3">
                                        {claimExaminerEmailLabel}:
                                      </label>
                                    </Grid>
                                    <Grid item xs={7} md={8}>
                                      <b>
                                        <a href="" className="ssp-blue">
                                          {claimData.examinerdetails.email}
                                        </a>
                                      </b>
                                    </Grid>
                                  </Grid>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    }
                  })}
              </Blueheadinggrid>
            </Grid>
          </Grid>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
