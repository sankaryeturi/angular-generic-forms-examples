import React, { createContext, ReactNode, ReactElement, useState } from "react";
import { ClaimsService } from "./claimsServices";
import { CommonService } from "../../_services/commonServices";

interface ClaimsControllerProps {
  children: ReactNode;
}
interface ClaimsState {
  error: any;
  claimsList: any;
  claimsListError: any;
  statesList: any;
  statesListError: any;
  citiesList: any;
  citiesListError: any;
  propertyLossTypeList: any;
  propertyLossTypeListError: any;
  propertyLossCauseList: any;
  propertyLossCauseListError: any;
  submitClaimResponse: any;
  submitClaimResponseError: any;
}
interface ClaimsStateContext extends ClaimsState {
  readonly getClaimsList: (polucyNumber) => any;
  readonly getStates: () => any;
  readonly getCities: (stateCode) => any;
  readonly getPropertyLossType: () => any;
  readonly getPropertyLossCauseList: () => any;
  readonly submitClaim: (data) => any;
}
const initialState: ClaimsState = {
  error: null,
  claimsList: [],
  claimsListError: null,
  statesList: [],
  statesListError: [],
  citiesList: [],
  citiesListError: [],
  propertyLossTypeList: [],
  propertyLossTypeListError: null,
  propertyLossCauseList: [],
  propertyLossCauseListError: null,
  submitClaimResponse: null,
  submitClaimResponseError: null,
};
const initialContext: ClaimsStateContext = {
  ...initialState,
  getClaimsList: invalidContext,
  getStates: invalidContext,
  getCities: invalidContext,
  getPropertyLossType: invalidContext,
  getPropertyLossCauseList: invalidContext,
  submitClaim: invalidContext,
};

export const ClaimsContext = createContext(initialContext);

export function ClaimsController(props: ClaimsControllerProps): ReactElement {
  const [state, setState] = useState(initialState);
  /** get claims list */
  async function getClaimsList(inputReq): Promise<any> {
    try {
      const responseData: any = await ClaimsService.getClaimsHistory(inputReq);
      setState({ ...state, claimsList: responseData });
      return {
        ...initialState,
        claimsList: responseData.data?.claims,
      };
    } catch (error) {
      setState({ ...state, claimsListError: error });
      return { ...initialState, claimsListError: error };
    }
  }
  /** get states list */
  async function getStates(): Promise<any> {
    try {
      const responseData: any = await CommonService.getState();
      setState({ ...state, statesList: responseData });
      return {
        ...initialState,
        statesList: responseData.data?.states,
      };
    } catch (error) {
      setState({ ...state, statesListError: error });
      return { ...initialState, statesListError: error };
    }
  }
  /** get cities list */
  async function getCities(stateCode): Promise<any> {
    try {
      const responseData: any = await CommonService.getCities(stateCode);
      setState({ ...state, citiesList: responseData });
      return {
        ...initialState,
        citiesList: responseData.data?.cities,
      };
    } catch (error) {
      setState({ ...state, citiesListError: error });
      return { ...initialState, citiesListError: error };
    }
  }
  /** get PROPERTY LOSS TYPE list */
  async function getPropertyLossType(): Promise<any> {
    try {
      const responseData: any = await ClaimsService.getPropertyLossType();
      setState({
        ...state,
        propertyLossTypeList: responseData.data?.propertyLossTypes,
      });
      return {
        ...initialState,
        propertyLossTypeList: responseData.data?.propertyLossTypes,
      };
    } catch (error) {
      setState({ ...state, propertyLossTypeListError: error });
      return { ...initialState, propertyLossTypeListError: error };
    }
  }

  /** get PROPERTY LOSS TYPE list */
  async function getPropertyLossCauseList(): Promise<any> {
    try {
      const responseData: any = await ClaimsService.getPropertyLossCauseList();
      setState({
        ...state,
        propertyLossCauseList: responseData.data.lossCauses,
      });
      return {
        ...initialState,
        propertyLossCauseList: responseData.data?.lossCauses,
      };
    } catch (error) {
      setState({ ...state, propertyLossCauseListError: error });
      return { ...initialState, propertyLossCauseListError: error };
    }
  }

  /** submit claim */
  async function submitClaim(data): Promise<any> {
    try {
      const responseData: any = await ClaimsService.submitClaimInfo(data);
      setState({ ...state, submitClaimResponse: responseData.data });
      return {
        ...initialState,
        submitClaimResponse: responseData.data,
      };
    } catch (error) {
      setState({ ...state, submitClaimResponseError: error });
      return { ...initialState, submitClaimResponseError: error };
    }
  }

  const context = {
    ...state,
    getClaimsList,
    getStates,
    getCities,
    getPropertyLossType,
    getPropertyLossCauseList,
    submitClaim,
  };
  return (
    <ClaimsContext.Provider value={context}>
      {props.children}
    </ClaimsContext.Provider>
  );
}
function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a claimsController?");
}
