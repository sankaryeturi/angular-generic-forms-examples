/* eslint-disable */
import React, { ReactElement, useContext, useEffect, useState } from "react";
import {
  Appbodycontainer,
  Blueheadinggrid,
  SspformGroup,
  Sspbluebutton,
  Bluebutton,
  Darkbluebutton,
  Anchor,
  PopupBlock,
  ThemeIcon
} from "../../themes/styles";
import { ThemeContext } from "../../themes";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { LocalizationContext } from "../../locales";
import { 
  Grid, 
  Box, 
  Radio, 
  TextField, 
  Checkbox,
  RadioGroup,
  FormControlLabel,
  Modal } from "@material-ui/core";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { useSelector } from "react-redux";
import { ClaimsContext } from "./claimsController";
import InsuranceItemsComponent from "../dashboard/_components/insuranceItems";

interface InitialStateInterface {
  policies: any;
  selectPolicyNumber: any;
  phoneNumber: string;
  emailExist: string;
  differentPhoneNo: string;
  differentEmail: string;
  updatePhoneNoBlock: boolean;
  updateEmailBlock: boolean;
  locationOfLoss: string;
  statesList: any;
  stateName: string;
  stateCode: string;
  cityList: any;
  cityName: string;
  cityCode: string;
  lossDate: any;
  glassClaimBlock: boolean;
  glassClaim: string;
  policyType: string;
  whatHappened: any;
  causeOfDamage: string;
  autoEvent: any;
  vehicleInvolved: string;
  drivingVehicle: string;
  currentPolicyNumber: string;
  updatePhoneNoCheck: boolean;
  updateEmailNoCheck: boolean;
  propertyLossTypeList: any;
  propertyLossCauseList: any;
  homeDescription: string;
  successMessage: string;
  failMessage: string;
  alternatePhno: string;
  cancelPopup: boolean;
}
const initialState: InitialStateInterface = {
  policies: [],
  selectPolicyNumber: "",
  phoneNumber: "primary",
  emailExist: "exist",
  differentPhoneNo: "",
  differentEmail: "",
  updatePhoneNoBlock: false,
  updateEmailBlock: false,
  locationOfLoss: "",
  statesList: [],
  stateName: "",
  stateCode: "",
  cityList: [],
  cityName: "",
  cityCode: "",
  lossDate: "",
  glassClaimBlock: true,
  glassClaim: "false",
  policyType: "Auto",
  whatHappened: [],
  causeOfDamage: "",
  autoEvent: [],
  vehicleInvolved: "",
  drivingVehicle: "",
  currentPolicyNumber: "",
  updatePhoneNoCheck: false,
  updateEmailNoCheck: false,
  propertyLossTypeList: [],
  propertyLossCauseList: [],
  homeDescription: "",
  successMessage: "",
  failMessage: "",
  alternatePhno: "",
  cancelPopup: false
};

const formWizardState: any = {
  activeBlock: 0,
};

export default function SubmitClaimComponent(): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const [state, setState] = useState(initialState);
  const [statesList, setStatesList] = useState(initialState.statesList);
  const [citiesList, setCitiesList] = useState(initialState.cityList);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);
  const [policiesListInfo, setPoliciesListInfo] = useState(initialState.policies);
  const { getStates } = useContext(ClaimsContext);
  const { getCities } = useContext(ClaimsContext);
  const { submitClaim } = useContext(ClaimsContext);

  let policiesEmptyState = false;
  /** adding activeStatus to policies */
  let policiesList = policies.policis;
  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policiesEmptyState = true;
  }

  /** handle change for input fields */
  const handleChange = (e: any, field: any = undefined) => {
    
  };

  /** policy click fun */
  const policyTabClick = (policyIndex) => {
    let policyNo = "";
    let policyType = "";
    const policy: any = policiesListInfo.filter((policyData: any, i) => {
      if (policyIndex === i) {
        policyNo = policyData.policyNumber;
        policyType = policyData.policyType;
        policyData.activeStatus = true;
        // return policyData;
      } else {
        policyData.activeStatus = false;
      }
      return policyData;
    });
    if (policy.length !== 0) {
      const dynamicData = {
        ...state,
        selectPolicyNumber: policyNo,
        policyType: policyType,
      };
      if (policy[0].policyType === "Auto") {
        dynamicData.glassClaimBlock = true;
      } else {
        dynamicData.glassClaimBlock = false;
      }
      setState(dynamicData);
    }
  };

  useEffect(() => {
    try {
      let activePolicy = policiesList.filter((data, i) => {
        if (data.activeStatus === true) {
          return data;
        }
      });
      if (activePolicy.length === 0) {
        policiesList[0].activeStatus = true;
        setState({
          ...state,
          currentPolicyNumber: policiesList[0].policyNumber,
        });
      } else {
        setState({
          ...state,
          currentPolicyNumber: activePolicy[0].policyNumber,
        });
      }
      setPoliciesListInfo(policiesList);
      // Getting states list
      getStates().then((response) => {
        setStatesList(response.statesList);
      });
    } catch (error) {
      console.log("Error paymentInformation - useEffect", error);
    }
  }, [policiesEmptyState]);

  const submitClaimInfo = (e) => {
    console.log(e)
  };

  const cancelPopup = () => {
    setState({
      ...state,
      cancelPopup: !state.cancelPopup
    })
  }
  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle["label.claims"]}
            subTitle="File a claim"
            iconName="ssp-clipboardcheck-big-icon"
          />
          {/* ./END page title block */}
          {/* policies list */}
          <Grid container className="ssp-mb3 ssp-mt3">
            {policiesListInfo &&
              policiesListInfo.map((policyData, i) => {
                return (
                  <Grid item xs={2} key={i}>
                    <InsuranceItemsComponent
                      insuranceInfo={policyData}
                      ItemIndex={i}
                      policyTabClick={policyTabClick}
                      footerStatus="false"
                      xsSize="11"
                    />
                  </Grid>
                );
              })}
          </Grid>
          {/* ./ END policies list */}

          {/* Claim form */}
          <ValidatorForm
            onSubmit={(e) => submitClaimInfo(e)}
            autoComplete="off"
          >
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Blueheadinggrid theme={theme} className="ssp-mr0 min-height-auto">
                  <div className="heading ssp-p3">
                    <h3>&nbsp;</h3>
                  </div>
                  <div className="content ssp-p3">
                    <b>A claim has already been started for this policy.</b>
                    <Anchor className="ssp-blue underline bold text-left">Claim #123456</Anchor>
                    <Box mt={4} mb={6}>
                      <Bluebutton
                        className="ssp-mr3 ssp-px6"
                        type="button"
                        theme={theme}                
                      >
                        Start a new claim
                      </Bluebutton>
                      <Darkbluebutton className="ssp-px6" theme={theme}>
                        Call us about this claim
                      </Darkbluebutton>
                    </Box>
                  </div>
                </Blueheadinggrid>
              </Grid>
              <Grid item xs={12}>
                <Blueheadinggrid theme={theme} className="ssp-mr0 min-height-auto">
                  <div className="heading ssp-p3">
                    <h3>{bundle["button.contact"]}</h3>
                  </div>
                  <div className="content ssp-p3">
                    <Grid container>
                      <Grid sm={12} md={6}>
                        <Box width="75%">
                        <SspformGroup theme={theme} className="ssp-mt0">
                          <label>Best number to reach you regarding claim:</label>
                          <div className="ssp-mt2">
                            <Radio
                              checked={state.phoneNumber === "primary"}
                              onChange={(e) =>
                                handleChange(e, "phoneNumber")
                              }
                              value="primary"
                              color="primary"
                              name="primary"
                            />
                            <div className="ssp-inline-block heading-color">
                              904-999-1234
                            </div>
                          </div>
                          <div className="ssp-mt2">
                            <Radio
                              checked={state.phoneNumber === "secondary"}
                              onChange={(e) =>
                                handleChange(e, "phoneNumber")
                              }
                              value="secondary"
                              color="primary"
                              name="secondary"
                            />
                            <div className="ssp-inline-block">
                              <b>904-333-4444</b>
                            </div>
                          </div>
                        </SspformGroup>
                        <p>If you wish to use another phone number that is not associated with your account, please enter it here.</p>
                        <SspformGroup theme={theme} className="ssp-mt0">
                          <TextValidator
                            className="ssp-inputwhite"
                            name="alternatePhno"
                            value={state.alternatePhno}
                            placeholder="123-456-7890"
                            InputLabelProps={{
                              shrink: true,
                            }}
                            InputProps={{
                              readOnly: true,
                            }}
                          />
                        </SspformGroup>
                        <p>If you wish to update phone numbers associated with your account 
                          <Anchor href={undefined} className="ssp-blue underline bold ssp-inline-block"> click here</Anchor>. 
                          <b>Be aware that you will have to restart your claim once you have updated your phone number(s).</b>
                        </p>
                        </Box>
                      </Grid>
                      <Grid container sm={12} md={6}>
                        <Box width="75%">
                          <SspformGroup theme={theme} className="ssp-mt0 ssp-mb0">
                            <label>Email address for claims communications:</label>
                            <div className="ssp-mt2">
                              <Radio
                                checked={state.phoneNumber === "primary"}
                                onChange={(e) =>
                                  handleChange(e, "phoneNumber")
                                }
                                value="primary"
                                color="primary"
                                name="primary"
                              />
                              <div className="ssp-inline-block heading-color">
                                john.smith@gmail.com
                              </div>
                            </div>
                          </SspformGroup>
                          <p>If you wish to use another email address that is not associated with your account, please enter it here.</p>
                          <SspformGroup theme={theme} className="ssp-mt0 ssp-mb0">
                            <TextValidator
                              className="ssp-inputwhite"                              
                              name="alternatePhno"
                              value={state.alternatePhno}
                              placeholder="123-456-7890"
                              InputLabelProps={{
                                shrink: true,
                              }}
                              InputProps={{
                                readOnly: true,
                              }}
                            />
                          </SspformGroup>
                          <p>If you wish to update the email address associated with your account
                            <Anchor href={undefined} className="ssp-blue underline bold ssp-inline-block"> click here</Anchor>. 
                            <b>Be aware that you will have to restart your claim once you have updated your email address.</b>
                          </p>
                        </Box>                        
                      </Grid>
                    </Grid>
                  </div>
                </Blueheadinggrid>
              </Grid>
              <Grid item xs={12} md={6}>
                <Blueheadinggrid theme={theme} className="ssp-mr0">
                  <div className="heading ssp-p3">
                    <h3>{bundle?.claims?.dateOfLoss}</h3>
                  </div>
                  <div className="content ssp-p3">
                    <label>Enter the date of loss:</label>
                    <div>
                      <SspformGroup
                          theme={theme}
                          className="input50 month"
                        >
                          <TextValidator
                            fullWidth
                            onChange={(e) =>
                              handleChange(
                                e,
                                "filterToMonth"
                              )
                            }
                            name="filterToMonth"
                            value=""
                            placeholder="MM"
                            type="number"
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                      </SspformGroup>
                      <SspformGroup
                          theme={theme}
                          className="input50 day"
                      >
                          <TextValidator
                            
                            onChange={(e) =>
                              handleChange(
                                e,
                                "filterToDay"
                              )
                            }
                            name="filterToDay"
                            value=""
                            placeholder="DD"
                            type="text"
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                      </SspformGroup>
                      <SspformGroup
                          theme={theme}
                          className="input50 year"
                      >
                        <TextValidator                          
                          onChange={(e) =>
                            handleChange(
                              e,
                              "filterToYear"
                            )
                          }
                          name="filterToYear"
                          value=""
                          placeholder="YYYY"
                          type="number"
                          InputLabelProps={{
                            shrink: true,
                          }}
                        />
                      </SspformGroup>
                    </div>
                  </div>
                </Blueheadinggrid>
              </Grid>
              <Grid item xs={12} md={6}>
                <Blueheadinggrid theme={theme} className="ssp-mr0">
                  <div className="heading ssp-p3">
                    <h3>{bundle?.claims?.locationOfLoss}</h3>
                  </div>
                  <div className="content ssp-p3">
                    <div className="MuiGrid-grid-xs-12 MuiGrid-grid-lg-6">
                      <SspformGroup
                        theme={theme}
                        className="input50 ssp-mb2"
                      >
                        <TextValidator
                          label="Street Address - optional"     
                          fullWidth                   
                          onChange={(e) => handleChange(e, "email")}
                          name="email"
                          type="text"
                          value=""
                          validators={["required", "isEmail"]}
                          errorMessages={[
                            bundle?.changeEmailAddress?.newEmailError,
                            bundle?.validation?.emailPattern,
                          ]}
                          InputLabelProps={{
                            shrink: true,
                          }}
                        />
                      </SspformGroup>
                      {/* state field */}
                      <SspformGroup theme={theme}>
                        <label>State - required</label>
                        <select
                          value={state.stateCode}
                          onChange={(e) => handleChange(e, "statesList")}
                        >
                          <option>-- Select State --</option>
                          {statesList &&
                            statesList.map((data, i) => (
                              <option key={i} value={data.code}>
                                {data.description}
                              </option>
                            ))}
                        </select>
                      </SspformGroup>
                      {/* City field */}
                      <SspformGroup theme={theme}>
                        <label>City - required</label>
                        <select
                          value={state.cityCode}
                          onChange={(e) => handleChange(e, "cityCode")}
                        >
                          <option>-- Select City --</option>
                          {citiesList &&
                            citiesList.map((cityData, j) => (
                              <option key={j} value={cityData.code}>
                                {cityData.description}
                              </option>
                            ))}
                        </select>
                      </SspformGroup>
                    </div>
                  </div>
                </Blueheadinggrid>
              </Grid>            
            </Grid>
            {/* Action buttons */}
            <Grid container alignItems="center" justify="center" direction="column">
              <Grid item xs={12}>
                <Box mt={4}>
                  <Bluebutton
                    className="ssp-mr3 ssp-px6"
                    type="button"
                    theme={theme}                
                  >
                    {bundle?.button?.prev}
                  </Bluebutton>
                  <Darkbluebutton className="ssp-px6" theme={theme}>
                    {bundle?.button?.next}
                  </Darkbluebutton>
                  <Box component="div" mt={3}>
                    <Anchor onClick={cancelPopup} className="ssp-blue underline bold">Cancel Claim</Anchor>
                  </Box>
                </Box>              
              </Grid>
            </Grid>
          </ValidatorForm>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
      {/* guidence popup */}
      <Modal
          open={state.cancelPopup}
          onClose={cancelPopup}
          aria-labelledby="simple-modal-title"
          aria-describedby="simple-modal-description"
        >
          <PopupBlock theme={theme} className="guidanceCheckPopup">
            <Box mt={4}>
              <Box width="60%" mx="auto">
                <p>By canceling this claim, you will be directed back to the dashboard and you will have start over to initiate a claim.</p>
              </Box>
              <Box mt={4} width="75%" mx="auto" textAlign="center">
                <Bluebutton
                  className="ssp-mr3 ssp-px6"
                  type="button"
                  theme={theme}                
                >
                  Don’t cancel this claim
                </Bluebutton>
                <Darkbluebutton className="ssp-px6" theme={theme} onClick={cancelPopup}>
                  Cancel claim
                </Darkbluebutton>
              </Box>
            </Box>
          </PopupBlock>
        </Modal>
    </div>
  );
}
