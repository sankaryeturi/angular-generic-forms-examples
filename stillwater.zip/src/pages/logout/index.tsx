import React, { ReactElement, useEffect } from "react";
import { useHistory } from "react-router-dom";

export default function LogoutComponent(): ReactElement {
  const history = useHistory();
  useEffect(() => {
    localStorage.removeItem("isAuthenticated");
    history.push("/login");
  });
  return <></>;
}
