import { URL } from "../../config/constants";
import { CommonService } from "../../_services/commonServices";

export class EdocService {
  public static async getEdocsList(inputData): Promise<[]> {
    const url = URL.GET_EDOCS_LIST;
    const { data } = await CommonService.request("post", url, inputData);
    return data;
  }
}
