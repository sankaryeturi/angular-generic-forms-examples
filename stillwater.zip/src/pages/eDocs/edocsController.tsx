import React, { ReactElement, ReactNode, useState, createContext } from "react";
import { EdocService } from "./edocsServices";

interface EdocsControllerProps {
  children: ReactNode;
}
interface EdocsState {
  docsListResponse: any;
  error: any;
}
interface EdocsStateContext extends EdocsState {
  readonly getEdocsList: (policyNumber) => any;
}
const initialState: EdocsState = {
  docsListResponse: null,
  error: null,
};
const initialContext: EdocsStateContext = {
  ...initialState,
  getEdocsList: invalidContext,
};
export const EdocsContext = createContext(initialContext);
export function EdocsController(props: EdocsControllerProps): ReactElement {
  const [state, setState] = useState(initialState);
  async function getEdocsList(inputData): Promise<any> {
    try {
      const responseData = await EdocService.getEdocsList(inputData);
      setState({ ...state, docsListResponse: responseData, error: null });
      return { ...initialState, docsListResponse: responseData, error: null };
    } catch (error) {
      if (error?.errors) {
        setState({ ...initialState, error: error?.errors[0]?.errorDescription });
      }
      throw error;
    }
  }
  const context = {
    ...state,
    getEdocsList,
  };
  return (
    <EdocsContext.Provider value={context}>
      {props.children}
    </EdocsContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a edocsController?");
}
