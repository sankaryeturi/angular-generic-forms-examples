import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  Darkblueheadingh3,
  SspformGroup,
  Bluebutton,
  Darkbluebutton,
  Anchor,
  ThemeIcon,
  ErrorMessage
} from "../../themes/styles";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { Grid } from "@material-ui/core";
import { EdocsContext } from "./edocsController";
// initial state
const initialState = {
  policyNumber: "",
  formSubmit: false,
  docsList: [],
};

export default function Edocs(): ReactElement {
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();
  const { getEdocsList, error } = useContext(EdocsContext);

  const formSubmit = (e) => {
    const inputData = {
      policyNumber: state.policyNumber,
    };
    getEdocsList(inputData)
      .then((response) => {
        // console.log("edocs", response.docsListResponse?.data[0]?.displayDocumentMap);
        const eDocsList = response.docsListResponse?.data?.displayDocumentMap;
        const keys = Object.keys(eDocsList);
        const mainKey = keys[0];
        console.log(
          "edocs",
          response.docsListResponse?.data?.displayDocumentMap[mainKey]
        );
        setState({
          ...state,
          formSubmit: true,
          docsList:
          response.docsListResponse?.data?.displayDocumentMap[mainKey],
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleChange = (e: any, field: any): void => {
    const inputVal = e.target.value;
    setState({
      ...state,
      [field]: inputVal,
    });
  };
  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          <Darkblueheadingh3 theme={theme}>
            {bundle.heading?.edocs}
          </Darkblueheadingh3>

          {state.formSubmit === false && (
            <>
              <p className="ssp-my1">{bundle?.eDocs?.enterPolicyNo}</p>
              <ValidatorForm onSubmit={(e) => formSubmit(e)} autoComplete="off">
                <Grid container className="ssp-mt2">
                  <Grid item xs={12} md={5} lg={4}>
                    <SspformGroup
                      theme={theme}
                      className="gray input50 ssp-mb2"
                    >
                      <TextValidator
                        label={bundle?.label?.policyNumber}
                        fullWidth
                        onChange={(e) => handleChange(e, "policyNumber")}
                        name="policyNumber"
                        type="text"
                        value={state.policyNumber}
                        validators={["required"]}
                        errorMessages={[bundle?.validation?.policyNoRequired]}
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                    </SspformGroup>
                    {error && (
                      <ErrorMessage
                        className="orange ssp-mt2 ssp-inline-block"
                        theme={theme}
                      >
                        <b>{error}</b>
                      </ErrorMessage>
                    )}
                    <div className="ssp-align-right ssp-mt4">
                      <Bluebutton
                        className="ssp-px6 ssp-mb3 ssp-mr3"
                        type="button"
                        theme={theme}
                        onClick={() => navigation("login")}
                      >
                        {bundle["button.cancel"]}
                      </Bluebutton>
                      <Darkbluebutton className={`ssp-px6`} theme={theme}>
                        {bundle.button?.submit}
                      </Darkbluebutton>
                    </div>
                  </Grid>
                </Grid>
              </ValidatorForm>
            </>
          )}

          {state.formSubmit === true && (
            <>
              <p>
                <b>{bundle.label?.policyNumber}:</b> {state.policyNumber}
              </p>
              <ul>
                {(state.docsList) && state.docsList.map((data: any, i) => (
                  <li className="ssp-pb3" key={i}>
                    <Anchor
                      href={data.externalDisplayLink}
                      target="_blank"
                      theme={theme}
                      className="text-left dark-blue bold underline"
                    >
                      <ThemeIcon className="file-pdf-blue-icon bg-very-small"></ThemeIcon>{" "}
                      {data?.description} - Lorem ipsum dolor sit amet
                    </Anchor>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
