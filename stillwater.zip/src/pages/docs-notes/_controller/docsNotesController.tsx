import React, { ReactElement, ReactNode, useState, createContext } from "react";
import { DocsNotesService } from "../_services/docsNotesServices";

interface DocsNotesControllerProps {
  children: ReactNode;
}

interface DocsNotesState {
  docsNotesError: any;
  docsListResponse: any;
}

interface DocsNotesStateContext extends DocsNotesState {
  readonly getDocsList: (policyNumber) => any;
}

const initialState: DocsNotesState = {
  docsNotesError: null,
  docsListResponse: null,
};

const initialContext: DocsNotesStateContext = {
  ...initialState,
  getDocsList: invalidContext,
};

export const DocsNotesContext = createContext(initialContext);

export function DocsNotesController(
  props: DocsNotesControllerProps
): ReactElement {
  const [state, setState] = useState(initialState);
  async function getDocsList(policyNumber): Promise<any> {
    try {
      const responseData = await DocsNotesService.getDocsList(policyNumber);
      setState({
        ...state,
        docsListResponse: responseData,
        docsNotesError: null,
      });
      return {
        ...initialState,
        docsListResponse: responseData,
        docsNotesError: null,
      };
    } catch (error) {
      if (error?.errors) {
        setState({
          ...initialState,
          docsNotesError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }

  const context = {
    ...state,
    getDocsList,
  };

  return (
    <DocsNotesContext.Provider value={context}>
      {props.children}
    </DocsNotesContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a docsNotesController?");
}
