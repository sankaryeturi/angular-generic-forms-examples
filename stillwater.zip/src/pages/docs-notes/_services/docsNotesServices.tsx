import { URL } from "../../../config/constants";
import { CommonService } from "../../../_services/commonServices";

export class DocsNotesService {
  /**
   * get docs list
   */
  public static async getDocsList(policyNumber): Promise<[]> {
    const url = URL.GET_POLICY_DOCS;
    const loginToken = localStorage.getItem("authorizationToken");
    const inputReq = {
      policyNumber: policyNumber,
    };
    const { data } = await CommonService.request(
      "post",
      url,
      inputReq,
      loginToken
    );
    return data;
  }
}
