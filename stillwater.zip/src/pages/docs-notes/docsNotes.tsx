/* eslint-disable */
import React, { ReactElement, useContext, useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useParams } from "react-router";
import Slider from "react-slick";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import { updatePolicies } from "../../_actions";
import {
  Appbodycontainer,
  Blueheadinggrid,
  ThemeIcon,
  CarouselSlider,
  SspformGroup,
  BlueRibbon,
  Anchor,
  ErrorMessage,
} from "../../themes/styles";
import PageTitleComponent from "../../shared-components/page-title-block/indexComponent";
import { Grid, Hidden } from "@material-ui/core";
import InsuranceItemsComponent from "../dashboard/_components/insuranceItems";
import PolicyListDropdownComponent from "../../shared-components/policy-list-dropdown/policy-list-dropdown";
import { InputLabel, Select, MenuItem } from "@material-ui/core";
import { DocsNotesContext } from "./_controller/docsNotesController";

interface InitialStateInterface {
  policies: any;
  docsList: any;
}
const initialState: InitialStateInterface = {
  policies: [],
  docsList: [],
};
export default function DocsNotes(): ReactElement {
  const urlParm: any = useParams();
  const dispatch = useDispatch();
  const [state, setState] = useState(initialState);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const policies = useSelector((storeState: any) => storeState.policiesReducer);
  const { getDocsList, docsNotesError } = useContext(DocsNotesContext);

  let policyEmptyState = false;
  /** adding activeStatus to policies */
  let policiesList = policies.policis;
  if (policiesList === undefined || policiesList.length === 0) {
    policiesList = [];
  } else {
    policyEmptyState = true;
    if (state.policies.length == 0) {
      policiesList = policiesList.map((data, i) => {
        if (data.policyNumber === urlParm.policyNumber) {
          data.activeStatus = true;
        } else {
          data.activeStatus = false;
        }
        return data;
      });
    }
  }

  useEffect(() => {
    getDocsList(urlParm.policyNumber).then((response) => {
      setState({
        ...state,
        docsList: response?.docsListResponse?.data,
      });
      console.log("docs", response?.docsListResponse?.data);
    });
  }, []);

  /** slider properties */
  const slickSliderSettings = {
    dots: false,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    infinite: false,
  };

  /** policy tab click function */
  const policyTabClick = (policyIndex: any) => {
    /** active state change */
    let policyNo = "";
    const policy = state.policies.map((policyData: any, i) => {
      if (policyIndex === i) {
        policyData.activeStatus = true;
        policyNo = policyData.policyNumber;
      } else {
        policyData.activeStatus = false;
      }
      return policyData;
    });
    dispatch(updatePolicies(policy));
    // policyDetailsInfo(policyNo, policy);
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          {/* page title block */}
          <PageTitleComponent
            pageTitle={bundle?.heading?.docsNotes}
            icon="wallet-blue-big.svg"
            iconName="ssp-walletblue-big-icon"
          />
          {/* ./END page title block */}
          {/* Policies list */}
          <div className="ssp-mt3">
            <Hidden smDown>
              {/* Slider */}
              <CarouselSlider theme={theme} className="policy-slider">
                <Slider {...slickSliderSettings}>
                  {policiesList &&
                    policiesList.map((policyData, i) => {
                      return (
                        <InsuranceItemsComponent
                          insuranceInfo={policyData}
                          ItemIndex={i}
                          policyTabClick={policyTabClick}
                          footerStatus="false"
                          xsSize={11}
                          key={i}
                        />
                      );
                    })}
                </Slider>
              </CarouselSlider>
            </Hidden>

            {/* policy list for responsive view */}
            <Hidden mdUp>
              <form>
                <PolicyListDropdownComponent
                  policies={policiesList}
                  dynamicClass="select-field gray"
                  policyTabClick={policyTabClick}
                ></PolicyListDropdownComponent>
              </form>
            </Hidden>
          </div>

          <div className="clearfix">
            <BlueRibbon theme={theme} className="ssp-align-center ssp-pullLeft">
              <div className="number">5</div>
              <div>YEARS</div>
            </BlueRibbon>
            <div className="ssp-pullLeft MuiGrid-grid-xs-5 ssp-pl4 ssp-pt4">
              Thank you Jay for being a loyal Stillwater customer for 5 years.
              We appreciate your business. Don't hesitate to give us a review
              via the <a href="#">Better Business Bureau.</a>
            </div>
          </div>

          <div className="ssp-mt3">
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <SspformGroup
                  theme={theme}
                  className={`input50 MuiGrid-grid-xs-8`}
                >
                  <InputLabel shrink>Policy Coverage Term</InputLabel>
                  <Select className={`gray select-field`} value="">
                    <MenuItem value=""> <ThemeIcon className="icon home-icon"></ThemeIcon>
                      Current Term - 05/01/2019 - 05/01/2020
                    </MenuItem>
                  </Select>
                </SspformGroup>
              </Grid>

              <Grid item xs={6} className="ssp-dflex-centerleft">
                <p>
                  <Anchor
                    theme={theme}
                    href="#"
                    className="dark-blue bold underline"
                  >
                    View and download Letter of Experience for this policy
                  </Anchor>
                </p>
              </Grid>
            </Grid>
          </div>

          <div>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Blueheadinggrid theme={theme} className="ssp-mr0">
                  <div className="heading ssp-p3 ssp-pl4">
                    <h3>DOCUMENTS</h3>
                  </div>
                  <div className="content h-250 ssp-p3 ssp-pl4">
                    <ul>
                      {docsNotesError && (
                        <li className="ssp-pb2">
                          <ErrorMessage
                            className="orange ssp-mt2 ssp-inline-block"
                            theme={theme}
                          >
                            <b>{docsNotesError}</b>
                          </ErrorMessage>
                        </li>
                      )}
                      {state.docsList &&
                        state.docsList.map((data, i) => (
                          <li className="ssp-pb2" key={i}>
                            <Anchor
                              href={data?.external_display}
                              target="_blank"
                              theme={theme}
                              className="text-left dark-blue bold underline"
                            >
                              <ThemeIcon className="file-pdf-blue-icon bg-very-small"></ThemeIcon>{" "}
                              {data?.description}
                            </Anchor>
                          </li>
                        ))}
                    </ul>
                  </div>
                </Blueheadinggrid>
              </Grid>
              <Grid item xs={6}>
                <Blueheadinggrid theme={theme} className="ssp-mr0">
                  <div className="heading ssp-p3 ssp-pl4">
                    <h3>NOTES</h3>
                  </div>
                  <div className="content h-250 ssp-p3 ssp-pl4">
                    <ul>
                      <li className="ssp-pb2">
                        <span>
                          <b>Payment Due</b> - Auto 123456789 -{" "}
                        </span>
                        <Anchor
                          href="#"
                          target="_blank"
                          theme={theme}
                          className="text-left dark-blue bold underline ssp-inline-block"
                        >
                          Make Payment
                        </Anchor>
                      </li>
                      <li className="ssp-pb2">
                        <span>
                          <b>Payment Submitted 6/10/20</b> -{" "}
                        </span>
                        <Anchor
                          href="#"
                          target="_blank"
                          theme={theme}
                          className="text-left dark-blue bold underline ssp-inline-block"
                        >
                          Go to Payments
                        </Anchor>
                      </li>
                      <li className="ssp-pb2">
                        <span>
                          <b>Payment Submitted 5/08/20</b> -{" "}
                        </span>
                        <Anchor
                          href="#"
                          target="_blank"
                          theme={theme}
                          className="text-left dark-blue bold underline ssp-inline-block"
                        >
                          Go to Payments
                        </Anchor>
                      </li>
                      <li className="ssp-pb2">
                        <b>Endorsement Document added</b> 04/12/20{" "}
                      </li>
                      <li className="ssp-pb2">
                        <b>Renewal Offer Document added</b> 04/01/20
                      </li>
                    </ul>
                  </div>
                </Blueheadinggrid>
              </Grid>
            </Grid>
          </div>
        </div>
        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
