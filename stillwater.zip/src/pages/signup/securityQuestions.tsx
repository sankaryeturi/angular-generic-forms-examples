import React, { ReactElement, useContext, useState, useEffect } from "react";
import { PacificBlueh3 } from "../../themes/styles";
import { SignupContext } from "./_controllers/signupController";
import SecurityQuestionsComponent from "../../shared-components/securityQuestions/securityQuestionsComponent";
import { Grid } from "@material-ui/core";

export interface InitialState {
  questionsList: any;
  userAttempts: any;
}
const initialState: InitialState = {
  questionsList: [],
  userAttempts: [],
};
export default function SecurityQuestions(props): ReactElement {
  const [state, setState] = useState(initialState);
  const { getSecurityQuestions } = useContext(SignupContext);

  useEffect(() => {
    getSecurityQuestions().then((response) => {
      if (response.questionsList) {
        let questionsList = response?.questionsList?.data?.questions;
        questionsList = questionsList.map((data) => {
          data.showPasswordField = false;
          return data;
        });
        if (questionsList.length !== 0) {
          setState({
            ...state,
            questionsList: questionsList,
          });
        }
      } else {
        setState({
          ...state,
          questionsList: 0,
        });
      }
    });
  }, []);
  // updating the question to state
  const handleQuestionChange = (value, questionIndex) => {
    const obj = {
      question: value.text,
      index: questionIndex,
      questionID: value.id,
      answer: "",
    };
    const userAttempts = state.userAttempts;
    const filter = userAttempts.filter((data, i) => {
      if (data.index === questionIndex) {
        return data;
      }
    });
    if (filter.length === 0) {
      userAttempts.push(obj);
    } else {
      const position = userAttempts.findIndex((x) => x.index === questionIndex);
      userAttempts[position].question = obj.question;
      userAttempts[position].index = obj.index;
    }
    setState({
      ...state,
      userAttempts: userAttempts,
    });
  };
  // updating the answer to state
  const handleAnswer = (value, answerIndex) => {
    const obj = {
      question: "",
      index: answerIndex,
      answer: value,
    };
    const userAttempts = state.userAttempts;
    const filter = userAttempts.filter((data, i) => {
      if (data.index === answerIndex) {
        return data;
      }
    });
    if (filter.length === 0) {
      userAttempts.push(obj);
    } else {
      const position = userAttempts.findIndex((x) => x.index === answerIndex);
      userAttempts[position].answer = obj.answer;
      userAttempts[position].index = obj.index;
    }
    // updating the security question to parent component
    props.updateSecurityQuestions(userAttempts);
    //updaing the state
    setState({
      ...state,
      userAttempts: userAttempts,
    });
  };

  return (
    <>
      <PacificBlueh3 theme={props.theme}>
        {props.bundle["heading.securityQuestions"]}
      </PacificBlueh3>
      <Grid container>
        <Grid item xs={12} md={7} lg={5}>
          {/* security questions component */}
          <SecurityQuestionsComponent
            theme={props.theme}
            bundle={props.bundle}
            inputClass="gray"
            questionsList={state.questionsList}
            handleQuestionChange={handleQuestionChange}
            handleAnswer={handleAnswer}
            userAttempts={state.userAttempts}
            iconState="hide"
          />
        </Grid>
      </Grid>
    </>
  );
}
