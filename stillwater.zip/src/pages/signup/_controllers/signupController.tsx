import React, { ReactElement, ReactNode, useState, createContext } from "react";
import { SignupService } from "../_services/signupServices";

interface SignupControllerProps {
  children: ReactNode;
}
interface SignupState {
  signUpError: any;
  policyCheckResponse: any;
  emailUseridResponse: any;
  questionsList: any;
  termsConditionsResponse: any;
  userAddResponse: any;
}
interface SignupStateContext extends SignupState {
  readonly checkPolicyInfo: (inputRequest: any) => any;
  readonly emailUseridRegistration: (inputRequest: any) => any;
  readonly getSecurityQuestions: () => any;
  readonly getTermsConditionsInfo: () => any;
  readonly userAdd: (inputRequest: any) => any;
}
const initialState: SignupState = {
  signUpError: null,
  policyCheckResponse: null,
  emailUseridResponse: null,
  questionsList: null,
  termsConditionsResponse: null,
  userAddResponse: null,
};
const initialContext: SignupStateContext = {
  ...initialState,
  checkPolicyInfo: invalidContext,
  emailUseridRegistration: invalidContext,
  getSecurityQuestions: invalidContext,
  getTermsConditionsInfo: invalidContext,
  userAdd: invalidContext,
};
export const SignupContext = createContext(initialContext);
export function SignupController(props: SignupControllerProps): ReactElement {
  const [state, setState] = useState(initialState);
  // checking policy information
  async function checkPolicyInfo(inputRequest): Promise<any> {
    try {
      const responseData = await SignupService.checkPolicyInfo(inputRequest);
      setState({
        ...state,
        policyCheckResponse: responseData,
        signUpError: null,
      });
      return {
        ...state,
        policyCheckResponse: responseData,
        signUpError: null,
      };
    } catch (error) {
      if (error.errors) {
        setState({
          ...initialState,
          signUpError: error.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  // email & user id registraion
  async function emailUseridRegistration(inputRequest): Promise<any> {
    try {
      const responseData = await SignupService.emailUseridRegistration(
        inputRequest
      );
      setState({
        ...state,
        emailUseridResponse: responseData,
        signUpError: null,
      });
      return {
        ...initialState,
        emailUseridResponse: responseData,
        signUpError: null,
      };
    } catch (error) {
      if (error.errors) {
        setState({
          ...initialState,
          signUpError: error.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  // get security questions
  async function getSecurityQuestions(): Promise<any> {
    try {
      const responseData = await SignupService.getSecurityQuestions();
      setState({ ...state, questionsList: responseData });
      return { ...initialState, questionsList: responseData };
    } catch (error) {
      if (error.errors) {
        setState({
          ...initialState,
          signUpError: error?.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }
  // terms and conditions request
  async function getTermsConditionsInfo(): Promise<any> {
    try {
      const responseData = await SignupService.getTermsConditionsInfo();
      setState({ ...state, termsConditionsResponse: responseData });
      return { ...initialState, termsConditionsResponse: responseData };
    } catch (error) {
      if (error.errors) {
        setState({
          ...initialState,
          signUpError: error.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }

  async function userAdd(inputRequest): Promise<any> {
    try {
      const responseData = await SignupService.userAdd(inputRequest);
      setState({ ...state, userAddResponse: responseData });
      return { ...initialState, userAddResponse: responseData };
    } catch (error) {
      if (error.errors) {
        setState({
          ...initialState,
          signUpError: error.errors[0]?.errorDescription,
        });
      }
      throw error;
    }
  }

  const context = {
    ...state,
    checkPolicyInfo,
    emailUseridRegistration,
    getSecurityQuestions,
    getTermsConditionsInfo,
    userAdd,
  };
  return (
    <SignupContext.Provider value={context}>
      {props.children}
    </SignupContext.Provider>
  );
}

function invalidContext(): Promise<void> {
  throw new Error("no conext found, did you use a settingsController?");
}
