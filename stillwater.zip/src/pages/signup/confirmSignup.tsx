import React, { ReactElement, useContext } from "react";
import { useHistory } from "react-router-dom";
import { Grid } from "@material-ui/core";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  PacificBlueh3,
  Darkbluebutton,
  PacificBlueborder,
} from "../../themes/styles";

export default function ConfirmSignup(props): ReactElement {
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const history = useHistory();

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  return (
    <>
      <PacificBlueh3 theme={theme}>
        {bundle["heading.confirmation"]}
      </PacificBlueh3>
      <Grid container>
        <Grid item xs={12} md={7} lg={5}>
          <p>{bundle["confirmSignup.pContent1"]}</p>
          <p>{bundle["confirmSignup.pContent2"]}</p>

          <PacificBlueborder className="ssp-mb3 ssp-pl3" theme={theme}>
            <p>
              <b className="ssp-pr4">{bundle["label.email"]}:</b>{" "}
              {props?.signupInfo?.email}
            </p>
            <p>
              <b className="ssp-pr4">{bundle["label.userid"]}:</b>{" "}
              {props?.signupInfo?.userId}
            </p>
          </PacificBlueborder>

          <div className="ssp-mt4 ssp-align-right">
            <Darkbluebutton
              className="w-20"
              theme={theme}
              onClick={() => navigation("login")}
            >
              {bundle["label.login"]}
            </Darkbluebutton>
          </div>
        </Grid>
      </Grid>
    </>
  );
}
