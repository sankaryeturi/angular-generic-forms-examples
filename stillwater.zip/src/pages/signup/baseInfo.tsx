/* eslint-disable */
import React, { ReactElement, useContext, useState, useEffect } from "react";
import { TextValidator } from "react-material-ui-form-validator";
import { Grid } from "@material-ui/core";
import { SspformGroup } from "../../themes/styles";
import { ValidationService } from "../../_services/validation";

const initialState = {
  disableField: true,
  dobValidationMessage: "",
  dobValidationStatus: false,
  formSubmit: false,
};

export default function BaseInfo(props): ReactElement {
  const [state, setState] = useState(initialState);

  // changing input field value
  const handleChange = (e: any, field: any): void => {
    props.handleChange(e.target.value, field);
  };

  /** date of birth validation */
  const dobValidation = (): void => {
    if (
      props.formValues?.dobDay &&
      props.formValues?.dobMonth &&
      props.formValues?.dobYear
    ) {
      const response = ValidationService.dobValidation(
        props.formValues?.dobDay,
        props.formValues?.dobMonth,
        props.formValues?.dobYear
      );
      if (response === false) {
        setState({
          ...state,
          dobValidationStatus: false,
          dobValidationMessage: props.bundle["validation.dobValidation"],
        });
      } else {
        setState({
          ...state,
          dobValidationStatus: true,
          dobValidationMessage: "",
        });
      }
    }
  };

  return (
    <>
      <p>{props.bundle?.signup?.securityContext}</p>
      <label className="dark-label">{props?.bundle?.label?.dob}</label>
      <Grid container>
        <Grid item xs={12} md={5}>
          <Grid container className="ssp-mt2" spacing={1}>
            <Grid item xs={4} md={2} className="ssp-pb0">
              <SspformGroup theme={props.theme} className="gray input50">
                <TextValidator
                  fullWidth
                  onChange={(e) => handleChange(e, "dobMonth")}
                  onKeyUp={() => dobValidation()}
                  name="dobMonth"
                  value={props.formValues?.dobMonth}
                  placeholder="MM"
                  type="number"
                  validators={["required"]}
                  errorMessages={[""]}
                  onInput={(e) => {
                    e.target.value = Math.max(0, parseInt(e.target.value))
                      .toString()
                      .slice(0, 2);
                  }}
                />
              </SspformGroup>
            </Grid>
            <Grid item xs={4} md={2} className="ssp-pb0">
              <SspformGroup theme={props.theme} className="gray input50">
                <TextValidator
                  fullWidth
                  onChange={(e) => handleChange(e, "dobDay")}
                  onKeyUp={() => dobValidation()}
                  name="dobDay"
                  value={props.formValues?.dobDay}
                  placeholder="DD"
                  type="number"
                  validators={["required"]}
                  errorMessages={[""]}
                  onInput={(e) => {
                    e.target.value = Math.max(0, parseInt(e.target.value))
                      .toString()
                      .slice(0, 2);
                  }}
                />
              </SspformGroup>
            </Grid>
            <Grid item xs={4} md={2} className="ssp-pb0">
              <SspformGroup theme={props.theme} className="gray input50">
                <TextValidator
                  fullWidth
                  onChange={(e) => handleChange(e, "dobYear")}
                  onKeyUp={() => dobValidation()}
                  name="dobYear"
                  value={props.formValues?.dobYear}
                  placeholder="YYYY"
                  type="number"
                  validators={["required"]}
                  errorMessages={[""]}
                  onInput={(e) => {
                    e.target.value = Math.max(0, parseInt(e.target.value))
                      .toString()
                      .slice(0, 4);
                  }}
                />
              </SspformGroup>
            </Grid>
            <Grid item xs={12} className="ssp-pt0">
              <span className="ssp-error">{state.dobValidationMessage}</span>
            </Grid>
          </Grid>

          <Grid container className="ssp-mt2">
            <Grid item xs={12} md={9} lg={8}>
              <SspformGroup theme={props.theme} className="gray input50">
                <TextValidator
                  label={props.bundle?.label?.policyNumber}
                  type="text"
                  name="policyNumber"
                  fullWidth
                  onChange={(e) => handleChange(e, "policyNumber")}
                  value={props.formValues?.policyNumber}
                  validators={["required"]}
                  errorMessages={[props.bundle?.validation?.policyNoRequired]}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </SspformGroup>
            </Grid>
          </Grid>

          <Grid container className="ssp-mt2">
            <Grid item xs={12} md={5} lg={4}>
              <SspformGroup theme={props.theme} className="gray input50">
                <TextValidator
                  label={props.bundle?.signup?.zipcodeLabel}
                  fullWidth
                  onChange={(e) => handleChange(e, "zipCode")}
                  name="zipCode"
                  type="text"
                  value={props.formValues?.zipCode}
                  validators={["required", "maxStringLength:5"]}
                  errorMessages={[props.bundle?.signup?.zipcodeError, props.bundle?.signup?.zipcodeLength]}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </SspformGroup>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
}
