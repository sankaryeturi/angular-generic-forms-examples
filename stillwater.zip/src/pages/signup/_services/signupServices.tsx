import { URL } from "../../../config/constants";
import { CommonService } from "../../../_services/commonServices";

export class SignupService {
  //check policy ingo
  public static async checkPolicyInfo(inputRequest) {
    const url = URL.SIGNUP_POLICY_INFO_CHECK;
    const { data } = await CommonService.request("post", url, inputRequest);
    return data;
  }
  // email & user id registraion
  public static async emailUseridRegistration(inputRequest) {
    const url = URL.SIGNUP_EMAIL_USERID_CHECK;
    const { data } = await CommonService.request("post", url, inputRequest);
    return data;
  }
  // get the security questions
  public static async getSecurityQuestions() {
    const url = URL.GET_QUESTOINS;
    const { data } = await CommonService.request("get", url);
    return data;
  }
  // get the terms and condions request
  public static async getTermsConditionsInfo() {
    const url = URL.TERMS_CONDITIONS;
    const { data } = await CommonService.request("get", url);
    return data;
  }
  // registration user add
  public static async userAdd(inputRequest) {
    const url = URL.FINAL_REGISTRATION;
    const { data } = await CommonService.request("post", url, inputRequest);
    return data;
  }
}
