/* eslint-disable */
import React, { ReactElement, useContext, useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { ValidatorForm } from "react-material-ui-form-validator";
import { Grid } from "@material-ui/core";
import { ThemeContext } from "../../themes";
import { LocalizationContext } from "../../locales";
import {
  Appbodycontainer,
  Darkblueheadingh3,
  Bluebutton,
  Darkbluebutton,
  ErrorMessage,
} from "../../themes/styles";
import {
  ISignUpPage1,
  SignupFormValuesInterface,
} from "./_interfaces/interface";
import { SignupContext } from "./_controllers/signupController";
import BaseInfo from "./baseInfo";
import PasswordSetUp from "./passwordSetUp";
import SecurityQuestions from "./securityQuestions";
import TermsConditions from "./termsConditions";
import ConfirmSignup from "./confirmSignup";
import { CommonService } from "../../_services/commonServices";

const formValues: SignupFormValuesInterface = {
  dobDay: "",
  dobMonth: "",
  dobYear: "",
  policyNumber: "",
  zipCode: "",
  email: "",
  userId: "",
  password: "",
  confirmPassword: "",
  formSubmit: false,
  securityQuestions: null,
  questionIDs: null,
  answers: null,
  acknowledgements: null,
  clientId: null,
  firstName: null,
  lastName: null
};

const formWizardState: any = {
  activeBlock: 0,
};

export default function SignUpPage(): ReactElement {
  const history = useHistory();
  const [formWizard, setFormWizard] = useState(formWizardState);
  const [formValuesState, setFormValuesState] = useState(formValues);
  const { theme } = useContext(ThemeContext);
  const { bundle } = useContext(LocalizationContext);
  const {
    signUpError,
    checkPolicyInfo,
    emailUseridRegistration,
    getTermsConditionsInfo,
    userAdd,
  } = useContext(SignupContext);

  // changing input field value
  const handleChange = (inputVal: any, field: any): void => {
    setFormValuesState({
      ...formValuesState,
      [field]: inputVal,
    });
  };
  // update the security question to state
  const updateSecurityQuestions = (questionData) => {
    setFormValuesState({
      ...formValuesState,
      securityQuestions: questionData,
    });
  };

  // submit new mailing address form
  const formSubmit = (e: any): void => {
    // basic policy info condition
    if (formWizard.activeBlock == 0) {
      console.log("step 1", formValuesState);
      // input request obj for api
      const inputRequest = {
        birthMonth: formValuesState.dobMonth,
        birthDay: formValuesState.dobDay,
        birthYear: formValuesState.dobYear,
        policyNumber: formValuesState.policyNumber,
        mailingZipCode: formValuesState.zipCode,
      };
      checkPolicyInfo(inputRequest)
        .then((response) => {
          console.log("client id", response);
          setFormValuesState({
            ...formValuesState, 
            clientId: response?.policyCheckResponse?.data?.clientId,
            firstName: response?.policyCheckResponse?.data?.firstname,
            lastName: response?.policyCheckResponse?.data?.lastname
          })
          setFormWizard({ ...formWizard, activeBlock: 1 });
        })
        .catch((error) => {
          CommonService.consolError(error, "signUpPage.tsx", "formSubmit");
        });
    }
    // email and user id condition
    else if (formWizard.activeBlock == 1) {
      console.log("step 2", formValuesState);
      const inputRequest = {
        username: formValuesState.userId,
        password: formValuesState.password,
        email: formValuesState.email,
      };
      emailUseridRegistration(inputRequest)
        .then((response) => {
          setFormWizard({ ...formWizard, activeBlock: 2 });
        })
        .catch((error) => {
          CommonService.consolError(error, "signUpPage.tsx", "formSubmit");
        });
    }
    // security questions condition
    else if (formWizard.activeBlock == 2) {
      console.log("step 3", formValuesState);
      const questionIDs: any = [];
      const answers: any = [];
      for (let i = 0; i < formValuesState?.securityQuestions?.length; i++) {
        questionIDs.push(formValuesState?.securityQuestions[i].questionID);
        answers.push(formValuesState?.securityQuestions[i].answer);
      }
      setFormValuesState({
        ...formValuesState,
        questionIDs: questionIDs,
        answers: answers,
      });
      setFormWizard({ ...formWizard, activeBlock: 3 });
    }
    // terms and conditions condition
    else if (formWizard.activeBlock == 3) {
      console.log("step 4", formValuesState);
      var currentDate = new Date();
      const inputRequest = {
        user: {
          logonId: formValuesState.userId,
          password: formValuesState.password,
          passwordRuleId: "FIRST_PUB",
          effectiveDate: currentDate.getFullYear() + "-" + (currentDate.getMonth() + 1)+ "-" + currentDate.getDate() ,
          applicationAccessId: ["PUB_SVC"],
          clientIds: [formValuesState.clientId],
          firstName: formValuesState.firstName,
          lastName: formValuesState.lastName,
          email: formValuesState.email,
          skipPasswordCheck: false,
          questionIDs: formValuesState.questionIDs,
          answers: formValuesState.answers
        },
        policyNumber: formValuesState.policyNumber,
        acknowledgements: null
      };
      getTermsConditionsInfo()
        .then((response) => {
          console.log("ack res", response?.termsConditionsResponse?.data);
          var ackRes: any = response?.termsConditionsResponse?.data;
          ackRes.acknowledgements[0].acknowledged = true;
          ackRes.acknowledgements[0].url = null;
          // console.log("ackRes ackRes", ackRes)
          setFormValuesState({
            ...formValuesState,
            acknowledgements: ackRes
          });
          inputRequest.acknowledgements = ackRes;          
          userAdd(inputRequest)
            .then((response) => {
              console.log("reg response", response);
              setFormWizard({ ...formWizard, activeBlock: 4 });
            })
            .catch((error) => {
              CommonService.consolError(error, "signUpPage.tsx", "formSubmit");
            });
        })
        .catch((error) => {
          CommonService.consolError(error, "signUpPage.tsx", "formSubmit");
        });
    }
  };

  //navigate to respective page
  const navigation = (path) => {
    history.push("/" + path);
  };

  return (
    <div>
      {/* App body start */}
      <Appbodycontainer theme={theme}>
        <div>
          <Darkblueheadingh3 theme={theme}>
            {bundle["heading.accountSignup"]}
          </Darkblueheadingh3>
          <ValidatorForm onSubmit={(e) => formSubmit(e)} autoComplete="off">
            {/* base info component */}
            {formWizard.activeBlock === 0 && (
              <BaseInfo
                bundle={bundle}
                theme={theme}
                formValues={formValuesState}
                handleChange={handleChange}
              />
            )}
            {/* password setup component  */}
            {formWizard.activeBlock === 1 && (
              <PasswordSetUp
                bundle={bundle}
                theme={theme}
                formValues={formValuesState}
                handleChange={handleChange}
              />
            )}
            {/* security questoins component */}
            {formWizard.activeBlock === 2 && (
              <SecurityQuestions
                bundle={bundle}
                theme={theme}
                updateSecurityQuestions={updateSecurityQuestions}
              />
            )}
            {/* terms and confitions component */}
            {formWizard.activeBlock === 3 && (
              <TermsConditions bundle={bundle} theme={theme} />
            )}
            {/* login navigarion block */}
            {formWizard.activeBlock === 4 && (
              <ConfirmSignup bundle={bundle} theme={theme} signupInfo={formValuesState} />
            )}
            {/* error message block */}
            {signUpError && (
              <ErrorMessage
                className="orange ssp-mt2 ssp-inline-block"
                theme={theme}
              >
                <b>{signUpError}</b>
              </ErrorMessage>
            )}

            {/* Action buttons */}
            {formWizard.activeBlock !== 4 && (
            <Grid container className="ssp-mt2">
              <Grid item xs={formWizard.activeBlock == '3'? 12:4} className="ssp-mt4 ssp-align-right">
                <Bluebutton
                  className="ssp-px6 ssp-mb3 ssp-mr3"
                  type="button"
                  theme={theme}
                  onClick={() => navigation("login")}
                >
                  {bundle["button.cancel"]}
                </Bluebutton>
                <Darkbluebutton className={`ssp-px6`} theme={theme}>
                  {bundle["button.continue"]}
                </Darkbluebutton>
                {/* <OrangeButton theme={theme} className="w-25" type="button">
                  {bundle["label.register"]}
                </OrangeButton> */}
              </Grid>
            </Grid>
            )}
          </ValidatorForm>
        </div>

        <div className="white-block"></div>
      </Appbodycontainer>
    </div>
  );
}
