import React, { ReactElement, useContext } from "react";
import { Grid } from "@material-ui/core";
import { ThemeContext } from "../../themes";
import { PacificBlueh3 } from "../../themes/styles";

export default function TermsConditions(props): ReactElement {
  const { theme } = useContext(ThemeContext);
  return (
    <>
      <div>
        <PacificBlueh3 theme={theme}>TERMS & CONDITIONS</PacificBlueh3>
        <Grid container>
          <Grid item xs={12}>
            <div style={{ minHeight: "500px", width: "100%" }}>
              <div
                style={{
                  height: "500px",
                  backgroundColor: "#cccccc",
                  width: "100%",
                  padding: "15px",
                }}
              >
                <div
                  style={{
                    backgroundColor: "#ffffff",
                    width: "100%",
                    height: "100%",
                  }}
                ></div>
              </div>
            </div>
          </Grid>
        </Grid>
      </div>
    </>
  );
}
