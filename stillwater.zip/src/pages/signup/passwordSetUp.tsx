/* eslint-disable */
import React, { ReactElement, useContext, useState, useEffect } from "react";
import { ValidatorForm, TextValidator } from "react-material-ui-form-validator";
import { Grid } from "@material-ui/core";
import { SspformGroup, PacificBlueh3, ErrorMessage } from "../../themes/styles";
import { ValidationService } from "../../_services/validation";
import { ISignUpPage2 } from "./_interfaces/interface";
import { SignupContext } from "./_controllers/signupController";
import { constantValues } from "../../config/config";
import PasswordStrengthBlock from "../../shared-components/passwordStrength/passwordStrength";

const initialState: ISignUpPage2 = {
  numberCheck: false,
  charCheck: false,
  uppercaseCheck: false,
  disableField: true,
  lengthCheck: false,
  emailExistenceError: "",
  useridExistenceError: "",
  formSubmit: false,
};

export default function PasswordSetUp(props): ReactElement {
  const [state, setState] = useState(initialState);

  useEffect(() => {
    ValidationService.charNumCombo();
  }, []);

  useEffect(() => {
    ValidationService.isPasswordMatch(props.formValues.password);
    ValidatorForm.addValidationRule("isStrong", (value) => {
      let lengthCheck = false;
      let numberCheck = false;
      let charCheck = false;
      let uppercaseCheck = false;

      if (value.length > constantValues.validationLength_8) {
        lengthCheck = true;
      }
      if (value.match(/^(?=.*[0-9]).{1,255}$/)) {
        numberCheck = true;
      }
      if (value.match(/^(?=.*[a-zA-Z]).{1,255}$/)) {
        charCheck = true;
      }
      if (value.match(/^(?=.*[A-Z]).{1,255}$/)) {
        uppercaseCheck = true;
      }
      setState({
        ...state,
        charCheck: charCheck,
        lengthCheck: lengthCheck,
        numberCheck: numberCheck,
        uppercaseCheck: uppercaseCheck,
      });
      if (lengthCheck === true && numberCheck === true && charCheck === true)
        return true;
      return false;
    });
  }, [props.formValues.password]);

  // changing input field value
  const handleChange = (e: any, field: any): void => {
    props.handleChange(e.target.value, field)
  };
  

  return (
    <>
      <Grid container>
        <Grid item xs={12} md={5}>
          <PacificBlueh3 theme={props.theme}>
            {props.bundle?.signup?.subHeading}
          </PacificBlueh3>
          {state.emailExistenceError && (
            <ErrorMessage className="orange ssp-dBlock" theme={props.theme}>
              {state.emailExistenceError}
            </ErrorMessage>
          )}
          {state.useridExistenceError && (
            <ErrorMessage className="orange ssp-dBlock" theme={props.theme}>
              {state.useridExistenceError}
            </ErrorMessage>
          )}
          <SspformGroup theme={props.theme} className="gray input50">
            <TextValidator
              label={props.bundle?.label?.email}
              fullWidth
              name="email"
              type="text"
              onChange={(e) => handleChange(e, "email")}
              value={props.formValues.email}
              validators={["required", "isEmail"]}
              errorMessages={[
                props.bundle?.validation?.emailRequired,
                props.bundle?.validation?.emailPattern,
              ]}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </SspformGroup>

          <SspformGroup theme={props.theme} className="gray input50">
            <TextValidator
              label={props.bundle?.label?.userid}
              fullWidth
              onChange={(e) => handleChange(e, "userId")}
              name="userId"
              id="userId"
              type="text"
              className="right"
              value={props.formValues.userId}
              validators={["required", "minStringLength:6", "maxStringLength:32"]}
              errorMessages={[
                props.bundle?.validation?.useridRequired,
                props.bundle?.validation?.useridMinimum,
                props.bundle?.validation?.useridMaximum,
              ]}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </SspformGroup>

          <SspformGroup
            theme={props.theme}
            className="gray input50 password-strength"
          >
            <TextValidator
              label={props.bundle?.label?.passcode}
              fullWidth
              name="password"
              id="userPassword"
              onChange={(e) => handleChange(e, "password")}
              value={props.formValues.password}
              validators={["required", "isStrong"]}
              errorMessages={[props.bundle?.changePassword?.newPasswordError]}
              InputLabelProps={{
                shrink: true,
              }}
              type="password"
            />
            {/* password strengh */}
            <PasswordStrengthBlock
              theme={props.theme}
              lengthCheck={state.lengthCheck}
              uppercaseCheck={state.uppercaseCheck}
              numberCheck={state.numberCheck}
              charCheck={state.charCheck}
              passStrengthMin={props.bundle?.validation?.passStrengthMin}
              passStrengthUppercase={
                props.bundle?.validation?.passStrengthUppercase
              }
              passStrengthNumber={props.bundle?.validation?.passStrengthNumber}
              passStrengthSpcChar={props.bundle?.validation?.passStrengthSpcChar}
            />
          </SspformGroup>

          <SspformGroup theme={props.theme} className="gray input50">
            <TextValidator
              label={props.bundle?.label?.confirmPassword}
              fullWidth
              name="confirmPassword"
              id="userConfirmPassword"
              onChange={(e) => handleChange(e, "confirmPassword")}
              value={props.formValues.confirmPassword}
              validators={["required", "isPasswordMatch"]}
              errorMessages={[
                props.bundle?.changePassword?.newPasswordError,
                props.bundle?.validation?.confirmPasswordMatch,
              ]}
              InputLabelProps={{
                shrink: true,
              }}
              type="password"
            />
          </SspformGroup>
        </Grid>
      </Grid>
    </>
  );
}
