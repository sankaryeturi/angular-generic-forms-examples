export interface SignupFormValuesInterface {
  dobDay: string | null;
  dobMonth: string | null;
  dobYear: string | null;
  policyNumber: string | null;
  zipCode: string | null;
  email: string | null;
  userId: string | null;
  password: string | null;
  confirmPassword: string | null;
  formSubmit: false;
  securityQuestions: any;
  questionIDs: any;
  answers: any;
  acknowledgements: any;
  clientId: string | null;
  firstName: string | null;
  lastName: string | null;
}
export interface ISignUpPage1 {
  buttonBlockSize: number;
  disableField: boolean;
  dobValidationMessage: any;
  dobValidationStatus: boolean;
  formSubmit: boolean;
}

export interface ISignUpPage2 {
  numberCheck: boolean;
  charCheck: boolean;
  uppercaseCheck: boolean;
  disableField: boolean;
  lengthCheck: boolean;
  emailExistenceError: any;
  useridExistenceError: any;
  formSubmit: boolean;
}
