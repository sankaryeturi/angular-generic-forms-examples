import React, { ReactElement } from "react";
import { useDispatch } from "react-redux";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import LoginPage from "./pages/login/LoginPage";
import { DashboardController } from "./pages/dashboard/dashboardController";
import DashboardPageComponent from "./pages/dashboard";
import NotFoundPage from "./pages/NotFoundPage";
import UrgentMessagesComponent from "./shared-components/urgent-messages/urgentMessagesComponent";
import Footer from "./shared-components/footer/footer";
import Accountsettings from "./pages/account-settings/index";
import ChangeMailingAddress from "./pages/account-settings/changeMailingAddress";
import ChangeMailAddressInfo from "./pages/account-settings/changeMailAddressInfo";
import "./assets/styles/common.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { AuthenticatedRoute, UnauthenticatedRoute } from "./_auth";
import { Hidden } from "@material-ui/core";
import { SettingsController } from "./pages/account-settings/settingsController";
import ChangeEmail from "./pages/account-settings/changeEmail";
import ChangePhoneNumber from "./pages/account-settings/changePhoneNumber";
import ChangePassword from "./pages/account-settings/changePassword";
import ChangeUserId from "./pages/account-settings/changeUserId";
import SignUpPage from "./pages/signup/signUpPage";
import { SignupController } from "./pages/signup/_controllers/signupController";
import PolicyInformation from "./pages/policies/policyInformation";
import { UrgentMessageController } from "./shared-components/urgent-messages/urgentMessageController";
import { PolicyController } from "./pages/policies/_controllers/policyController";
import LogoutComponent from "./pages/logout";
import { PoliciesService } from "./_services/policiesServices";
import {
  updatePolicies,
  updateUserProfile,
  updatedTargetedAlerts,
  updateAuthentication,
} from "./_actions";
import PaymentComponent from "./pages/payments";
import { CommonService } from "./_services/commonServices";
import MakePaymentComponent from "./pages/payments/makePayment";
import { PaymentController } from "./pages/payments/paymentController";
import ClaimsComponent from "./pages/claims/claims";
import { ClaimsController } from "./pages/claims/claimsController";
import SubmitClaimComponent from "./pages/claims/submitClaim";
import NotificationPreference from "./pages/account-settings/notificationPreference";
import PaperlessStatementComponent from "./pages/account-settings/paperless";
import ChangeSecurityQuestionsComponent from "./pages/account-settings/changeSecurityQuestions";
import MainHeader from "./shared-components/main-header/mainheader";
import ForgotPassword from "./pages/forgot-user/forgotPassword";
import { ForgotController } from "./pages/forgot-user/_controller/forgotController";
import ForgotUserId from "./pages/forgot-user/forgotUserId";
import AutoIdCardComponent from "./pages/policies/autoIdCard";
import RoadAssistance from "./pages/roadAssistance/roadAssistanceIndex";
import Edocs from "./pages/eDocs/edocs";
import { EdocsController } from "./pages/eDocs/edocsController";
import DocsNotes from "./pages/docs-notes/docsNotes";
import { DocsNotesController } from "./pages/docs-notes/_controller/docsNotesController";

export default function App(): ReactElement {
  const dispatch = useDispatch();
  const localStorageToken: any = localStorage.getItem("isAuthenticated");
  /** update the redux storage */
  async function updateStore(): Promise<void> {
    try {
      const policiesList: any = await PoliciesService.getPolicies();
      const targetedAlerts: any = await CommonService.getTargetedMessages();
      const targetList = targetedAlerts?.data?.messages;
      dispatch(updatePolicies(policiesList.data.policies)); // updating the policies to redux
      const userInfo = {
        userID: localStorage.getItem("userid"),
        username: policiesList.data.policies[0].policyNamed,
      };
      dispatch(updateUserProfile(userInfo));
      dispatch(updatedTargetedAlerts(targetList)); // updating the targeted alerts to redux
      dispatch(updateAuthentication(true)); // updating the user authentication status
    } catch (error) {
      // CommonService.tokenExpire(error);
      console.log(
        `%c Error: login.tsx - LoginForm.onClick ${JSON.stringify(error)}`,
        "color: #FF0000"
      );
    }
  }

  if (localStorageToken === "true") {
    updateStore();
  }

  return (
    <div className="App">
      {/*  */}
      <Hidden smDown>
        <UrgentMessageController>
          <UrgentMessagesComponent />
        </UrgentMessageController>
      </Hidden>

      <Router>
        {/* main header after login */}
        <MainHeader />
        <Switch>
          <UnauthenticatedRoute exact path="/login">
            <LoginPage />
          </UnauthenticatedRoute>

          <AuthenticatedRoute exact path="/">
            <DashboardController>
              <DashboardPageComponent />
            </DashboardController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/dashboard">
            <DashboardController>
              <DashboardPageComponent />
            </DashboardController>
          </AuthenticatedRoute>

          <UnauthenticatedRoute exact path="/signUpPage">
            <SignupController>
              <SignUpPage />
            </SignupController>
          </UnauthenticatedRoute>

          <AuthenticatedRoute exact path="/settings">
            <Accountsettings />
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/changemailaddress">
            <SettingsController>
              <ChangeMailingAddress />
            </SettingsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/changemailaddressinfo">
            <ChangeMailAddressInfo />
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/changeEmail">
            <SettingsController>
              <ChangeEmail />
            </SettingsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/changePhoneNumber">
            <SettingsController>
              <ChangePhoneNumber />
            </SettingsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/changePassword">
            <SettingsController>
              <ChangePassword />
            </SettingsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/changeUserid">
            <SettingsController>
              <ChangeUserId />
            </SettingsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/notifications">
            <SettingsController>
              <NotificationPreference />
            </SettingsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/paperlessstatement">
            <SettingsController>
              <PaperlessStatementComponent />
            </SettingsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/changeSecurityQuestions">
            <SettingsController>
              <ChangeSecurityQuestionsComponent />
            </SettingsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/policy-information/:policyNumber">
            <PolicyController>
              <PolicyInformation />
            </PolicyController>
          </AuthenticatedRoute>

          <Route exact path="/payments/:policyNumber">
            <PaymentController>
              <PaymentComponent />
            </PaymentController>
          </Route>

          <Route exact path="/makepayment">
            <MakePaymentComponent />
          </Route>

          <AuthenticatedRoute exact path="/autoid/:policyNumber">
            <PolicyController>
              <AutoIdCardComponent />
            </PolicyController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/roadAssistance">
            <RoadAssistance />
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/claims/:policyNumber">
            <ClaimsController>
              <ClaimsComponent />
            </ClaimsController>
          </AuthenticatedRoute>

          <AuthenticatedRoute exact path="/submitclaim">
            <ClaimsController>
              <SubmitClaimComponent />
            </ClaimsController>
          </AuthenticatedRoute>

          <Route exact path="/forgotpassword">
            <ForgotController>
              <ForgotPassword />
            </ForgotController>
          </Route>

          <Route exact path="/forgotuserid">
            <ForgotController>
              <ForgotUserId />
            </ForgotController>
          </Route>

          <Route exact path="/edocs">
            <EdocsController>
              <Edocs />
            </EdocsController>
          </Route>

          <AuthenticatedRoute exact path="/docsnotes/:policyNumber">
            <DocsNotesController>
              <DocsNotes />
            </DocsNotesController>
          </AuthenticatedRoute>

          <Route path="*">
            <LoginPage />
          </Route>

          <Route exact path="/logout">
            <LogoutComponent />
          </Route>
        </Switch>
      </Router>
      {/* footer area */}
      <Footer />
      <ToastContainer />
    </div>
  );
}
