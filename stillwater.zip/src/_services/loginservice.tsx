import Ajv from "ajv";
import { Profile, $Profile } from "../_interfaces/profile";
import { URL } from "../config/constants";
import { CommonService } from "./commonServices";
import { normalize, validate } from "../config/utils";

interface LoginResponse {
  username: string;
  bearerToken: string;
}

const validators = {
  profile: new Ajv().compile($Profile),
};

export class LoginService {
  // login auth
  public static async login(
    username: string,
    password: string
  ): Promise<LoginResponse> {
    const url = URL.LOGIN;
    const { headers } = await CommonService.request("post", url, {
      userID: username,
      password,
    });
    const bearerToken = headers.get("Authorization");
    if (!bearerToken)
      throw new Error("bearerToken was missing in server response");
    return { username, bearerToken };
  }
  // logout functionality
  public static async logout(): Promise<[]> {
    const path = URL.LOGOUT;
    const { data } = await CommonService.request("post", path);
    return data;
  }
}
