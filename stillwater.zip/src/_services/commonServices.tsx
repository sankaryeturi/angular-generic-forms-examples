import { URL } from "../config/constants";

interface ServerResponse {
  data: any;
  headers: Headers;
}

export class CommonService {
  /** api request parameter */
  public static async request(
    method: string,
    url: string,
    input?: any,
    token?: any
  ): Promise<ServerResponse> {
    const body = input ? JSON.stringify(input) : undefined;
    const headers: any = { "Content-Type": "application/json" };
    token && (headers["Authorization"] = token);
    const resp = await fetch(url, { method, body, headers });

    let errorMessage: any = "";

    if (resp.status !== 200) {
      errorMessage = await resp.text();
      if (resp.status === 401) {
        this.tokenExpire(errorMessage);
      }
      throw JSON.parse(errorMessage);
    } 
    // this else case is for temprory fix when getting the contentType === "text/plain 
    else {
      let contentType = resp.headers.get("Content-Type")
      if(contentType === "text/plain;charset=UTF-8") {
        const data = {
          data: true,
          headers: resp.headers,
          status: resp.status,
          error: errorMessage,
        };
        return { data, headers: resp.headers };
      }
    }
    const length = resp.headers.get("Content-Length");
    const authToken = resp.headers.get("Authorization");
    // once we are completely moved to qua site we need to remove this condition
    if (authToken !== null) {
      this.updateToken(authToken);
    }
    const data = {
      data: length === "0" ? null : await resp.json(),
      headers: resp.headers,
      status: resp.status,
      error: errorMessage,
    };
    return { data, headers: resp.headers };
  }
  // auth token update
  public static async updateToken(token) {
    localStorage.removeItem("authorizationToken");
    localStorage.setItem("authorizationToken", token);
  }
  // if token expired navigating to login page
  public static tokenExpire(error) {
    const tokenRrror = JSON.parse(error);
    const description = tokenRrror?.errors[0]?.errorDescription;
    const tokenMatch = description.match(/token/gi);
    if (tokenMatch !== null) {
      // localStorage.removeItem("isAuthenticated");
      // window.location.href = "/";
    }
  }
  /** get the important info */
  public static async getUrgentMessages(): Promise<[]> {
    const url = URL.BLANKETED_ALERTS;
    const { data } = await this.request("get", url);
    return data;
  }
  /** get targeted messages */
  public static async getTargetedMessages(): Promise<[]> {
    const url = URL.TARGETED_ALERTS;
    const { data } = await this.request("get", url);
    return data;
  }

  /** get states list */
  public static async getState(): Promise<[]> {
    const url = URL.GET_STATES;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await this.request("get", url, "", loginToken);
    return data;
  }

  /** get cities list */
  public static async getCities(stateCode: string): Promise<[]> {
    const url = URL.getCities(stateCode);
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await this.request("get", url, "", loginToken);
    return data;
  }
  /** update policy alerts */
  public static async updatePolicyAlerts(alertInfo, userId): Promise<[]> {
    const url = URL.updatePolicyAlertsUrl(userId);
    const { data } = await this.request("post", url, alertInfo);
    return data;
  }

  /** icon class */
  public static policyIcon(iconType: string) {
    switch (iconType) {
      case "Home-H3": {
        return "icon home-icon";
        break;
      }
      case "Auto": {
        return "icon car-icon";
        break;
      }
      case "Business": {
        return "icon building";
        break;
      }
      case "Renters": {
        return "icon renters";
        break;
      }
      case "Umbrella": {
        return "icon umbrella";
        break;
      }
      case "Landlord": {
        return "icon landlord";
        break;
      }
      default:
        return "icon building";
    }
  }

  /** checking cookie error */
  public static cookieError(error) {
    // if (error?.errors[0]?.error === "CookieError") {
    //   localStorage.removeItem("isAuthenticated");
    //   window.location.href = "/";
    //   //return true;
    // } else {
    //   return false;
    // }
  }

  /** checking the blanked/targeted alert period is valid or not */
  public static checkActiveStatus = (startData, endDate) => {
    const currentDate = new Date();
    startData = Date.parse(startData);
    endDate = Date.parse(endDate);
    const cDate = Date.parse(
      currentDate.getMonth() +
        1 +
        "/" +
        currentDate.getDate() +
        "/" +
        currentDate.getFullYear()
    );
    if (startData <= cDate && endDate >= cDate) return true;
    return false;
  };
  /**  */
  public static priceFormat(price) {
    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }
  /** logout */
  public static logout() {
    const url = URL.LOGOUT;
    const loginToken = localStorage.getItem("authorizationToken");
    const data = this.request("delete", url, "", loginToken);
    localStorage.clear();
    return data;
  }
  // console error display
  public static consolError(error, pageName, functionName) {
    console.log(
      `%c Error: ${pageName} - ${functionName} ${JSON.stringify(error)}`,
      "color: #FF0000"
    );
  }
}
