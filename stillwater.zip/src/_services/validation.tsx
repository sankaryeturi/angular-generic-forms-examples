/* eslint-disable */
import { ValidatorForm } from "react-material-ui-form-validator";

export class ValidationService {
  /**
   * minLength()
   */
  public static minLength(submitStatus) {
    ValidatorForm.addValidationRule("minLength", (value) => {
      if (submitStatus?.formSubmit === false && value.length < 6) {
        return false;
      }
      return true;
    });
  }
  /**
   * charNumCombo
   */
  public static charNumCombo() {
    ValidatorForm.addValidationRule("charNumCombo", (value) => {
      const regExp = /^(?=.*[a-z])(?=.*[0-9]).{1,255}$/;
      if (value.match(regExp)) return true;
      return false;
    });
  }
  /**
   *
   * @param form
   */
  public static emailMatch(form) {
    ValidatorForm.addValidationRule("emailMatch", (value) => {
      if (value !== form.email) return false;
      return true;
    });
  }

  public static emailExistence(input) {
    ValidatorForm.addValidationRule("emailExistence", (value) => {
      if (input) return true;
      return false;
    });
  }

  /**
   * number validation like phone number
   */
  public static numberCheck() {
    ValidatorForm.addValidationRule("numberCheck", (value) => {
      if (isNaN(value)) return false;
      return true;
    });
  }
  /**
   * password mach
   */
  public static isPasswordMatch(newPassword) {
    ValidatorForm.addValidationRule("isPasswordMatch", (value) => {
      if (value !== newPassword) {
        return false;
      }
      return true;
    });
  }

  /**
   * Phone number validation
   */
  public static phoneValidation() {
    ValidatorForm.addValidationRule("phoneValidation", (value) => {
      if (value.length === 10) {
        return true;
      }
      return false;
    });
  }

  //date of birth validation
  public static dobValidation(day, month, year) {
    const mm: any = parseInt(month);
    const dd: any = parseInt(day);
    const yy: any = parseInt(year);
    const ListofDays: any = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (mm === 1 || mm > 2) {
      if (dd > ListofDays[mm - 1]) {
        return false;
      }
    }
    if (mm === 2) {
      let lyear = false;
      if ((!(yy % 4) && yy % 100) || !(yy % 400)) {
        lyear = true;
      }
      if (lyear === false && dd >= 29) {
        return false;
      }
      if (lyear === true && dd > 29) {
        return false;
      }
    }
    if (mm > 12) {
      return false;
    }
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();
    const currentDay = currentDate.getDate();
    if (yy > currentYear) {
      return false;
    } else if (yy === currentYear) {
      if (mm > currentMonth + 1) {
        return false;
      } else if (mm === currentMonth + 1) {
        if (dd > currentDay) return false;
        return true;
      }
    } else {
      return true;
    }
  }
}
