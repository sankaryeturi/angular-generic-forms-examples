import { Policy, $Policies } from "../_interfaces/policies";
import { URL } from "../config/constants";
import { CommonService } from "./commonServices";

export class PoliciesService {
  // get the user profile
  public static async getPolicies(): Promise<Policy[]> {
    const url = URL.GET_ALL_POLICIES;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("get", url, "", loginToken);
    return data;
  }

  /**
   * get policy individual details
   * @param policyNumber
   */
  public static async policyDetails(policyNumber) {
    const path = URL.GET_POLICY_DETAILS;
    const inputData = {
      policyNumber: policyNumber,
    };
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "POST",
      path,
      inputData,
      loginToken
    );
    return data;
  }
  /** get the autoid card by policy number */
  public static async getAutoIds(inputRequest): Promise<[]> {
    const path = URL.GET_AUTOIDS_LIST;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request(
      "POST",
      path,
      inputRequest,
      loginToken
    );
    return data;
  }
  /** get help text info */
  public static async getHelptextInfo(inputReq): Promise<[]> {
    const url = URL.GET_HELPTEXT;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("POST", url, inputReq, loginToken);
    return data;
  }
  /** send auto id card email */
  public static async autoCardSendMail(inputReq): Promise<[]> {
    const url = URL.AUTOID_SEND_MAIL;
    const loginToken = localStorage.getItem("authorizationToken");
    const { data } = await CommonService.request("POST", url, inputReq, loginToken);
    return data;
  }
  
}
