const path = require('path')
const webpack = require('webpack');
const CompressionPlugin = require('compression-webpack-plugin');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

module.exports = 
{
    entry: './src/index.tsx',
    devtool: 'inline-source-map',
    module:
    {
        rules:
        [{
            test: /\.ts(x?)$/,
            exclude: /node_modules/,
            use: 
            [{
                loader: "ts-loader",
                options: { configFile: "tsconfig.client.json" }
            }]
        },
        {
            test: /\.css$/,
            use: ['style-loader', 'css-loader' ]
        },
        {
            test: /\.(png|svg|jpg|gif|woff2)$/,
            use: 
            [{
                loader: 'file-loader',
                options:
                {
                    outputPath: '../images',
                    publicPath: '/ClientSelfService/images/',
                },
            }],
        }],
    },
    resolve:
    {
        extensions: ['.js', '.ts', '.tsx'],
    },
    optimization: 
    {
        minimizer: 
        [
            new UglifyJsPlugin({
                test: /\.js$|\.css$|\.html$|\.ts$|\.tsx$/,
            }),
        ],
    },
    plugins: 
    [
        new webpack.DefinePlugin( // <-- key to reducing React's size
        {
            'process.env': {'NODE_ENV': JSON.stringify('production')}
        }),

        // new webpack.optimize.DedupePlugin(), //dedupe similar code 
        // new webpack.optimize.minimize(), //minify everything
        new webpack.optimize.AggressiveMergingPlugin(),//Merge chunks
        
        // new BundleAnalyzerPlugin(),
    ],
    output:
    {
        filename: 'ssp-main.js',
        path: path.resolve(__dirname, './WebContent/js'),
    },
    node:
    {
        fs: 'empty',
        net: 'empty',
        tls: 'empty',
    }
}
